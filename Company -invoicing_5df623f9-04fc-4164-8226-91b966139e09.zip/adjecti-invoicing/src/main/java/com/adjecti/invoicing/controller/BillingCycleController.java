package com.adjecti.invoicing.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.adjecti.invoicing.dto.BillingCycleDto;
import com.adjecti.invoicing.response.Response;
import com.adjecti.invoicing.service.BillingCycleService;

@Controller
@RequestMapping("/billingcycle")
public class BillingCycleController {

	@Autowired
	private BillingCycleService billingCycleService;
	 	
	private List<BillingCycleDto> allBillingCycle;

	@PostMapping(value = "/save",produces = {MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody ResponseEntity<?> saveOrUpdate(@Valid @ModelAttribute("billingcycle")  BillingCycleDto billingCycle,
			BindingResult bindingResult) {
		System.out.println(billingCycle.getType());
		List<Response> responseList=new ArrayList<>();
		
		if(bindingResult.hasErrors()) {
			System.out.println("inside binding result");
			List<FieldError> fieldErrors = bindingResult.getFieldErrors();
			for(FieldError temp:fieldErrors) {
				System.out.println(temp.getField()+"  "+temp.getDefaultMessage());
				 responseList.add(new Response(temp.getField(),temp.getDefaultMessage(),null));
			}
			
			return new ResponseEntity<>(responseList,HttpStatus.BAD_REQUEST);
		}
			Response response=new Response();
			billingCycleService.save(billingCycle);
			response.setStatusMessage("New Record Added");
			if(billingCycle.getId()>0)
				response.setStatusMessage("Record Updated");
			return new ResponseEntity<>(response,HttpStatus.OK);
		
	}

	@GetMapping("/list")
	public  String billingCycleList(Model theModel) {

		theModel.addAttribute("billingCycleList", billingCycleService.getAllBillingCycle());

		return "billingcycle";
	}
	
	@GetMapping("/load")
	public @ResponseBody List<BillingCycleDto> loadBillingCycle(){
	
		allBillingCycle = billingCycleService.getAllBillingCycle();
		return allBillingCycle;
	}

	@RequestMapping("/delete")
	public @ResponseBody String delete(@ModelAttribute("id") int id) {

		billingCycleService.delete(id);
		return "Record Deleted";
	}

	@GetMapping(value = "/getById", produces = "application/json")
	public @ResponseBody BillingCycleDto findId(@RequestParam(value = "id") int id) {
		BillingCycleDto billingCycleDto = this.billingCycleService.findById(id);
		return billingCycleDto;
	}
	
	
}