package com.adjecti.invoicing.controller;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adjecti.invoicing.dto.BillingTypeDto;
import com.adjecti.invoicing.response.ValidationResponse;
import com.adjecti.invoicing.service.BillingTypeService;

@RestController
@RequestMapping("/billingType")
public class BillingTypeController {

	@Autowired
	private BillingTypeService billingTypeService;
	
	@GetMapping("/list")
	public ResponseEntity<List<BillingTypeDto>> getList() {
		return new ResponseEntity<List<BillingTypeDto>>(billingTypeService.findAll(), HttpStatus.OK);
	}

	@GetMapping("/billingType/{id}")
	public ResponseEntity<BillingTypeDto> getById(@PathVariable Integer id) {
		return new ResponseEntity<BillingTypeDto>(billingTypeService.findById(id), HttpStatus.OK);
	}

	@PostMapping("/save")
	public ResponseEntity<?> saveOrUpdateBillingType(@Valid @RequestBody @ModelAttribute("billingtypeDto")  BillingTypeDto billingtypeDto) {
		
		return new ResponseEntity<>(billingTypeService.save(billingtypeDto),HttpStatus.OK);
		
	}
	@GetMapping("/delete/{id}")
	public ResponseEntity<Void> delete(@PathVariable String id) {
		System.out.println(id);
		billingTypeService.delete(Integer.parseInt(id));
		return new ResponseEntity<Void>(HttpStatus.OK);
	}

}
