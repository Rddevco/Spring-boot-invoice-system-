package com.adjecti.invoicing.controller;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.adjecti.invoicing.dto.ConsultantDto;
import com.adjecti.invoicing.dto.ConsultantInvoicingDto;
import com.adjecti.invoicing.dto.PaymentModeDto;
import com.adjecti.invoicing.model.ConsultantInvoicing;
import com.adjecti.invoicing.response.Response;
import com.adjecti.invoicing.response.ValidationResponse;
import com.adjecti.invoicing.service.ConsultantInvoicingService;
import com.adjecti.invoicing.service.ConsultantPaymentService;
import com.adjecti.invoicing.service.ConsultantService;
import com.adjecti.invoicing.service.PaymentModeService;
@Controller
@RequestMapping("/consultantinvoicing")
public class ConsultantInvoicingController {

	@Autowired
	private ConsultantInvoicingService consultantInvoicingService;
	@Autowired 
	private ValidationResponse response;
	@Autowired
	private ConsultantService consultantService;
    @Autowired
	private PaymentModeService paymentModeService;

	@GetMapping("/list")
	public String getConsultantInvoicing(Model m) 
	{
		return "consultant-invoicing";
	}	
	@RequestMapping(value="/jlist", produces="application/json")
	  public ResponseEntity<List<ConsultantInvoicingDto>> getConsultantInvoicingList() {
	    try {
	      List<ConsultantInvoicingDto> consulatntInvoicingList = consultantInvoicingService.findAll();
	      if (consulatntInvoicingList.isEmpty()) {
	        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	      }
	      return new ResponseEntity<>(consulatntInvoicingList, HttpStatus.OK);
	    } catch (Exception e) {
	      return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	  }

	
	@RequestMapping("/add")
	public String addConsultantInvoicing(Model m)
	{	
		List<ConsultantDto> consultant=consultantService.findAll();
		//System.out.println(consultant);	
		m.addAttribute("consultant",consultant);
		m.addAttribute("consultantinvoicing",new ConsultantInvoicing());
		return "consultant-invoicingform";
	}
	
	@RequestMapping(value="/save", method = {RequestMethod.POST,RequestMethod.GET}, produces = "application/json")
	public @ResponseBody ResponseEntity<?> saveConsultantInvoicing(@Valid @ModelAttribute("consultantinvoicing") ConsultantInvoicingDto consultantInvoicingDto,BindingResult result,MultipartFile file)
	{
		List<Response> responseList = new ArrayList<>();
		System.out.println(consultantInvoicingDto.getConsultantInvoicDocument().getId());
		System.out.println(file.getOriginalFilename());
		//System.out.println(consultantInvoicingDto);	
            if(result.hasErrors()) {
			System.out.println("hello");
			   Map<String, String> errors = result.getFieldErrors().stream()
	                    .collect(
	                            Collectors.toMap(FieldError::getField, FieldError::getDefaultMessage)
	                    );
	            response.setValidated(false);
	            response.setErrorMessages(errors);
		return new ResponseEntity<>(response,HttpStatus.BAD_REQUEST);	            
		}
   		Response response=new Response();
		if(!file.getOriginalFilename().isEmpty()) {
		this.consultantInvoicingService.save(consultantInvoicingDto,file);	
		response.setStatusMessage("Created");
		}
		else {
			this.consultantInvoicingService.update(consultantInvoicingDto);	
			response.setStatusMessage("Updated");
		}
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	@RequestMapping("/delete/{id}")
	public @ResponseBody String deleteConsultantInvoicing(@PathVariable("id") Integer id, Model m,RedirectAttributes redirectAttributes) {
		System.out.println(id);
		this.consultantInvoicingService.deleteConsultantInvoicing(id);
		redirectAttributes.addFlashAttribute("msg", "Successfully Deleted Consultant Invoice!!!");
		return "Delete";
	}
	@GetMapping("/update")
	public String updateConsultantView(@RequestParam("id") int id,Model m) {
		System.out.println(id);
		List<ConsultantDto> consultant=consultantService.findAll();
		m.addAttribute("consultant",consultant);
		ConsultantInvoicingDto cunsulConsultantInvoicing=consultantInvoicingService.findByid(id);
		
		m.addAttribute("consultantinvoicing",cunsulConsultantInvoicing);
		return "consultant-invoicingform";
	}
	
	
}
