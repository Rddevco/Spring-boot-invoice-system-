package com.adjecti.invoicing.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.adjecti.invoicing.model.CostToCompanySalary;
import com.adjecti.invoicing.model.Response;
import com.adjecti.invoicing.service.CostToCompanyService;

@Controller
@RequestMapping("/costtocompanycontroller")
public class CostToCompanyController {
@Autowired
	CostToCompanyService costToCompanyService;
	
	@GetMapping("/costtocompany")
	public String costToCompany(Model model) {
		CostToCompanySalary costToCompanySalary=new CostToCompanySalary();
        model.addAttribute("costtocompanysalary", costToCompanySalary);
        
        return "costtocompany";

	}
	
	@GetMapping("/list")
	@ResponseBody
	public List<CostToCompanySalary> getCostToCompanyList()
	{
		 List<CostToCompanySalary> list=costToCompanyService.getList();
    return list;
	}
	
	@GetMapping("/fetch/{id}")
	public @ResponseBody CostToCompanySalary  getById(@PathVariable("id") Integer id ,Model model)
	{ 
		
		System.out.println("Cost Id No");
		
		CostToCompanySalary costToCompanySalary=costToCompanyService.getBYId(id);
		return costToCompanySalary;
		
	}
	
	@RequestMapping("/delete/{idNo}")
	public @ResponseBody String  softdelete(@PathVariable("idNo") Integer idNo ) {
		System.out.println("Soft Delete Successully....."+idNo);
		String data = costToCompanyService.getSalaryByIdForDelete(idNo);
		String value="";
		if(data.equals("Delete Is Successfully Done."))
		{
			value="Successfully Deleted";
        System.out.print(data);
		}else {
			value="Not Deleted .";
		}
        return value;
	}
	
	@PostMapping("/updateCostToCompany")
    @ResponseBody
	public ResponseEntity<?> updateCostToCompany(@Valid @ModelAttribute CostToCompanySalary costtocompanysalary,BindingResult result,Model model)
	{
		System.out.println("tds"+costtocompanysalary.getRetention());
		System.out.println("tds"+costtocompanysalary.getPBI());
    	//model.addAttribute("costtocompanysalary",new CostToCompanySalary());
		if(costtocompanysalary.getPaymentModeForRetention().equals("percentage") )
		{
			System.out.println("inside tds");
			if(costtocompanysalary.getRetention()<=100.0 ) {}
			else {
		ObjectError error = new ObjectError("retention","Its Value must be less than 100 .");
			result.addError(error);}
		}
		if(costtocompanysalary.getPaymentModeforPBI().equals("percentage") )
		{	System.out.println("inside retension");
			if(costtocompanysalary.getRetention()<=100.0 ) {}
			else {
		ObjectError error = new ObjectError("pBI","Its Value must be less than 100 .");
			result.addError(error);}
		}
		System.out.println("Retention"+costtocompanysalary.getPaymentModeForRetention());
		System.out.println("PBI"+costtocompanysalary.getPaymentModeforPBI());
		System.out.println("Update Salary Page");
		System.out.println(costtocompanysalary.getId());
		 List<Response> responseList=new ArrayList<>();
				if(result.hasErrors()) {
				System.out.println("inside binding result "+result.getFieldErrors());
				List<ObjectError> allErrors = result.getAllErrors();
                 for(ObjectError temp:allErrors) {
					
					System.out.println(temp.getObjectName()+" MMM "+temp.getDefaultMessage());
				 responseList.add(new  Response(temp.getObjectName(),temp.getDefaultMessage(),null));
					 
				}
				System.out.println("Object error "+allErrors);
				List<FieldError> fieldErrors = result.getFieldErrors();
				for(FieldError temp:fieldErrors) {
					
					System.out.println(temp.getField()+" MMM "+temp.getDefaultMessage());
					 responseList.add(new Response(temp.getField(),temp.getDefaultMessage(),null));
				}
				System.out.println(result.getErrorCount());	
				System.out.println(result);
				return new ResponseEntity<>(responseList,HttpStatus.BAD_REQUEST);
			}
	Response response=new  Response();
	response.setStatusMessage("COst To Company Save Successfully");
	CostToCompanySalary costToCompanySalary= costToCompanyService.forUpdateCostToCompanySalary(costtocompanysalary);
	System.out.println(result.getErrorCount());	
	System.out.println(result);
	return new ResponseEntity<>(response,HttpStatus.OK);
	}
	
	
}
