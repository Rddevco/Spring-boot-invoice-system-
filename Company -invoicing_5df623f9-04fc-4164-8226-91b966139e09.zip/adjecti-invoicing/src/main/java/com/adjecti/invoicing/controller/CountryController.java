package com.adjecti.invoicing.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adjecti.invoicing.dto.CountryDto;
import com.adjecti.invoicing.service.BillingTypeService;
import com.adjecti.invoicing.service.CountryService;

@RestController
@RequestMapping("/country")
public class CountryController {

	@Autowired
	private CountryService countryService;
	@GetMapping("/list")
	public ResponseEntity<List<CountryDto>> getCountryList() {
		return new ResponseEntity<List<CountryDto>>(countryService.getCountryList(), HttpStatus.OK);
	}

	@PostMapping("/save")
	public ResponseEntity<CountryDto> saveOrUpdateCompany(@Valid @RequestBody @ModelAttribute("country") CountryDto countrydto) {
	
		return new ResponseEntity<CountryDto>(countryService.save(countrydto),HttpStatus.OK);
	}

	@GetMapping("/delete/{id}")

	public ResponseEntity<Void> delete(@PathVariable String id) {
		System.out.println(id);
		countryService.delete(Integer.parseInt(id));
		return new ResponseEntity<Void>(HttpStatus.OK);
	}

}
