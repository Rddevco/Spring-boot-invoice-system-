package com.adjecti.invoicing.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
 
 import com.adjecti.invoicing.model.EmployeeAddress;
import com.adjecti.invoicing.model.Response;
import com.adjecti.invoicing.service.EmployeeAddressService;
@Controller
@RequestMapping("/employeeaddress")
public class EmployeeAddressController {

	@Autowired
	EmployeeAddressService employeeAddressService;
	

	@PostMapping("/saveemployeeaddress")
	@ResponseBody
	public ResponseEntity<?> saveEmployee(@Valid @ModelAttribute EmployeeAddress employeeAddress,BindingResult result)
	{
		System.out.println("Arrddess Isd "+employeeAddress.getAddressId());
		List<Response> reponseList=new ArrayList<>();
		if(result.hasErrors())
		{
			List<FieldError> fieldErrors = result.getFieldErrors();
			for(FieldError fieldError:fieldErrors)
			{
				reponseList.add(new Response(fieldError.getField(),fieldError.getDefaultMessage(),null));
			}
        return new ResponseEntity<>(reponseList,HttpStatus.BAD_REQUEST);
		}
		Response response=new Response();
		response.setStatusMessage("Employee Save Successfulley");
		EmployeeAddress saveEmployeeAddress = employeeAddressService.saveEmployee(employeeAddress);
	 
		return new ResponseEntity<>(response,HttpStatus.OK);
		
	}
	
	 @RequestMapping("/employee/{id}")
	  @ResponseBody
	  public List<EmployeeAddress> fetchEmployeeAddressBasedOnEmployeeId(@PathVariable("id") Integer id)
	  {
	    List<EmployeeAddress> employeeAddress=employeeAddressService.fetchEmployeeAddress(id);
		
	    for(EmployeeAddress e:employeeAddress)
	    {
	    e.setEmployee(null);
	    }
	    return employeeAddress;
	  
	  }
	 
	 @RequestMapping("/delete/{id}")
	  @ResponseBody
	  public String deleteEmployee(@PathVariable("id") Integer id)
	  {
		 String str= employeeAddressService.deleteEmployee(id);
		return str;
		  
	  }
	
	
	 @RequestMapping("/fetch/{id}")
	  @ResponseBody
	  public EmployeeAddress fetchEmployeeAddress(@PathVariable("id") Integer id)
	  {
		 EmployeeAddress employee= employeeAddressService.fetchEmployee(id);
		 employee.setEmployee(null);
		return employee;
		  
	  }
	}
	
	

