package com.adjecti.invoicing.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.adjecti.invoicing.model.Employee;
import com.adjecti.invoicing.model.EmployeeAddress;
import com.adjecti.invoicing.model.EmployeeEducation;
import com.adjecti.invoicing.model.EmployeeExperence;
import com.adjecti.invoicing.model.Leave;
import com.adjecti.invoicing.model.Response;
import com.adjecti.invoicing.service.EmployeeService;

@Controller
@RequestMapping("/employee")
public class EmployeeController {
	@Autowired
	EmployeeService employeeService;
	
	@GetMapping("/showemployee")
	public String showEmployee(Model model)
	{Employee employee=new Employee();
	EmployeeAddress employeeAddress=new EmployeeAddress();
	EmployeeExperence employeeExperence=new EmployeeExperence();
	EmployeeEducation employeeEducation=new EmployeeEducation();
	model.addAttribute("employee", employee);
	model.addAttribute("employeeAddress",employeeAddress);
	model.addAttribute("employeeExperence", employeeExperence);
	model.addAttribute("employeeEducation", employeeEducation);
		
		return "employee";
		
	}
	
	@GetMapping("/employeeform/{id}")
	public String showEmployeeForm(@PathVariable("id") Integer id,Model model)
	{   model.addAttribute("id",id);
		Employee employee=new Employee();
		EmployeeAddress employeeAddress=new EmployeeAddress();
		EmployeeExperence employeeExperence=new EmployeeExperence();
		EmployeeEducation employeeEducation=new EmployeeEducation();
		model.addAttribute("employee", employee);
		model.addAttribute("employeeAddress",employeeAddress);
		model.addAttribute("employeeExperence", employeeExperence);
		model.addAttribute("employeeEducation", employeeEducation);
		return "employeeform";
		
	}
	

	
	@PostMapping("/saveemployee")
	@ResponseBody
	public ResponseEntity<?> saveEmployee(@Valid @ModelAttribute Employee employee,BindingResult result)
	{
		List<Response> reponseList=new ArrayList<>();
		if(result.hasErrors())
		{
			List<FieldError> fieldErrors = result.getFieldErrors();
			for(FieldError fieldError:fieldErrors)
			{
				reponseList.add(new Response(fieldError.getField(),fieldError.getDefaultMessage(),null));
			}
        return new ResponseEntity<>(reponseList,HttpStatus.BAD_REQUEST);
		}
		Response response=new Response();
		response.setStatusMessage("Employee Save Successfulley");
		Employee saveEmployee = employeeService.saveEmployee(employee);
	 
		return new ResponseEntity<>(response,HttpStatus.OK);
		
	}
	
	
	@GetMapping("/list")
	@ResponseBody
	public List<Employee> getEmployeeList()
	{
		List<Employee> list=employeeService.getEmployees();
		
		for(Employee e:list)
		{e.setEmployeeExperence(null);
		
			e.setEmployeeEducation(null);
			e.setEmployeeAddress(null);
			List<Leave> leave = e.getLeave();
			for(Leave l:leave)
			{
				l.setEmployee_id(null);
							}
		}
		return list;
		
	}
	
  @RequestMapping("/delete/{id}")
  @ResponseBody
  public String deleteEmployee(@PathVariable("id") Integer id)
  {
	 String str= employeeService.deleteEmployee(id);
	return str;
	  
  }
  
  @RequestMapping("/fetch/{id}")
  @ResponseBody
  public Employee fetchEmployee(@PathVariable("id") Integer id)
  {
	 Employee employee= employeeService.fetchEmployee(id);
	 employee.setEmployeeExperence(null);
	 employee.setEmployeeAddress(null);
	 employee.setEmployeeEducation(null);
		employee.setEmployeeAddress(null);
	 List<Leave> leave = employee.getLeave();
	 for(Leave leave1:leave)
	 {
		 leave1.setEmployee_id(null);
	 }
	return employee;
	  
  }
}
