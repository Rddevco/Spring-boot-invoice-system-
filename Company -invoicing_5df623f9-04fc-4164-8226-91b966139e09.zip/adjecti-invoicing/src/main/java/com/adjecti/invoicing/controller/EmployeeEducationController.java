package com.adjecti.invoicing.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.adjecti.invoicing.model.EmployeeEducation;

import com.adjecti.invoicing.model.Response;
import com.adjecti.invoicing.service.EmployeeEducationService;

@Controller
@RequestMapping("/employeeeducation")
public class EmployeeEducationController {

	@Autowired
	EmployeeEducationService employeeEducationService;
	
	
	@PostMapping("/saveemployeeeducation")
	@ResponseBody
	public ResponseEntity<?> saveEmployeeEducation(@Valid @ModelAttribute EmployeeEducation employeeEducation,BindingResult result)
	{System.out.println("Arrddess Isd Save Experence ");
		List<Response> reponseList=new ArrayList<>();
		if(result.hasErrors())
		{
			List<FieldError> fieldErrors = result.getFieldErrors();
			for(FieldError fieldError:fieldErrors)
			{
				reponseList.add(new Response(fieldError.getField(),fieldError.getDefaultMessage(),null));
			}
        return new ResponseEntity<>(reponseList,HttpStatus.BAD_REQUEST);
		}
		Response response=new Response();
		response.setStatusMessage("Employee Save Successfulley");
		EmployeeEducation saveEmployeeExperence =employeeEducationService.saveEmployeeEducation(employeeEducation);
	 
		return new ResponseEntity<>(response,HttpStatus.OK);
		
	}
	
	 @GetMapping("/employee/{id}")
	  @ResponseBody
	  public List<EmployeeEducation> fetchEmployeeEducationBasedOnEmployeeId(@PathVariable("id") Integer id)
	  {
		 List<EmployeeEducation> employeeEducation=employeeEducationService.fetchEmployee(id);
		for(EmployeeEducation e:employeeEducation)
		{
			e.setEmployee(null);
		}
	    return employeeEducation;
	    
	  }
	
	
	
	 @RequestMapping("/fetch/{id}")
	  @ResponseBody
	  public EmployeeEducation fetchEmployeeEducation(@PathVariable("id") Integer id)
	  {
		 EmployeeEducation employee=employeeEducationService.fetchEducation(id);
		 employee.setEmployee(null);
		return employee;
		  
	  }
	
	 @RequestMapping("/delete/{id}")
	  @ResponseBody
	  public boolean deleteEmployee(@PathVariable("id") Integer id)
	  {
		 boolean str= employeeEducationService.deleteEmployeeExperence(id);
		return str;
		  
	  }
	
}
