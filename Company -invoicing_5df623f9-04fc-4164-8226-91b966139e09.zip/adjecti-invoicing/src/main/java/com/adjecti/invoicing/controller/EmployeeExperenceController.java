package com.adjecti.invoicing.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.adjecti.invoicing.model.EmployeeExperence;
import com.adjecti.invoicing.model.Response;
import com.adjecti.invoicing.service.EmployeeExperenceService;

@Controller
@RequestMapping("/employeeexperence")
public class EmployeeExperenceController {
	@Autowired
	EmployeeExperenceService employeeExperenceService;
	
	
	@PostMapping("/saveemployeeexperence")
	@ResponseBody
	public ResponseEntity<?> saveEmployee(@Valid @ModelAttribute EmployeeExperence employeeExperence,BindingResult result)
	{System.out.println("Arrddess Isd Save Experence ");
		List<Response> reponseList=new ArrayList<>();
		if(result.hasErrors())
		{
			List<FieldError> fieldErrors = result.getFieldErrors();
			for(FieldError fieldError:fieldErrors)
			{
				reponseList.add(new Response(fieldError.getField(),fieldError.getDefaultMessage(),null));
			}
        return new ResponseEntity<>(reponseList,HttpStatus.BAD_REQUEST);
		}
		Response response=new Response();
		response.setStatusMessage("Employee Save Successfulley");
		EmployeeExperence saveEmployeeExperence =employeeExperenceService.saveEmployeeExperence(employeeExperence);
	 
		return new ResponseEntity<>(response,HttpStatus.OK);
		
	}
	
	 @GetMapping("/employee/{id}")
	  @ResponseBody
	  public List<EmployeeExperence> fetchEmployeeExperenceBasedOnEmployeeId(@PathVariable("id") Integer id)
	  {
		 List<EmployeeExperence> employeeExperence=employeeExperenceService.fetchEmployeeExperence(id);
		for(EmployeeExperence e:employeeExperence)
		 {e.setEmployee(null);
		 
		 }
	    return employeeExperence;
	    
	  }
	
	
	
	 @GetMapping("/fetch/{id}")
	  @ResponseBody
	  public EmployeeExperence fetchEmployeeAddress(@PathVariable("id") Integer id)
	  {
		 EmployeeExperence employee=employeeExperenceService.fetchEmployee(id);
		 employee.setEmployee(null);
		return employee;
		  
	  }
	 
	 @RequestMapping("/delete/{id}")
	  @ResponseBody
	  public String deleteEmployee(@PathVariable("id") Integer id)
	  {
		 String str= employeeExperenceService.deleteEmployeeExperence(id);
		return str;
		  
	  }
	
}
