package com.adjecti.invoicing.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.adjecti.invoicing.dto.ClientDto;
import com.adjecti.invoicing.dto.ClientPurchaseOrderItemDto;
import com.adjecti.invoicing.dto.InvoiceDto;
import com.adjecti.invoicing.dto.PaymentModeDto;
import com.adjecti.invoicing.dto.PurchaseOrderDto;
import com.adjecti.invoicing.dto.RecievePaymentDto;
import com.adjecti.invoicing.model.ClientPurchaseOrderItem;
import com.adjecti.invoicing.model.InvoiceItem;
import com.adjecti.invoicing.model.PurchaseOrder;
import com.adjecti.invoicing.service.ClientPurchaseOrderItemSerice;
import com.adjecti.invoicing.service.ClientService;
import com.adjecti.invoicing.service.CurrencyService;
import com.adjecti.invoicing.service.InvoiceService;
import com.adjecti.invoicing.service.PaymentModeService;
import com.adjecti.invoicing.service.PurchaseOrderService;

@Controller
@RequestMapping("/invoice")
public class InvoiceController {

	@Value("${invoice.number.format}")
	String invoiceNoFormat;

	@Autowired
	private ClientService clientService;
	
	@Autowired
	private PaymentModeService paymentmodeservice;

	@Autowired
	private InvoiceService invoiceService;

	@Autowired
	private PurchaseOrderService purchaseOrderService;

	@Autowired
	private ClientPurchaseOrderItemSerice clientPurchaseOrderItemSerice;

	@Autowired
	private CurrencyService currencyService;


	@GetMapping("/list")
	public String invoiceList(Model model, @ModelAttribute("msg") String msg) {	
		return "invoice-list";
	}

	@GetMapping("/load")
	@ResponseBody
	public List<InvoiceDto> listInvoices() {
		
		List<InvoiceDto> list = invoiceService.findAll();
		
		List<InvoiceDto> tempList = new ArrayList<>(); 
		for(InvoiceDto tempInvoiceDto:list) {
			tempInvoiceDto.getClient().setTax(null);
			tempInvoiceDto.getClient().setPurchaseOrders(null);
			tempInvoiceDto.getClient().setAddress(null);
			tempInvoiceDto.getClient().setCompany(null);
			tempInvoiceDto.getPurchaseOrder().setClientPurchaseOrderItem(null);
			tempInvoiceDto.getPurchaseOrder().setProject(null);
			tempInvoiceDto.getPurchaseOrder().setClient(null);
			tempInvoiceDto.getPurchaseOrder().setBillingType(null);
			tempInvoiceDto.getPurchaseOrder().setBillingAddress(null);
			tempInvoiceDto.getPurchaseOrder().setBillingCycle(null);
			tempInvoiceDto.setInvoiceItems(null);
			tempInvoiceDto.getTaxItems().forEach(taxItem -> taxItem.setTax(null) );
			tempList.add(tempInvoiceDto);
		}
		return tempList;
	}
	
	@GetMapping("/print")
	public String printInvoice(@RequestParam("invoiceId") int theInvoiceId,Model model) {

		
		model.addAttribute("invoice", invoiceService.findById(theInvoiceId));
		return "print-invoice";
	}
	
	@GetMapping("/view")
	public String viewInvoice(@RequestParam("invoiceId") int theInvoiceId,Model model) {

		
		model.addAttribute("invoice", invoiceService.findById(theInvoiceId));
		return "view-invoice";
	}
	
	
	@GetMapping("/new")
	public String newInvoice(Model model) {

		InvoiceDto invoice = new InvoiceDto();
		model.addAttribute("invoice", invoice);
		model.addAttribute("clients", clientService.getClients());
		model.addAttribute("currency", currencyService.findAll());
		return "invoice";
	}

	@RequestMapping(value = "/save", method = { RequestMethod.GET, RequestMethod.POST }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public InvoiceResponse saveOrUpdateInvoice(@ModelAttribute InvoiceDto theInvoice, RedirectAttributes redirectAttributes) {
		System.out.println(theInvoice);

		InvoiceResponse invoiceResponse = null;
		if (theInvoice.getId() > 0) {
			theInvoice = invoiceService.save(theInvoice);
			/*
			 * theInvoice.getClient().setPurchaseOrders(null);
			 * theInvoice.getClient().setTax(null);
			 * theInvoice.getPurchaseOrder().setClient(null);
			 * theInvoice.getPurchaseOrder().setClientPurchaseOrderItem(null);
			 * theInvoice.setInvoiceItems(null); theInvoice.setTaxItems(null);
			 */
			invoiceResponse = new InvoiceResponse("Sucessfully Updated Invoice.");

		} else {
			theInvoice.setEnabled(1);
			theInvoice.setCreatedDate(new Date());
			theInvoice = invoiceService.save(theInvoice);
			theInvoice.setInvoiceNo(invoiceNoFormat + theInvoice.getId());
			theInvoice.setSerialNo(theInvoice.getId());
			theInvoice = invoiceService.save(theInvoice);
			/*
			 * theInvoice.setClient(null); theInvoice.setTaxItems(null);
			 * theInvoice.setPurchaseOrder(null); theInvoice.setInvoiceItems(null);
			 */
			/*
			 * theInvoice.getClient().setPurchaseOrders(null);
			 * theInvoice.getClient().setTax(null);
			 * theInvoice.getPurchaseOrder().setClient(null);
			 * theInvoice.getPurchaseOrder().setClientPurchaseOrderItem(null);
			 * theInvoice.setInvoiceItems(null); theInvoice.setTaxItems(null);
			 */
			invoiceResponse = new InvoiceResponse("Sucessfully Created Invoice.");
		}

		return invoiceResponse;
	}

	@GetMapping("/delete")
	@ResponseBody
	public InvoiceResponse deleteInvoice(@RequestParam("invoiceId") int theId) {
		System.out.println(theId);
		invoiceService.delete(theId);

		return new InvoiceResponse("sucessfully Deleted Invoice.");
	}
	
	@GetMapping("/cancel")
	@ResponseBody
	public InvoiceResponse cancelInvoice(@RequestParam("invoiceId") int theId) {
		System.out.println(theId);
		InvoiceDto tempInvoiceDto = invoiceService.findById(theId);
		tempInvoiceDto.setCancelled(1);
		tempInvoiceDto.setEnabled(0);
		invoiceService.save(tempInvoiceDto);

		return new InvoiceResponse("Sucessfully Cancelled Invoice.");
	}
	
	@GetMapping("/copy")
	public String copyInvoice(@RequestParam("invoiceId") int theInvoiceId, Model model) {
		System.out.println(theInvoiceId);

		InvoiceDto invoiceDto = invoiceService.findById(theInvoiceId);
		int clientId = invoiceDto.getClient().getId();
		int purchaseOrderId = invoiceDto.getPurchaseOrder().getId();
		ClientDto client = clientService.getClient(clientId);
		List<PurchaseOrder> purchaseOrders = client.getPurchaseOrders();

		PurchaseOrderDto purchaseOrder = purchaseOrderService.getPurchaseOrder(purchaseOrderId);
		List<ClientPurchaseOrderItem> clientPurchaseOrderItem = purchaseOrder.getClientPurchaseOrderItem();
		List<InvoiceItem> invoiceItems = invoiceDto.getInvoiceItems();
		List<Integer> list = new ArrayList<>();
		for (InvoiceItem tempInvoiceItem : invoiceItems) {
			list.add(tempInvoiceItem.getClientPurchaseOrderItem().getId());
		}
		int size = invoiceItems.size();
		model.addAttribute("invoice", invoiceDto);
		model.addAttribute("clients", clientService.getClients());
		model.addAttribute("purchaseOrders", purchaseOrders);
		model.addAttribute("clientPOItems", clientPurchaseOrderItem);
		model.addAttribute("rowsize", size);
		model.addAttribute("clientpoids", list);
		model.addAttribute("currency", currencyService.findAll());

		return "invoice";
	}

	@GetMapping("/update")
	public String editInvoice(@RequestParam("invoiceId") int theInvoiceId, Model model,
			RedirectAttributes redirectAttributes) {
		System.out.println(theInvoiceId);

		InvoiceDto invoiceDto = invoiceService.findById(theInvoiceId);
		int clientId = invoiceDto.getClient().getId();
		int purchaseOrderId = invoiceDto.getPurchaseOrder().getId();
		ClientDto client = clientService.getClient(clientId);
		List<PurchaseOrder> purchaseOrders = client.getPurchaseOrders();

		PurchaseOrderDto purchaseOrder = purchaseOrderService.getPurchaseOrder(purchaseOrderId);
		List<ClientPurchaseOrderItem> clientPurchaseOrderItem = purchaseOrder.getClientPurchaseOrderItem();
		List<InvoiceItem> invoiceItems = invoiceDto.getInvoiceItems();
		List<Integer> list = new ArrayList<>();
		for (InvoiceItem tempInvoiceItem : invoiceItems) {
			list.add(tempInvoiceItem.getClientPurchaseOrderItem().getId());
		}
		int size = invoiceItems.size();
		model.addAttribute("invoice", invoiceDto);
		model.addAttribute("clients", clientService.getClients());
		model.addAttribute("purchaseOrders", purchaseOrders);
		model.addAttribute("clientPOItems", clientPurchaseOrderItem);
		model.addAttribute("rowsize", size);
		model.addAttribute("clientpoids", list);
		model.addAttribute("currency", currencyService.findAll());

		return "invoice";
	}

	@GetMapping(value = "/getClientPurchaseOrder", produces = "application/json")
	public @ResponseBody ClientDto findClientPurchaseOrderById(@RequestParam(value = "clientId") int id) {
		ClientDto client = clientService.getClient(id);

		List<PurchaseOrder> purchaseOrders = client.getPurchaseOrders();
		List<PurchaseOrder> purchOrders = new ArrayList<>();
		for (PurchaseOrder purchaseOrder : purchaseOrders) {
			purchaseOrder.setClient(null);
			purchaseOrder.setClientPurchaseOrderItem(null);
			purchaseOrder.setProject(null);
			// purchaseOrder.setInvoices(null);
			purchOrders.add(purchaseOrder);
		}
		client.setPurchaseOrders(purchOrders);
		System.out.println("Printing the client obj " + client.getPurchaseOrders());
		return client;
	}

	@GetMapping(value = "/getClientPurchaseOrderItems", produces = "application/json")
	public @ResponseBody PurchaseOrderDto findClientPurchaseOrderItemsById(
			@RequestParam(value = "purchaseOrderId") int id) {

		PurchaseOrderDto purchaseOrder = purchaseOrderService.getPurchaseOrder(id);
		purchaseOrder.setClient(null);
		//purchaseOrder.setInvoices(null);

		List<ClientPurchaseOrderItem> clientPurchaseOrderItems = purchaseOrder.getClientPurchaseOrderItem();

		List<ClientPurchaseOrderItem> tempClientPurchaseOrderItems = new ArrayList<>();
		for (ClientPurchaseOrderItem clientPurchaseOrderItem : clientPurchaseOrderItems) {
			clientPurchaseOrderItem.setPurchaseOrder(null);
			// clientPurchaseOrderItem.setInvoiceItems(null);
			tempClientPurchaseOrderItems.add(clientPurchaseOrderItem);
		}
		purchaseOrder.setClientPurchaseOrderItem(tempClientPurchaseOrderItems);
		System.out.println("Printing the client obj " + purchaseOrder.getClientPurchaseOrderItem());
		return purchaseOrder;
	}

	@GetMapping(value = "/getClientPurchaseOrderItem", produces = "application/json")
	public @ResponseBody ClientPurchaseOrderItemDto findClientPurchaseOrderItemById(
			@RequestParam(value = "ClientPurchaseOrderItemId") int id) {
		ClientPurchaseOrderItemDto allCLientPoItem = clientPurchaseOrderItemSerice.getAllCLientPoItem(id);
		allCLientPoItem.setPurchaseOrder(null);
		return allCLientPoItem;
	}

	private class InvoiceResponse {
		private String msg;

		public InvoiceResponse() {
		}

		public InvoiceResponse(String msg) {
			super();
			this.msg = msg;
		}

		public String getMsg() {
			return msg;
		}

		public void setMsg(String msg) {
			this.msg = msg;
		}

	}
}
