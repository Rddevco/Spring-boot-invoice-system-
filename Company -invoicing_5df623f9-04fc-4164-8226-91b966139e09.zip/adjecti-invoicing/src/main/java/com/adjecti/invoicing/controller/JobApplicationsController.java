
package com.adjecti.invoicing.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.adjecti.invoicing.dto.JobApplicationsDto;
import com.adjecti.invoicing.dto.JobOpeningDto;

import com.adjecti.invoicing.service.JobApplicationsService;
import com.adjecti.invoicing.service.JobOpeningService;

@Controller
@RequestMapping("/JobApplications")
public class JobApplicationsController {
	@Autowired
	private JobOpeningService jobopeningservice;

	@Autowired
	private JobApplicationsService jobapplicationsservice;

	@RequestMapping("/list")
	public String getJobApplicationList(Model model) {
		List<JobApplicationsDto> jobapplications = jobapplicationsservice.getJobApplications();
		model.addAttribute("JobApplications", jobapplications);
		return "jobapplications-list";
	}

	@GetMapping("/jlist")
	@ResponseBody
	public List<JobApplicationsDto> JJobApplicationsList() {
		List<JobApplicationsDto> jobapplications = jobapplicationsservice.getJobApplications();
      System.out.println(jobapplications);
		return jobapplications;
	}

	@RequestMapping("/new")
	public String getNewJobApplications(Model model) {

		List<JobApplicationsDto> jobapplicationsdto = jobapplicationsservice.getJobApplications();
		List<JobOpeningDto> jobopeningdto = jobopeningservice.getJobOpening();
		model.addAttribute("jobopening", jobopeningdto);
		model.addAttribute("jobapplication", jobapplicationsdto);
		model.addAttribute("jobapplication", new JobApplicationsDto());
		return "jobapplications-form";
	}

	@RequestMapping("/delete/{id}")
	@ResponseBody
	public JobApplicationsResponse delete(@PathVariable("id") int id) {
		jobapplicationsservice.delete(id);
		return new JobApplicationsResponse(null, "Sucessfully Deleted JobApplications...");
	}

	@RequestMapping(value = "/add", method = { RequestMethod.GET, RequestMethod.POST }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public JobApplicationsResponse saveJobApplications(
			@Valid @ModelAttribute("jobapplication") JobApplicationsDto jobapplicationsdto, BindingResult result) {

		JobApplicationsResponse jobapplicationsresponse = new JobApplicationsResponse();
		jobapplicationsservice.save(jobapplicationsdto);
		if (jobapplicationsdto.getId() > 0) {

			return new JobApplicationsResponse(null, "Sucessfully Updated JobApplications...");
		} else {
			return new JobApplicationsResponse(null, "Sucessfully Saved JobApplications...");
		}
	}

	@RequestMapping("/update/{id}")
	public String jobOpeningUpdate(@PathVariable("id") int id, Model model) {

		List<JobOpeningDto> jobopening = jobopeningservice.getJobOpening();

		model.addAttribute("jobopening", jobopening);

		JobApplicationsDto jobapplicationsdto = jobapplicationsservice.getJobApplications(id);
		model.addAttribute("jobapplication", jobapplicationsdto);
		return "jobapplications-form";
	}

	@RequestMapping("/addJobApplications")
	public String addJobApplications(@RequestParam("id") int id, Model model) {
		System.out.println(id);
		List<JobOpeningDto> jobopening = jobopeningservice.getJobOpening();
		model.addAttribute("jobopening", jobopening);

		return "jobapplications-form";
	}

	private class JobApplicationsResponse {
		private JobApplicationsDto jobapplicationsDto;
		private String msg;

		public JobApplicationsResponse() {

		}

		public JobApplicationsResponse(JobApplicationsDto jobapplicationsDto, String msg) {

			this.jobapplicationsDto = jobapplicationsDto;
			this.msg = msg;
		}

		public JobApplicationsDto getJobApplicationsDto() {
			return jobapplicationsDto;
		}

		public void setJobApplicationsDto(JobApplicationsDto jobapplicationsDto) {
			this.jobapplicationsDto = jobapplicationsDto;
		}

		public String getMsg() {
			return msg;
		}

		public void setMsg(String msg) {
			this.msg = msg;
		}

	}

}
