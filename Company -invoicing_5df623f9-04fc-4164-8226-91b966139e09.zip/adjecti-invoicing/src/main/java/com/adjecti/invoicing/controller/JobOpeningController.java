
package com.adjecti.invoicing.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.adjecti.invoicing.dto.JobOpeningDto;

import com.adjecti.invoicing.service.JobOpeningService;

@Controller
@RequestMapping("/JobOpening")
public class JobOpeningController {
	@Autowired
	private JobOpeningService jobopeningservice;

	@RequestMapping("/list")
	public String getJobOpening(Model model) {
		List<JobOpeningDto> jobopening = jobopeningservice.getJobOpening();
		model.addAttribute("jobopening", jobopening);
		return "jobopening-list";
	}

	@GetMapping("/jlist")
	@ResponseBody
	public List<JobOpeningDto> JJobOpeningList() {
		List<JobOpeningDto> jobopening = jobopeningservice.getJobOpening();

		return jobopening;
	}

	@RequestMapping("/new")
	public String getNewJobOpening(Model model) {

		List<JobOpeningDto> jobopeningdto = jobopeningservice.getJobOpening();
		model.addAttribute("jobopening", jobopeningdto);

		model.addAttribute("jobopening", new JobOpeningDto());
		return "jobopening-form";
	}

	@RequestMapping("/delete/{id}")
	@ResponseBody
	public JobOpeningResponse delete(@PathVariable("id") int id) {
		jobopeningservice.delete(id);
		return new JobOpeningResponse(null, "Sucessfully Deleted JobOpening...");
	}

	@RequestMapping(value = "/add", method = { RequestMethod.GET, RequestMethod.POST }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public JobOpeningResponse saveJobOpening(@Valid @ModelAttribute("jobopening") JobOpeningDto jobopeningdto,
			BindingResult result) {

		JobOpeningResponse jobopeningresponse = new JobOpeningResponse();
		jobopeningservice.save(jobopeningdto);
		if (jobopeningdto.getId() > 0) {

			return new JobOpeningResponse(null, "Sucessfully Updated JobOpening...");
		} else {
			return new JobOpeningResponse(null, "Sucessfully Saved JobOpening...");
		}
	}

	@RequestMapping("/update/{id}")
	public String jobOpeningUpdate(@PathVariable("id") int id, Model model) {

		JobOpeningDto jobopeningdto = jobopeningservice.getJobOpening(id);
		model.addAttribute("jobopening", jobopeningdto);
		return "jobopening-form";
	}

	@RequestMapping("/addjobopening")
	public String addJobOpening(@RequestParam("id") int id, Model model) {
		System.out.println(id);
		List<JobOpeningDto> jobopening = jobopeningservice.getJobOpening();
		model.addAttribute("jobopening", jobopening);

		return "jobopening-form";
	}

	// @RequestMapping("/updateproject")
	// @Transactional
	// public String updateProject(@Valid @ModelAttribute("consultantpayment")
	// ConsultantPaymentDto consultantpaymentdto,BindingResult result) {

	// consultantpaymentservice.save(consultantpaymentdto);

	// return "redirect:/ConsultantPayment/list";
	// }

	private class JobOpeningResponse {
		private JobOpeningDto jobopeningDto;
		private String msg;

		public JobOpeningResponse() {

		}

		public JobOpeningResponse(JobOpeningDto jobopeningDto, String msg) {

			this.jobopeningDto = jobopeningDto;
			this.msg = msg;
		}

		public JobOpeningDto getJobOpeningDto() {
			return jobopeningDto;
		}

		public void setJobOpeningDto(JobOpeningDto jobopeningDto) {
			this.jobopeningDto = jobopeningDto;
		}

		public String getMsg() {
			return msg;
		}

		public void setMsg(String msg) {
			this.msg = msg;
		}

	}

}
