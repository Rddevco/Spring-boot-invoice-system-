package com.adjecti.invoicing.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.adjecti.invoicing.model.CostToCompanySalary;
import com.adjecti.invoicing.model.Employee;
import com.adjecti.invoicing.model.Leave;
import com.adjecti.invoicing.model.Response;
import com.adjecti.invoicing.service.LeaveService;

@Controller
@RequestMapping("/leave")
public class LeaveController {

	@Autowired
	LeaveService leaveService;
	@GetMapping("/showleave/{id}")
	public String showLeave(@PathVariable("id") Integer eid,Model model)
	{ 		model.addAttribute("eid",eid);
	System.out.println("EID Is  "+eid);
		Leave leave=new Leave();
		model.addAttribute("leave", leave);
		return "leave";
		
	}
	

	@PostMapping("/saveleave")
	@ResponseBody
	public ResponseEntity<?> saveLeave(@Valid @ModelAttribute Leave leave,BindingResult result)
	{
		System.out.println("Inside Save  Leave");
		 List<Response> responseList=new ArrayList<>();
			if(result.hasErrors()) {
			System.out.println("inside binding result");
			List<FieldError> fieldErrors = result.getFieldErrors();
			for(FieldError temp:fieldErrors) {
				System.out.println(temp.getField()+"  "+temp.getDefaultMessage());
				 responseList.add(new Response(temp.getField(),temp.getDefaultMessage(),null));
			}
			return new ResponseEntity<>(responseList,HttpStatus.BAD_REQUEST);
		}
        Response response=new  Response();
        response.setStatusMessage("COst To Company Save Successfully");
        Leave leave2 = leaveService.saveLeave(leave);
	return new ResponseEntity<>(response,HttpStatus.OK);
	}

	@RequestMapping("/list/{eid}")
	@ResponseBody
	public List<Leave> getLeaveList(@PathVariable("eid") Integer eid)
	{
		List<Leave> list=leaveService.getLeaves(eid);
		for(Leave leave:list)
		{
			leave.setEmployee_id(null);
		}
		return list;
		
	}

	 @RequestMapping("/delete/{id}")
	  @ResponseBody
	  public String deleteLeave(@PathVariable("id") Integer id)
	  {
		 String str= leaveService.deleteEmployee(id);
		return str;
		  
	  }
	  
	  @RequestMapping("/fetch/{id}")
	  @ResponseBody
	  public Leave fetchLeave(@PathVariable("id") Integer id)
	  {
		  Leave leave= leaveService.fetchEmployee(id);
		  
		return leave;
		  
	  }
	
}

