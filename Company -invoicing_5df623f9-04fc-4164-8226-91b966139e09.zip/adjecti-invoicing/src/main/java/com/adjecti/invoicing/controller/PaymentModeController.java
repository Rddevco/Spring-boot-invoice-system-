package com.adjecti.invoicing.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adjecti.invoicing.dto.PaymentModeDto;
import com.adjecti.invoicing.model.PaymentMode;
import com.adjecti.invoicing.service.BillingTypeService;
import com.adjecti.invoicing.service.PaymentModeService;

@RestController
@RequestMapping("/paymentmode")
public class PaymentModeController {

	@Autowired
	private PaymentModeService paymantmodeService;
	
	
	@GetMapping("/list")
	public ResponseEntity<List<PaymentModeDto>> getList() {
		return new ResponseEntity<List<PaymentModeDto>>(paymantmodeService.getAllPayment(), HttpStatus.OK);
	}

	@GetMapping("/paymentMode/{id}")
	public ResponseEntity<PaymentModeDto> getPaymenMode(@PathVariable Integer id) {
		return new ResponseEntity<PaymentModeDto>(paymantmodeService.findById(id), HttpStatus.OK);
	}

	@PostMapping("/save")
	public ResponseEntity<PaymentModeDto> saveOrUpdatePaymentMode(@Valid @RequestBody @ModelAttribute("paymentmode") PaymentModeDto paymentdto) {
	
		return new ResponseEntity<PaymentModeDto>(paymantmodeService.save(paymentdto),HttpStatus.OK);
	}

	@GetMapping("/delete/{id}")

	public ResponseEntity<Void> delete(@PathVariable String id) {
		System.out.println(id);
		paymantmodeService.delete(Integer.parseInt(id));
		return new ResponseEntity<Void>(HttpStatus.OK);
	}

}
