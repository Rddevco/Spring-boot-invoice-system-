package com.adjecti.invoicing.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import com.adjecti.invoicing.dto.ClientDto;
import com.adjecti.invoicing.dto.PurchaseOrderDto;
import com.adjecti.invoicing.model.ClientPurchaseOrderItem;
import com.adjecti.invoicing.model.Project;
import com.adjecti.invoicing.response.Response;
import com.adjecti.invoicing.security.PurchaseOrderValidator;
import com.adjecti.invoicing.service.BillingCycleService;
import com.adjecti.invoicing.service.BillingTypeService;
import com.adjecti.invoicing.service.ClientService;
import com.adjecti.invoicing.service.CurrencyService;
import com.adjecti.invoicing.service.PurchaseOrderService;

@Controller
@RequestMapping("/purchaseorder")
public class PurchaseOrderController {

	@Autowired
	private PurchaseOrderService purchaseOrderService ;

	@Autowired
	private ClientService clientService;

	@Autowired
	private BillingCycleService billingCycleService;

	@Autowired
	private BillingTypeService billingTypeService;

	@Autowired
	private CurrencyService currencyService;

	/*
	 * @Autowired private PurchaseOrderValidator purchaseOrderValidator;
	 */
	@GetMapping("/new")
	public String loadPurchaseOrder(Model theModel) {

		theModel.addAttribute("billingCycle", billingCycleService.getAllBillingCycle());
		theModel.addAttribute("billingType", billingTypeService.findAll());
		theModel.addAttribute("currencyList", currencyService.findAll());
		theModel.addAttribute("clients", clientService.getClients());
		theModel.addAttribute("purchaseOrder", new PurchaseOrderDto());
		return "purchaseorder";
	}

	@GetMapping("/list")
	public String purchaseOrderList(Model theModel, @ModelAttribute("msg") String msg) {
		theModel.addAttribute("msg", msg);

		return "purchase-order-list";
	}

	@GetMapping("/load")
	public @ResponseBody List<PurchaseOrderDto> loadPurchaseOrderList() {

		List<PurchaseOrderDto> purchaseOrderList = purchaseOrderService.getAllPurchaseOrder();
		List<PurchaseOrderDto> tempPurchaseOrder=new ArrayList<>() ;
		for(PurchaseOrderDto temp:purchaseOrderList ) {
			temp.setClientPurchaseOrderItem(null);
			temp.setBillingCycle(null);
			temp.setBillingType(null);
			temp.getClient().setPurchaseOrders(null);
			temp.getClient().setCompany(null);
			temp.getClient().setContact(null);
			temp.getClient().setAddress(null);
			temp.getClient().setTax(null);
			
			System.out.println();
			tempPurchaseOrder.add(temp);
		}
		return tempPurchaseOrder;
	}

	@PostMapping("/save")
	public @ResponseBody ResponseEntity<?> saveOrUpdatePurchaseOrder(@Valid @ModelAttribute PurchaseOrderDto purchaseOrderDto,
			BindingResult bindingResult,RedirectAttributes redirectAttributes) {

		/* purchaseOrderValidator.validate(purchaseOrderDto, bindingResult); */
		Response response=new Response();
		response.setStatusMessage("Record Added");
		//int pid=purchaseOrderDto.getId();
		if(purchaseOrderDto.getId()>0) {

			response.setStatusMessage("Record Updated");
			/*
			 * List<ClientPurchaseOrderItem> clientPurchaseOrderItem =
			 * purchaseOrderDto.getClientPurchaseOrderItem();
			 * clientPurchaseOrderItem.forEach(a->System.out.println(a.getPurchaseOrder()));
			 */
		}


		List<Response> responseList = new ArrayList<>();

		if (bindingResult.hasErrors()) {
			System.out.println("inside binding result");
			List<FieldError> fieldErrors = bindingResult.getFieldErrors();
			for (FieldError temp : fieldErrors) {
				System.out.println(temp.getField() + "  " + temp.getDefaultMessage());
				responseList.add(new Response(temp.getField(), temp.getDefaultMessage(), null));
			}

			return new ResponseEntity<>(responseList, HttpStatus.BAD_REQUEST);
		}
		

		purchaseOrderService.save(purchaseOrderDto);

		
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@GetMapping("/update")
	public String editPurchaseOrder(@RequestParam("poId") int id,Model theModel) {

		PurchaseOrderDto purchaseOrder = purchaseOrderService.getPurchaseOrder(id);
		int size = purchaseOrder.getClientPurchaseOrderItem().size();
		if(size==0)
			size=1;
		theModel.addAttribute("purchaseOrder",purchaseOrder);
		theModel.addAttribute("billingCycle", billingCycleService.getAllBillingCycle());
		theModel.addAttribute("billingType", billingTypeService.findAll());
		theModel.addAttribute("currencyList", currencyService.findAll());
		theModel.addAttribute("clients",clientService.getClients());
		theModel.addAttribute("updateform","update");
		theModel.addAttribute("rowSize", size);
		System.out.println(size);
		return "purchaseorder";
	}

	@GetMapping("/delete")
	public @ResponseBody String deletePurchaseOrder(@ModelAttribute("poid") int id) {

		purchaseOrderService.deletePurchaseOrder(id);		
		return "Record deleted";
	}	
}