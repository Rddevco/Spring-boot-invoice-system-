package com.adjecti.invoicing.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/salary")
public class Salary {

	@RequestMapping("importsalary")
	public String importSalary()
	{
		return "importsalary";
		
	}
}
