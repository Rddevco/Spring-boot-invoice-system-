package com.adjecti.invoicing.controller;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.adjecti.invoicing.model.CostToCompanySalary;
import com.adjecti.invoicing.model.LoadSalary;
import com.adjecti.invoicing.model.Salary;
import com.adjecti.invoicing.service.SalaryService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
@RequestMapping("/salary")
public class SalaryController {

	@Autowired
	SalaryService salaryService;

	@GetMapping("/import")
	public String importSalary(Model model) {
		System.out.println("import salary Method");
		model.addAttribute("loadSalary", new LoadSalary());
		return "importsalary";

	}

	@GetMapping("/jlist")
	@ResponseBody
	public List<Salary> JProjectList() {
		List<Salary> salary=salaryService.get();
		
		
		return salary;
	}
	

	@RequestMapping(value = "/upload", method = RequestMethod.POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public String uploadsalary(@ModelAttribute LoadSalary loadSalary) throws Exception {
		// System.out.println("File is" + loadSalary.getfile().getOriginalFilename());
		System.out.println("Upload Salary ");
	salaryService.upload(loadSalary.getfile());
		return "salarylist";
	}

	@GetMapping("/list")
	public String listOfSalary(Model model) {
		
		return "salarylist";

	}

	@GetMapping("/structureSalaryform")
	public String structureSalary(@RequestParam String salary,Model  model) {
		System.out.println("Salary  Without jsJson "+salary);
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			Salary salary1 = objectMapper.readValue(salary, Salary.class);
			System.out.println("printing the salary json convert"+ salary1);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Salary "+salary);
		return "structureSalaryform";

	}
	
	@GetMapping("/costtocompany")
	public String costToCompany(Model model) {
		CostToCompanySalary costToCompanySalary=new CostToCompanySalary();
model.addAttribute("costtocompanysalary", costToCompanySalary);
		return "costtocompany";

	}
	
	
	/*
	 * @GetMapping("/structure") public String structure(Model model) {
	 * StructueSalary structueSalary = new StructueSalary(); SalaryStructure
	 * structureForm=new SalaryStructure(); model.addAttribute("structureForm",
	 * structureForm); model.addAttribute("structueSalary", structueSalary); return
	 * "structure";
	 * 
	 * }
	 */
 
	
	@GetMapping("/structureform")
	public String structureForm(Model  model) {
		System.out.println("Structure Form");
		return "structureform";

	}
	
	
	 @GetMapping("/fetch/{idNo}")
	 public @ResponseBody Salary	  fetchSalary(@PathVariable("idNo") Integer idNo) {
	  System.out.println("Edit Salary Controller "); Salary salary =
	  salaryService.getSalaryById(idNo);
	  
	  return salary; }
	 
	 @GetMapping("/fetchh/{idNo}")
	 public String	 fetchhSalary(@PathVariable("idNo") Integer idNo,Model model) throws ParseException {
	  System.out.println("Edit Salary Controller "); Salary salary =
	  salaryService.getSalaryById(idNo);
	  model.addAttribute("salary",salary);
	  System.out.println(salary.getProcessingMonth());
	  String processingMonth = salary.getProcessingMonth();
	  Date date1=new SimpleDateFormat("dd-MMM-yyyy").parse(processingMonth);
	  System.out.println(date1);
	 
	  Instant instant = date1.toInstant(); 
	  ZonedDateTime zdt = instant.atZone(ZoneId.systemDefault());
	  LocalDate date = zdt.toLocalDate();
      System.out.println("date : "+date.getYear()+"month  "+date.getMonth());
	  
	 model.addAttribute("month", date.getMonth());
	 model.addAttribute("year",date.getYear());

	  return "printsalary"; }
	/*
	 * @PostMapping("/updateStructureSalary") public String
	 * updateSalary(@ModelAttribute SalaryStructure salaryStructue) {
	 * System.out.println("Update Salary Page");
	 * System.out.println(salaryStructue.getId()); Salary salary=
	 * salaryService.ForUpdateStructureSalary(salaryStructue.getId(),salaryStructue)
	 * ; return "redirect:/salary/structure"; }
	 */
	 
	/*
	 * @PostMapping("/updateCostToCompany")
	 * 
	 * @ResponseBody public ResponseEntity<?>
	 * updateCostToCompany(@Valid @ModelAttribute CostToCompanySalary
	 * costtocompanysalary,BindingResult result,Model model) {
	 * model.addAttribute("costtocompanysalary",new CostToCompanySalary());
	 * System.out.println("Update Salary Page");
	 * System.out.println(costtocompanysalary.getIdNo()); List<Response>
	 * responseList=new ArrayList<>();
	 * 
	 * if(result.hasErrors()) { System.out.println("inside binding result");
	 * List<FieldError> fieldErrors = result.getFieldErrors(); for(FieldError
	 * temp:fieldErrors) {
	 * System.out.println(temp.getField()+"  "+temp.getDefaultMessage());
	 * responseList.add(new
	 * Response(temp.getField(),temp.getDefaultMessage(),null)); } return new
	 * ResponseEntity<>(responseList,HttpStatus.BAD_REQUEST); } Response
	 * response=new Response();
	 * response.setStatusMessage("COst To Company Save Successfully"); Salary
	 * salary= salaryService.ForUpdateCostToCompanySalary(costtocompanysalary);
	 * return new ResponseEntity<>(response,HttpStatus.OK); }
	 */
	@RequestMapping("/delete/{idNo}")
	public @ResponseBody String  softdelete(@PathVariable("idNo") Integer idNo ) {
		System.out.println("Soft Delete Successully....."+idNo);
		String data = salaryService.getSalaryByIdForDelete(idNo);
		String value="";
		if(data.equals("Delete Is Successfully Done."))
		{
			value="Successfully Deleted";
        System.out.print(data);
		}else {
			value="Not Deleted .";
		}
        return value;
	}
	
}