package com.adjecti.invoicing.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.adjecti.invoicing.model.Response;
import com.adjecti.invoicing.model.SalaryHead;
import com.adjecti.invoicing.model.SalaryStructure;
import com.adjecti.invoicing.service.SalaryHeadService;

@Controller
@RequestMapping("/salaryhead")
public class SalaryHeadController {
	
	
	
	@Autowired
	SalaryHeadService   salaryHeadService;
	
	@GetMapping("/salaryhead")
	public String salaryhead(Model model)
	{
		model.addAttribute("salaryHead", new SalaryHead());
		return "salaryhead";
	}	
	
	
	@PostMapping("/save")
	@ResponseBody
	public ResponseEntity<?> save(@Valid @ModelAttribute SalaryHead salaryHead,BindingResult br,Model model)
	{
		
		System.out.println("Response Save Method Data ");
	List<Response> responseList=new ArrayList<Response>();
	if(br.hasErrors())
	{
		List<FieldError> fieldErrors = br.getFieldErrors();
		for(FieldError temp:fieldErrors) {
			System.out.println(temp.getField()+"  "+temp.getDefaultMessage());
			 responseList.add(new Response(temp.getField(),temp.getDefaultMessage(),null));
		}
		return new ResponseEntity<>(responseList,HttpStatus.BAD_REQUEST);
	}
	    Response response=new Response();
	    String save = salaryHeadService.save(salaryHead);
	    response.setStatusMessage("Salary Head Save Successfully");
		return new ResponseEntity<>(responseList,HttpStatus.OK);
		
	}	
	
	@GetMapping("/fetch/{id}")
	public @ResponseBody SalaryHead fetchSalary(@PathVariable("id") Integer id)
	{
		System.out.println("Edit Salary Controller ");
		SalaryHead salary = salaryHeadService.getSalaryById(id);
			System.out.println(salary);
		return salary;
	}
	
	
	
	@GetMapping("/fetchAll")
	@ResponseBody
	public List<SalaryHead> fechAll()
	{
		List<SalaryHead> fetchAll = salaryHeadService.fetchAll();
		return fetchAll;
	}	


	@RequestMapping("/delete/{id}")
	public  String  softdelete(@PathVariable("id") Integer id ) {
		System.out.println("Soft Delete Successully....."+id);
		String data = salaryHeadService.delete(id);
		String value="";
		if(data.equals("Delete Is Successfully Done."))
		{
        System.out.println("Successfully Deleted");
        System.out.print(data);
		}else {
			System.out.println("Not Deleted");
		}
		return "redirect:/salaryhead/salaryhead";
	}


}
