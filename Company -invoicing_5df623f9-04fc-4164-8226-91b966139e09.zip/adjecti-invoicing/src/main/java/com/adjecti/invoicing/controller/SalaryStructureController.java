package com.adjecti.invoicing.controller;
import java.util.ArrayList;
import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.adjecti.invoicing.model.Response;
import com.adjecti.invoicing.model.SalaryStructure;
import com.adjecti.invoicing.service.SalaryStructureService;
@Controller
@RequestMapping("/salaryStructure")
public class SalaryStructureController {
	@Autowired(required = true)
	SalaryStructureService salaryStructureService;
	
	@PostMapping("/save")
	@ResponseBody
	public ResponseEntity<?> saveNewStructure(@Valid @ModelAttribute SalaryStructure salaryStructure,BindingResult br,Model model)
	{
		System.out.println("Save New Structure");
		System.out.println(salaryStructure);
		List<Response> responseList=new ArrayList<>();
		if(br.hasErrors())
		{ 
		 List<FieldError> fieldErrors = br.getFieldErrors();
		    
			System.out.println("I am inside  SalaryStructure Error.");
			for(FieldError temp:fieldErrors) {
				System.out.println(temp.getField()+"  "+temp.getDefaultMessage());
				 responseList.add(new Response(temp.getField(),temp.getDefaultMessage(),null));
			}
			return new ResponseEntity<>(responseList,HttpStatus.BAD_REQUEST);
		}
		Response response=new Response();
		response.setStatusMessage("Salary is save successfully.");
		salaryStructureService.save(salaryStructure);	
		
		return new ResponseEntity<>(response,HttpStatus.OK);
	}
	

	@GetMapping("/fetch/{id}")
	public @ResponseBody SalaryStructure fetchSalary(@PathVariable("id") Integer id)
	{
		System.out.println("Edit Salary Controller ");
		SalaryStructure salary = salaryStructureService.getSalaryById(id);
			
		return salary;
	}


	@RequestMapping(value = "/structure",method = { RequestMethod.GET,RequestMethod.POST})
	public String structure(Model model) {
		 SalaryStructure salaryStructue = new SalaryStructure();
		 model.addAttribute("salaryStructure", salaryStructue);
		return "structure";

	}
	
	@GetMapping("/jlist")
	@ResponseBody
	public List<SalaryStructure> JProjectList() {
		List<SalaryStructure> salary=salaryStructureService.get();
		
		
		return salary;
	}
	@GetMapping("/data")
	
	
	
	@RequestMapping("/delete/{id}")
	public  String  softdelete(@PathVariable("id") Integer id ) {
		System.out.println("Soft Delete Successully....."+id);
		String data = salaryStructureService.delete(id);
		String value="";
		if(data.equals("Delete Is Successfully Done."))
		{
System.out.println("Successfully Deleted");
        System.out.print(data);
		}else {
			System.out.println("Not Deleted");
		}
		return "redirect:/salaryStructure/structure";
	}
	
	
}
