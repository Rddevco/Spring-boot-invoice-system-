package com.adjecti.invoicing.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adjecti.invoicing.dto.TechnologyDto;
import com.adjecti.invoicing.service.TechnologyService;

@RestController
@RequestMapping("/technology")
public class TechnologyController {

	@Autowired
	private TechnologyService technologyService;
	
	
	@GetMapping("/list")
	public ResponseEntity<List<TechnologyDto>> gettechnologyist() {
		return new ResponseEntity<List<TechnologyDto>>(technologyService.findAll(), HttpStatus.OK);
	}


	@PostMapping("/save")
	public ResponseEntity<TechnologyDto> saveOrUpdateTechnology(@Valid @RequestBody @ModelAttribute("technology") TechnologyDto technologyDto) {
		System.out.println(technologyDto.getName());
		return new ResponseEntity<TechnologyDto>(technologyService.save(technologyDto),HttpStatus.OK);
	}

	@GetMapping("/delete/{id}")

	public ResponseEntity<Void> delete(@PathVariable String id) {
		System.out.println(id);
		technologyService.delete(Integer.parseInt(id));
		return new ResponseEntity<Void>(HttpStatus.OK);
	}

}
