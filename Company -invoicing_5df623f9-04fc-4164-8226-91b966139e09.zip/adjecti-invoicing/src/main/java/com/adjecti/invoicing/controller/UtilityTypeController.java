package com.adjecti.invoicing.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.adjecti.invoicing.dto.UtilityTypeDto;
import com.adjecti.invoicing.service.UtilityService;

@Controller
@RequestMapping("/utility")
public class UtilityTypeController {
	@Autowired
	private UtilityService utilityservice;
	
	@GetMapping(value="/list")
	public String getAllUtilityType(Model model) {
		List<UtilityTypeDto> utilitydto = utilityservice.findAll();
		model.addAttribute("utilityType", utilitydto);
		return "UtilityType";
	}
	@PostMapping("/utilityType")
	public String save( UtilityTypeDto utilitydto) {
		utilityservice.save(utilitydto);
		return "redirect:/utilityType";
	}
}
