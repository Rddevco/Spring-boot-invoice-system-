package com.adjecti.invoicing.dto;

import javax.validation.constraints.NotEmpty;

import com.adjecti.invoicing.model.AddressType;

import lombok.Data;


public class AddressTypeDto {

	
	private long id;
	@NotEmpty
	private String name;
		
	
	public AddressTypeDto() {
		super();
	
	}

	public AddressTypeDto(AddressType entity) {
		super();
		this.id = entity.getId();
		this.name = entity.getName();
	}
   
	  public AddressType toEntity() {
	       AddressType entity = new AddressType();
	       entity.setId(this.getId());
	       entity.setName(this.name);
	       return entity;
	    }
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
	
	
	
	
	 
}
