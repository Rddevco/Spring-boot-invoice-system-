package com.adjecti.invoicing.dto;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

public class BillingTypeDto {
	private int id;
	@NotEmpty
	//@Size(min = 2)
	private String type;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
}

