package com.adjecti.invoicing.dto;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.adjecti.invoicing.model.Address;
import com.adjecti.invoicing.model.Client;
import com.adjecti.invoicing.model.CompanyType;
import com.adjecti.invoicing.model.Contact;
import com.adjecti.invoicing.model.PurchaseOrder;
import com.adjecti.invoicing.model.Tax;

public class ClientDto {

	private int id;
	
    @NotEmpty(message = "Please enter business name")
	private String businessName;
	
	
	private LocalDate createdDate;
	
	private byte enabled;
	private int paymentNetDays;
	private Integer taxExemptable;
	
	
	private String website;
	
	@NotEmpty(message = "Please Enter Name")
	private	String name;
	
	@Valid
	private Address address;
	
	
	private String primaryBusiness;
	 
	
	@NotNull(message = "Please select company type")
	private CompanyType companyType;

	private Contact contact;
	
	private String taxDocNo1;
	private String taxDocNo2;
	
	private List<Tax> tax;
	
	private List<PurchaseOrder> purchaseOrders;
	  
	  public List<PurchaseOrder> getPurchaseOrders() {
		return purchaseOrders;
	}

	public void setPurchaseOrders(List<PurchaseOrder> purchaseOrders) {
		this.purchaseOrders = purchaseOrders;
	}

	public ClientDto(Client entity)
	  {
		    this.id =entity. getId();
			this.businessName = entity.getBusinessName();
			this.createdDate = entity.getCreatedDate();
			this.enabled = entity.getEnabled();
			this.paymentNetDays = entity.getPaymentNetDays();
			this.taxExemptable = entity.getTaxExemptable();
			this.website = entity.getWebsite();
			this.name = entity.getName();
			this.address = entity.getAddress();
			this.primaryBusiness = entity.getPrimaryBusiness();
			this.companyType = entity.getCompany();
			this.contact = entity.getContact();
			this.taxDocNo1 = entity.getTaxDocNo1();
			this.taxDocNo2 = entity.getTaxDocNo2();
			this.tax = entity.getTax();
			this.purchaseOrders = entity.getPurchaseOrders();
	  }

	public ClientDto() {
		// TODO Auto-generated constructor stub
	}

	public Client ToEntity() {
		Client entity=new Client();
		
		entity.setId(this.getId());
		entity.setName(this.getName());
		entity.setAddress(this.getAddress());
		entity.setBusinessName(this.getBusinessName());
		entity.setCompany(this.getCompanyType());
		entity.setContact(this.getContact());
		entity.setCreatedDate(this.getCreatedDate());
		entity.setEnabled(this.getEnabled());
		entity.setPaymentNetDays(this.getPaymentNetDays());
		entity.setPrimaryBusiness(this.getPrimaryBusiness());
		entity.setTax(this.getTax());
		entity.setTaxDocNo1(this.getTaxDocNo1());
		entity.setTaxDocNo2(this.getTaxDocNo2());
		entity.setTaxExemptable(this.getTaxExemptable());
		entity.setWebsite(this.getWebsite());
		entity.setPurchaseOrders(this.purchaseOrders);
		return entity;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public LocalDate getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDate createdDate) {
		this.createdDate = createdDate;
	}

	public byte getEnabled() {
		return enabled;
	}

	public void setEnabled(byte enabled) {
		this.enabled = enabled;
	}

	public int getPaymentNetDays() {
		return paymentNetDays;
	}

	public void setPaymentNetDays(int paymentNetDays) {
		this.paymentNetDays = paymentNetDays;
	}

	public Integer getTaxExemptable() {
		return taxExemptable;
	}

	public void setTaxExemptable(Integer taxExemptable) {
		this.taxExemptable = taxExemptable;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public String getPrimaryBusiness() {
		return primaryBusiness;
	}

	public void setPrimaryBusiness(String primaryBusiness) {
		this.primaryBusiness = primaryBusiness;
	}

	
	public CompanyType getCompany() {

		return companyType;
	}


	public Contact getContact() {
		return contact;
	}

	public void setContact(Contact contact) {
		this.contact = contact;
	}

	public String getTaxDocNo1() {
		return taxDocNo1;
	}

	public void setTaxDocNo1(String taxDocNo1) {
		this.taxDocNo1 = taxDocNo1;
	}

	public String getTaxDocNo2() {
		return taxDocNo2;
	}

	public void setTaxDocNo2(String taxDocNo2) {
		this.taxDocNo2 = taxDocNo2;
	}

	public List<Tax> getTax() {
		
		return tax;
	}

	public void setTax(List<Tax> tax) {
		this.tax = tax;
	}

	public CompanyType getCompanyType() {
		return companyType;
	}

	public void setCompanyType(CompanyType companyType) {
		this.companyType = companyType;
	}

	@Override
	public String toString() {
		return "ClientDto [id=" + id + ", businessName=" + businessName + ", createdDate=" + createdDate + ", enabled="
				+ enabled + ", paymentNetDays=" + paymentNetDays + ", taxExemptable=" + taxExemptable + ", website="
				+ website + ", name=" + name + ", address=" + address + ", primaryBusiness=" + primaryBusiness
				+ ", companyType=" + companyType + ", contact=" + contact + ", taxDocNo1=" + taxDocNo1 + ", taxDocNo2="
				+ taxDocNo2 + ", tax=" + tax + ", purchaseOrders=" + purchaseOrders + "]";
	}
	
	  
}
