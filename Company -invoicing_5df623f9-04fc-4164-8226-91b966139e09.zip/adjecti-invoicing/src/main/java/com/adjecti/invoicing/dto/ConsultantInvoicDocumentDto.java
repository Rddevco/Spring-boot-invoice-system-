package com.adjecti.invoicing.dto;

import com.adjecti.invoicing.model.ConsultantInvoicDocument;

public class ConsultantInvoicDocumentDto {

	private int id;
	private String documentType;
	private String mimeType;
	private String name;
	private String path;
	private String title;
	
	public ConsultantInvoicDocumentDto(ConsultantInvoicDocument entity)
	{
		this.id=entity.getId();
		this.documentType=entity.getDocumentType();
		this.mimeType=entity.getMimeType();
		this.name=entity.getName();
		this.path=entity.getPath();
		this.title=entity.getTitle();		
	}
	
	public ConsultantInvoicDocument ToEntity()
	{ 
		ConsultantInvoicDocument entity = new ConsultantInvoicDocument();
		entity.setId(this.getId());
		entity.setDocumentType(this.getDocumentType());
		entity.setMimeType(this.getMimeType());
		entity.setName(this.getName());
		entity.setPath(this.getPath());
		entity.setTitle(this.getTitle());	
		return entity;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public String getMimeType() {
		return mimeType;
	}
	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public ConsultantInvoicDocumentDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
