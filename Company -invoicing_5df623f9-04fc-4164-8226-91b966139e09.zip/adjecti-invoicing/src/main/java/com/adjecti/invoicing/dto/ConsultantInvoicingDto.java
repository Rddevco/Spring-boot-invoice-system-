package com.adjecti.invoicing.dto;

import java.util.Date;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import com.adjecti.invoicing.model.Consultant;
import com.adjecti.invoicing.model.ConsultantInvoicDocument;
import com.adjecti.invoicing.model.ConsultantInvoicing;

public class ConsultantInvoicingDto {
	
	private int id;
	@Min(value=1, message="Must be equal or greater than 1") 
	private float amount;
	@NotEmpty
	private String description;
	@DateTimeFormat(pattern="yyyy-MM-dd")
	@NotNull(message = "Please provide a date.")
	private Date duedate;
	private byte enabled;
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date invoicedate;
	@NotEmpty
	private String invoiceNo;
	
	private float taxAmount;
	
	private ConsultantInvoicDocument consultantInvoicDocument;
	@NotNull
	
	private Consultant consultantid;
	
	public ConsultantInvoicingDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public ConsultantInvoicingDto(ConsultantInvoicing entity)
	{
		this.id=entity.getId();
		this.amount=entity.getAmount();
		this.description=entity.getDescription();
		this.duedate=entity.getDuedate();
		this.enabled=entity.getEnabled();
		this.invoicedate=entity.getInvoicedate();
		this.invoiceNo=entity.getInvoiceNo();
		this.taxAmount=entity.getTaxAmount();
		this.consultantInvoicDocument=entity.getConsultantInvoicDocument();
		this.consultantid=entity.getConsultantid();
		
	}
	
	public ConsultantInvoicing ToEntity() {
		ConsultantInvoicing entity=new ConsultantInvoicing();
		entity.setId(this.getId());
		entity.setAmount(this.getAmount());
		entity.setDescription(this.getDescription());
		entity.setDuedate(this.getDuedate());
		entity.setEnabled(this.getEnabled());
		entity.setInvoicedate(this.getInvoicedate());
		entity.setInvoiceNo(this.getInvoiceNo());
		entity.setTaxAmount(this.getTaxAmount());
		entity.setConsultantInvoicDocument(this.getConsultantInvoicDocument());
		entity.setConsultantid(this.getConsultantid());
		return entity;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getDuedate() {
		return duedate;
	}

	public void setDuedate(Date duedate) {
		this.duedate = duedate;
	}


	public byte getEnabled() {
		return enabled;
	}

	public void setEnabled(byte enabled) {
		this.enabled = enabled;
	}

	public Date getInvoicedate() {
		return invoicedate;
	}

	public void setInvoicedate(Date invoicedate) {
		this.invoicedate = invoicedate;
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public float getTaxAmount() {
		return taxAmount;
	}

	public void setTaxAmount(float taxAmount) {
		this.taxAmount = taxAmount;
	}

	public ConsultantInvoicDocument getConsultantInvoicDocument() {
		return consultantInvoicDocument;
	}

	public void setConsultantInvoicDocument(ConsultantInvoicDocument consultantInvoicDocument) {
		this.consultantInvoicDocument = consultantInvoicDocument;
	}

	public Consultant getConsultantid() {
		return consultantid;
	}

	public void setConsultantid(Consultant consultantid) {
		this.consultantid = consultantid;
	}

	@Override
	public String toString() {
		return "ConsultantInvoicingDto [id=" + id + ", amount=" + amount + ", description=" + description + ", duedate="
				+ duedate + ", enabled=" + enabled + ", invoicedate=" + invoicedate + ", invoiceNo=" + invoiceNo
				+ ", taxAmount=" + taxAmount + ", consultantInvoicDocument=" + consultantInvoicDocument
				+ ", consultantid=" + consultantid + "]";
	}

	
}
