package com.adjecti.invoicing.dto;


import javax.validation.constraints.NotEmpty;

import com.adjecti.invoicing.model.Country;

public class CountryDto {
	private int id;
	@NotEmpty
	private String name;
	public CountryDto() {
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public CountryDto(Country entity) {
		this.id=entity.getId();
		this.name=entity.getName();
	}
	
	public Country toEntity() {
		Country entity=new Country();
		entity.setId(this.getId());
		entity.setName(this.getName());
		
		return entity;
	}
	
	
}
