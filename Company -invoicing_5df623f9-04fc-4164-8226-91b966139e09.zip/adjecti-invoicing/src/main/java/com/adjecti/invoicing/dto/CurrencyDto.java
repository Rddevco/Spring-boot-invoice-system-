package com.adjecti.invoicing.dto;

import javax.validation.constraints.NotEmpty;

import com.adjecti.invoicing.model.Currency;

public class CurrencyDto {
	
	private int id;
	@NotEmpty
	private String currencyname;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCurrencyname() {
		return currencyname;
	}
	public void setCurrencyname(String currencyname) {
		this.currencyname = currencyname;
	}
	public CurrencyDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CurrencyDto(int id, String currencyname) {
		super();
		this.id = id;
		this.currencyname = currencyname;
	}
	
	public CurrencyDto(Currency entity) {
		
		this.id=entity.getId();
		this.currencyname=entity.getCurrencyname();
	}
	
	public Currency toEntity() {
		Currency entity =new Currency();
		entity.setId(this.getId());
		entity.setCurrencyname(this.getCurrencyname());
		return entity;
	}
	@Override
	public String toString() {
		return "CurrencyDto [id=" + id + ", currencyname=" + currencyname + "]";
	}
	
	
}
