package com.adjecti.invoicing.dto;

import com.adjecti.invoicing.model.ClientPurchaseOrderItem;

public class InvoiceItemDto {

	private int id;

	private double amount;

	private String descrition;

	private String name;

	private double part;

	private int quantity;

	private ClientPurchaseOrderItem clientPurchaseOrderItem;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getDescrition() {
		return descrition;
	}

	public void setDescrition(String descrition) {
		this.descrition = descrition;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPart() {
		return part;
	}

	public void setPart(double part) {
		this.part = part;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public ClientPurchaseOrderItem getClientPurchaseOrderItem() {
		return clientPurchaseOrderItem;
	}

	public void setClientPurchaseOrderItem(ClientPurchaseOrderItem clientPurchaseOrderItem) {
		this.clientPurchaseOrderItem = clientPurchaseOrderItem;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("InvoiceItemDto [id=").append(id).append(", amount=").append(amount).append(", descrition=")
				.append(descrition).append(", name=").append(name).append(", part=").append(part).append(", quantity=")
				.append(quantity).append(", clientPurchaseOrderItem=").append(clientPurchaseOrderItem).append("]");
		return builder.toString();
	}
	
	
}
