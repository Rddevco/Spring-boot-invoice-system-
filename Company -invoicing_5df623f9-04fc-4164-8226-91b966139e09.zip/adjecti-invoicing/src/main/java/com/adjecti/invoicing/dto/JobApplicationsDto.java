package com.adjecti.invoicing.dto;

import com.adjecti.invoicing.model.JobOpening;

import lombok.Data;
@Data
public class JobApplicationsDto {

	private int id;

	private String name;

	private String phone;

	private String email;

	private String relevantExp;

	private JobOpening jobOpening;

	private String currentCompany;

	private String currentLocation;

	private String noticePeroid;

	private String currentSalary;

	private String expectedSalary;

	private Boolean enabled;

	public JobApplicationsDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public JobApplicationsDto(int id, String name, String phone, String email, String relevantExp,
			JobOpening jobOpening, String currentCompany, String currentLocation, String noticePeroid,
			String currentSalary, String expectedSalary, Boolean enabled) {
		super();
		this.id = id;
		this.name = name;
		this.phone = phone;
		this.email = email;
		this.relevantExp = relevantExp;
		this.jobOpening = jobOpening;
		this.currentCompany = currentCompany;
		this.currentLocation = currentLocation;
		this.noticePeroid = noticePeroid;
		this.currentSalary = currentSalary;
		this.expectedSalary = expectedSalary;
		this.enabled = enabled;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getRelevantExp() {
		return relevantExp;
	}

	public void setRelevantExp(String relevantExp) {
		this.relevantExp = relevantExp;
	}

	public JobOpening getJobOpening() {
		return jobOpening;
	}

	public void setJobOpening(JobOpening jobOpening) {
		this.jobOpening = jobOpening;
	}

	public String getCurrentCompany() {
		return currentCompany;
	}

	public void setCurrentCompany(String currentCompany) {
		this.currentCompany = currentCompany;
	}

	public String getCurrentLocation() {
		return currentLocation;
	}

	public void setCurrentLocation(String currentLocation) {
		this.currentLocation = currentLocation;
	}

	public String getNoticePeroid() {
		return noticePeroid;
	}

	public void setNoticePeroid(String noticePeroid) {
		this.noticePeroid = noticePeroid;
	}

	public String getCurrentSalary() {
		return currentSalary;
	}

	public void setCurrentSalary(String currentSalary) {
		this.currentSalary = currentSalary;
	}

	public String getExpectedSalary() {
		return expectedSalary;
	}

	public void setExpectedSalary(String expectedSalary) {
		this.expectedSalary = expectedSalary;
	}

	public Boolean getEnabled() {
		return enabled;
	}

	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}

	@Override
	public String toString() {
		return "JobApplicationsDto [id=" + id + ", name=" + name + ", phone=" + phone + ", email=" + email
				+ ", relevantExp=" + relevantExp + ", jobOpening=" + jobOpening + ", currentCompany=" + currentCompany
				+ ", currentLocation=" + currentLocation + ", noticePeroid=" + noticePeroid + ", currentSalary="
				+ currentSalary + ", expectedSalary=" + expectedSalary + ", enabled=" + enabled + "]";
	}

	

}
