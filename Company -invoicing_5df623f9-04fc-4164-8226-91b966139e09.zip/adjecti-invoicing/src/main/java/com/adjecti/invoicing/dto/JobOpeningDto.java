package com.adjecti.invoicing.dto;

import lombok.Data;

@Data
public class JobOpeningDto {

	private int id;

	private String name;

	private String minExp;

	private String maxExp;

	private String minSalary;

	private String maxSalary;

	private String Description;

	private Boolean enabled;

	public JobOpeningDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public JobOpeningDto(int id, String name, String minExp, String maxExp, String minSalary, String maxSalary,
			String description, Boolean enabled) {
		super();
		this.id = id;
		this.name = name;
		this.minExp = minExp;
		this.maxExp = maxExp;
		this.minSalary = minSalary;
		this.maxSalary = maxSalary;
		Description = description;
		this.enabled = enabled;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMinExp() {
		return minExp;
	}

	public void setMinExp(String minExp) {
		this.minExp = minExp;
	}

	public String getMaxExp() {
		return maxExp;
	}

	public void setMaxExp(String maxExp) {
		this.maxExp = maxExp;
	}

	public String getMinSalary() {
		return minSalary;
	}

	public void setMinSalary(String minSalary) {
		this.minSalary = minSalary;
	}

	public String getMaxSalary() {
		return maxSalary;
	}

	public void setMaxSalary(String maxSalary) {
		this.maxSalary = maxSalary;
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}

	public Boolean getEnabled() {
		return enabled;
	}

	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}

	@Override
	public String toString() {
		return "JobOpeningDto [id=" + id + ", name=" + name + ", minExp=" + minExp + ", maxExp=" + maxExp
				+ ", minSalary=" + minSalary + ", maxSalary=" + maxSalary + ", Description=" + Description
				+ ", enabled=" + enabled + "]";
	}

	
	
	
}
