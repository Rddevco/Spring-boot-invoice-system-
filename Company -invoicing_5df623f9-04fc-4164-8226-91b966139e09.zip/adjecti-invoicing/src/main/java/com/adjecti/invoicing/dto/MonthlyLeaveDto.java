package com.adjecti.invoicing.dto;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.adjecti.invoicing.model.People;

import lombok.Data;

@Data
public class MonthlyLeaveDto {

	private int id;

	private People people;

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date processMonth;

	private int totalCount;

	private int fullDay;

	private int halfDay;

	private int ciCount;

	private int piCount;

	private int avgWorkingHour;

	private int lateEntryCount;

	private int applyBefore0Days;

	private int applyBefore1Days;

	private int applyBefore2Days;

	private int applyBefore3Days;

	private int applyBeforeMoreThan3Days;

	private String leaveDates;
	
	private Boolean enabled;

	public MonthlyLeaveDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public MonthlyLeaveDto(int id, People people, Date processMonth, int totalCount, int fullDay, int halfDay,
			int ciCount, int piCount, int avgWorkingHour, int lateEntryCount, int applyBefore0Days,
			int applyBefore1Days, int applyBefore2Days, int applyBefore3Days, int applyBeforeMoreThan3Days,
			String leaveDates, Boolean enabled) {
		super();
		this.id = id;
		this.people = people;
		this.processMonth = processMonth;
		this.totalCount = totalCount;
		this.fullDay = fullDay;
		this.halfDay = halfDay;
		this.ciCount = ciCount;
		this.piCount = piCount;
		this.avgWorkingHour = avgWorkingHour;
		this.lateEntryCount = lateEntryCount;
		this.applyBefore0Days = applyBefore0Days;
		this.applyBefore1Days = applyBefore1Days;
		this.applyBefore2Days = applyBefore2Days;
		this.applyBefore3Days = applyBefore3Days;
		this.applyBeforeMoreThan3Days = applyBeforeMoreThan3Days;
		this.leaveDates = leaveDates;
		this.enabled = enabled;
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public People getPeople() {
		return people;
	}

	public void setPeople(People people) {
		this.people = people;
	}

	public Date getProcessMonth() {
		return processMonth;
	}

	public void setProcessMonth(Date processMonth) {
		this.processMonth = processMonth;
	}

	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	public int getFullDay() {
		return fullDay;
	}

	public void setFullDay(int fullDay) {
		this.fullDay = fullDay;
	}

	public int getHalfDay() {
		return halfDay;
	}

	public void setHalfDay(int halfDay) {
		this.halfDay = halfDay;
	}

	public int getCiCount() {
		return ciCount;
	}

	public void setCiCount(int ciCount) {
		this.ciCount = ciCount;
	}

	public int getPiCount() {
		return piCount;
	}

	public void setPiCount(int piCount) {
		this.piCount = piCount;
	}

	public int getAvgWorkingHour() {
		return avgWorkingHour;
	}

	public void setAvgWorkingHour(int avgWorkingHour) {
		this.avgWorkingHour = avgWorkingHour;
	}

	public int getLateEntryCount() {
		return lateEntryCount;
	}

	public void setLateEntryCount(int lateEntryCount) {
		this.lateEntryCount = lateEntryCount;
	}

	public int getApplyBefore0Days() {
		return applyBefore0Days;
	}

	public void setApplyBefore0Days(int applyBefore0Days) {
		this.applyBefore0Days = applyBefore0Days;
	}

	public int getApplyBefore1Days() {
		return applyBefore1Days;
	}

	public void setApplyBefore1Days(int applyBefore1Days) {
		this.applyBefore1Days = applyBefore1Days;
	}

	public int getApplyBefore2Days() {
		return applyBefore2Days;
	}

	public void setApplyBefore2Days(int applyBefore2Days) {
		this.applyBefore2Days = applyBefore2Days;
	}

	public int getApplyBefore3Days() {
		return applyBefore3Days;
	}

	public void setApplyBefore3Days(int applyBefore3Days) {
		this.applyBefore3Days = applyBefore3Days;
	}

	public int getApplyBeforeMoreThan3Days() {
		return applyBeforeMoreThan3Days;
	}

	public void setApplyBeforeMoreThan3Days(int applyBeforeMoreThan3Days) {
		this.applyBeforeMoreThan3Days = applyBeforeMoreThan3Days;
	}

	public String getLeaveDates() {
		return leaveDates;
	}

	public void setLeaveDates(String leaveDates) {
		this.leaveDates = leaveDates;
	}
	
	

	public Boolean getEnabled() {
		return enabled;
	}



	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}



	@Override
	public String toString() {
		return "MonthlyLeaveDto [id=" + id + ", people=" + people + ", processMonth=" + processMonth + ", totalCount="
				+ totalCount + ", fullDay=" + fullDay + ", halfDay=" + halfDay + ", ciCount=" + ciCount + ", piCount="
				+ piCount + ", avgWorkingHour=" + avgWorkingHour + ", lateEntryCount=" + lateEntryCount
				+ ", applyBefore0Days=" + applyBefore0Days + ", applyBefore1Days=" + applyBefore1Days
				+ ", applyBefore2Days=" + applyBefore2Days + ", applyBefore3Days=" + applyBefore3Days
				+ ", applyBeforeMoreThan3Days=" + applyBeforeMoreThan3Days + ", leaveDates=" + leaveDates + "]";
	}

}
