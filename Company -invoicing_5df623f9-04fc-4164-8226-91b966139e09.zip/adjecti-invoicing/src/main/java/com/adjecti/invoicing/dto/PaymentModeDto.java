package com.adjecti.invoicing.dto;

import javax.validation.constraints.NotEmpty;

import com.adjecti.invoicing.model.PaymentMode;


public class PaymentModeDto {
	private long id;
	@NotEmpty
	private String name;
	
	public PaymentModeDto() {
		super();
		
	}

	public PaymentModeDto(PaymentMode entity) {
		super();
		this.id = entity.getId();
		this.name = entity.getName();
	}
	public PaymentMode toEntity() {
		PaymentMode entity=new PaymentMode();
		entity.setId(this.getId());
		entity.setName(this.name);
		return entity;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	

}
