package com.adjecti.invoicing.dto;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.adjecti.invoicing.model.Client;
import com.adjecti.invoicing.model.Invoice;
import com.adjecti.invoicing.model.PaymentMode;

import lombok.Data;

@Data
public class RecievePaymentDto {

	private int id;

	private Client client;

	private Invoice invoice;

	private double payableTotal;

	private double balanceDue;

	private double amountReceived;

	private PaymentMode paymentMode;
	
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date dateOfPayment;

	private float exchangeRate;

	private String transactionDetails;
	
	private double amountPaid;
	
	private Boolean enabled;

	public RecievePaymentDto() {
		
		// TODO Auto-generated constructor stub
	}

	

	public RecievePaymentDto(int id, Client client, Invoice invoice, double payableTotal, double balanceDue,
			double amountReceived, PaymentMode paymentMode, Date dateOfPayment, float exchangeRate,
			String transactionDetails, double amountPaid, Boolean enabled) {
		super();
		this.id = id;
		this.client = client;
		this.invoice = invoice;
		this.payableTotal = payableTotal;
		this.balanceDue = balanceDue;
		this.amountReceived = amountReceived;
		this.paymentMode = paymentMode;
		this.dateOfPayment = dateOfPayment;
		this.exchangeRate = exchangeRate;
		this.transactionDetails = transactionDetails;
		this.amountPaid = amountPaid;
		this.enabled = enabled;
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Client getClient() {
		return client;
	}

	public void setClient(Client client) {
		this.client = client;
	}

	public Invoice getInvoice() {
		return invoice;
	}

	public void setInvoice(Invoice invoice) {
		this.invoice = invoice;
	}

	public double getPayableTotal() {
		return payableTotal;
	}

	public void setPayableTotal(double payableTotal) {
		this.payableTotal = payableTotal;
	}

	public double getBalanceDue() {
		return balanceDue;
	}

	public void setBalanceDue(double balanceDue) {
		this.balanceDue = balanceDue;
	}

	public double getAmountReceived() {
		return amountReceived;
	}

	public void setAmountReceived(double amountReceived) {
		this.amountReceived = amountReceived;
	}

	public PaymentMode getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(PaymentMode paymentMode) {
		this.paymentMode = paymentMode;
	}

	public Date getDateOfPayment() {
		return dateOfPayment;
	}

	public void setDateOfPayment(Date dateOfPayment) {
		this.dateOfPayment = dateOfPayment;
	}

	public float getExchangeRate() {
		return exchangeRate;
	}

	public void setExchangeRate(float exchangeRate) {
		this.exchangeRate = exchangeRate;
	}

	public String getTransactionDetails() {
		return transactionDetails;
	}

	public void setTransactionDetails(String transactionDetails) {
		this.transactionDetails = transactionDetails;
	}

	public Boolean getEnabled() {
		return enabled;
	}

	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}
	
	
	
	public double getAmountPaid() {
		return amountPaid;
	}



	public void setAmountPaid(double amountPaid) {
		this.amountPaid = amountPaid;
	}



	@Override
	public String toString() {
		return "RecievePayment [id=" + id + ", client=" + client + ", invoice=" + invoice + ", payableTotal="
				+ payableTotal + ", balanceDue=" + balanceDue + ", amountReceived=" + amountReceived + ", paymentMode="
				+ paymentMode + ", dateOfPayment=" + dateOfPayment + ", exchangeRate=" + exchangeRate
				+ ", transactionDetails=" + transactionDetails + ", enabled=" + enabled + "]";
	}

}
