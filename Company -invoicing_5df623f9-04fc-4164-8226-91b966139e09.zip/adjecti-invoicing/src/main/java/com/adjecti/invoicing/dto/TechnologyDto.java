package com.adjecti.invoicing.dto;

import javax.validation.constraints.NotEmpty;

import com.adjecti.invoicing.model.Technology;

public class TechnologyDto {
	
	public TechnologyDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	private int id;
	@NotEmpty
	private String name;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public TechnologyDto(Technology technology) {
		this.id = technology.getId();
		this.name=technology.getName();
		
	}

	public Technology toEntity() {
		Technology technology = new Technology(); 
		technology.setId(this.getId());
		technology.setName(this.getName());
		return technology;
	}
}
