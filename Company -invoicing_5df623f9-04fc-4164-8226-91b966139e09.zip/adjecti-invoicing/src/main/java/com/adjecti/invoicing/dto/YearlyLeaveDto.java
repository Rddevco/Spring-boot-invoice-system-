package com.adjecti.invoicing.dto;

import com.adjecti.invoicing.model.People;

import lombok.Data;

@Data
public class YearlyLeaveDto {

	private int id;

	private People people;

	private int year;

	private int clTaken;

	private int plTaken;

	private int plEncashed;

	private int clBalance;

	private int plBalance;

	private int parentalLeaveTaken;

	private Boolean enabled;

	public YearlyLeaveDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public YearlyLeaveDto(int id, People people, int year, int clTaken, int plTaken, int plEncashed, int clBalance,
			int plBalance, int parentalLeaveTaken, Boolean enabled) {
		super();
		this.id = id;
		this.people = people;
		this.year = year;
		this.clTaken = clTaken;
		this.plTaken = plTaken;
		this.plEncashed = plEncashed;
		this.clBalance = clBalance;
		this.plBalance = plBalance;
		this.parentalLeaveTaken = parentalLeaveTaken;
		this.enabled = enabled;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public People getPeople() {
		return people;
	}

	public void setPeople(People people) {
		this.people = people;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getClTaken() {
		return clTaken;
	}

	public void setClTaken(int clTaken) {
		this.clTaken = clTaken;
	}

	public int getPlTaken() {
		return plTaken;
	}

	public void setPlTaken(int plTaken) {
		this.plTaken = plTaken;
	}

	public int getPlEncashed() {
		return plEncashed;
	}

	public void setPlEncashed(int plEncashed) {
		this.plEncashed = plEncashed;
	}

	public int getClBalance() {
		return clBalance;
	}

	public void setClBalance(int clBalance) {
		this.clBalance = clBalance;
	}

	public int getPlBalance() {
		return plBalance;
	}

	public void setPlBalance(int plBalance) {
		this.plBalance = plBalance;
	}

	public int getParentalLeaveTaken() {
		return parentalLeaveTaken;
	}

	public void setParentalLeaveTaken(int parentalLeaveTaken) {
		this.parentalLeaveTaken = parentalLeaveTaken;
	}

	public Boolean getEnabled() {
		return enabled;
	}

	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}

	@Override
	public String toString() {
		return "YearlyLeave [id=" + id + ", people=" + people + ", year=" + year + ", clTaken=" + clTaken + ", plTaken="
				+ plTaken + ", plEncashed=" + plEncashed + ", clBalance=" + clBalance + ", plBalance=" + plBalance
				+ ", parentalLeaveTaken=" + parentalLeaveTaken + ", enabled=" + enabled + "]";
	}

}
