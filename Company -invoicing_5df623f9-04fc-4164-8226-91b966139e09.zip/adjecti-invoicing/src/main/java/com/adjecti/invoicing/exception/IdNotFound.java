package com.adjecti.invoicing.exception;

public class IdNotFound extends Exception {

}
