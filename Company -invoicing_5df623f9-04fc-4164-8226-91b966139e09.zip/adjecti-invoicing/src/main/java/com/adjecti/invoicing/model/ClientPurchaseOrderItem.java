package com.adjecti.invoicing.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_client_po_item")
public class ClientPurchaseOrderItem {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private float amount;
	private String description;
	private String name;
	private float price;
	private int qty;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "purchaseOrderId")
	private PurchaseOrder purchaseOrder;

	/*
	 * @OneToMany(mappedBy = "clientPurchaseOrderItem", cascade =
	 * {CascadeType.DETACH, CascadeType.MERGE, CascadeType.PERSIST,
	 * CascadeType.REFRESH }) private List<InvoiceItem> invoiceItems;
	 */
	
	/*
	 * @OneToMany(mappedBy = "clientPurchaseOrderItem", cascade = {
	 * CascadeType.DETACH, CascadeType.MERGE, CascadeType.PERSIST,
	 * CascadeType.REFRESH }) private List<InvoiceItem> invoiceItems;
	 */

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public PurchaseOrder getPurchaseOrder() {

		return purchaseOrder;
	}

	public void setPurchaseOrder(PurchaseOrder purchaseOrder) {
		this.purchaseOrder = purchaseOrder;
	}

	
	/*
	 * public List<InvoiceItem> getInvoiceItems() { return invoiceItems; }
	 * 
	 * public void setInvoiceItems(List<InvoiceItem> invoiceItems) {
	 * this.invoiceItems = invoiceItems; }
	 */
	 

	@Override
	public String toString() {
		return "ClientPurchaseOrderItem [id=" + id + ", amount=" + amount + ", description=" + description + ", name="
				+ name + ", price=" + price + ", qty=" + qty + "]";
	}

}