package com.adjecti.invoicing.model;


import java.util.Date;

import javax.persistence.*;
import javax.validation.constraints.Size;

@Entity
@Table(name = "tbl_consultant")
public class Consultant {
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String address;
	private String bankdetails;
	@Column(name="businessName")
	private String businessname;
	private byte enabled;
	@Size(min = 2, message = "First Name should have atleast 2 characters")
	private String name;
	private Date registeredDate;
    
	private String taxdocno1;
	private String taxdocno2;
	private String contactno;
	private String email;
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="companyType_id")
	private CompanyType company;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getBankdetails() {
		return bankdetails;
	}

	public void setBankdetails(String bankdetails) {
		this.bankdetails = bankdetails;
	}

	

	public String getBusinessname() {
		return businessname;
	}

	public void setBusinessname(String businessname) {
		this.businessname = businessname;
	}

	public byte getEnabled() {
		return enabled;
	}

	public void setEnabled(byte enabled) {
		this.enabled = enabled;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getRegisteredDate() {
		return registeredDate;
	}

	public void setRegisteredDate(Date registeredDate) {
		this.registeredDate = registeredDate;
	}

	public String getTaxdocno1() {
		return taxdocno1;
	}

	public void setTaxdocno1(String taxdocno1) {
		this.taxdocno1 = taxdocno1;
	}

	public String getTaxdocno2() {
		return taxdocno2;
	}

	public void setTaxdocno2(String taxdocno2) {
		this.taxdocno2 = taxdocno2;
	}

	public String getContactno() {
		return contactno;
	}

	public void setContactno(String contactno) {
		this.contactno = contactno;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public CompanyType getCompany() {
		return company;
	}

	public void setCompany(CompanyType company) {
		this.company = company;
	}

	@Override
	public String toString() {
		return "Consultant [id=" + id + ", address=" + address + ", bankdetails=" + bankdetails + ", businessname="
				+ businessname + ", enabled=" + enabled + ", name=" + name + ", registeredDate=" + registeredDate
				+ ", taxdocno1=" + taxdocno1 + ", taxdocno2=" + taxdocno2 + ", contactno=" + contactno + ", email="
				+ email + ", CompanyType=" + company + "]";
	}

	public Consultant(int id, String address, String bankdetails, String businessname, byte enabled, String name,
			Date registeredDate, String taxdocno1, String taxdocno2, String contactno, String email,
			CompanyType company) {
		super();
		this.id = id;
		this.address = address;
		this.bankdetails = bankdetails;
		this.businessname = businessname;
		this.enabled = enabled;
		this.name = name;
		this.registeredDate = registeredDate;
		this.taxdocno1 = taxdocno1;
		this.taxdocno2 = taxdocno2;
		this.contactno = contactno;
		this.email = email;
		this.company = company;
	}

	public Consultant() {
		super();
		// TODO Auto-generated constructor stub
	}    
}
