package com.adjecti.invoicing.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "tbl_consultant_payment")
public class ConsultantPayment {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@Column(name = "amount")
	private float amount;
	@Column(name = "paymentDate")
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date paymentDate;
	@Column(name = "trnDetails")
	private String trnDetails;
	@Column(name = "taxDeducted")
	private float taxDeducted;
	@Column(name = "taxPaid")
	private float taxPaid;
	@OneToOne
	@JoinColumn(name = "paymentMode_id")
	private PaymentMode paymentmode;
	@OneToOne
	@JoinColumn(name = "invoice_id")
	private ConsultantInvoicing consultantinvoicing;
	private Boolean enabled;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	

	public Date getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}

	public String getTrnDetails() {
		return trnDetails;
	}

	public void setTrnDetails(String trnDetails) {
		this.trnDetails = trnDetails;
	}

	public float getTaxDeducted() {
		return taxDeducted;
	}

	public void setTaxDeducted(float taxDeducted) {
		this.taxDeducted = taxDeducted;
	}

	public float getTaxPaid() {
		return taxPaid;
	}

	public void setTaxPaid(float taxPaid) {
		this.taxPaid = taxPaid;
	}

	public PaymentMode getPaymentmode() {
		return paymentmode;
	}

	public void setPaymentmode(PaymentMode paymentmode) {
		this.paymentmode = paymentmode;
	}

	
	public ConsultantInvoicing getConsultantinvoicing() {
		return consultantinvoicing;
	}

	public void setConsultantinvoicing(ConsultantInvoicing consultantinvoicing) {
		this.consultantinvoicing = consultantinvoicing;
	}

	public Boolean getEnabled() {
		return enabled;
	}

	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}

	@Override
	public String toString() {
		return "ConsultantPayment [id=" + id + ", amount=" + amount + ", paymentDate=" + paymentDate + ", trnDetails="
				+ trnDetails + ", taxDeducted=" + taxDeducted + ", taxPaid=" + taxPaid + ", paymentmode=" + paymentmode
				+ ", consultantinvoicing=" + consultantinvoicing + ", enabled=" + enabled + "]";
	}

	
	
	

}
