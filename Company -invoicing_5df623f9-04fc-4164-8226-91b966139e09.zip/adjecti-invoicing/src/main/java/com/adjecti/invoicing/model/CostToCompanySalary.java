package com.adjecti.invoicing.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


@Entity
@Table(name="tbl_costtocompany")
public class CostToCompanySalary {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@NotEmpty(message = "Plz Enter Your Name.")
	private String  name;
	@NotEmpty(message = "Plz Enter Date Here.")
	private String  dayPresent;
	@NotEmpty(message = "Plz Enter Date Here.")
	private String  processingMonth;
	@NotEmpty(message ="PLease Enter the Earning Value ")
	private String earnings;
	@NotNull(message ="PLease Enter the Retention Value ")
	private Float retention;
	@NotEmpty(message ="PLease Enter the Payment Mode Value")
	private String paymentModeForRetention;
	@NotEmpty(message ="PLease Enter the disbursementPeriodForPBI Value")
	private String disbursementPeriodForPBI;
	@NotNull(message ="PLease Enter the PBI Value ")
	private Float pBI;
	@NotEmpty(message ="PLease Enter the Payment Mode Value")
	private String paymentModeforPBI;
	private String disbursementPeriodForRetention;
	private boolean status;
	public CostToCompanySalary() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDayPresent() {
		return dayPresent;
	}
	public void setDayPresent(String dayPresent) {
		this.dayPresent = dayPresent;
	}
	public String getProcessingMonth() {
		return processingMonth;
	}
	public void setProcessingMonth(String processingMonth) {
		this.processingMonth = processingMonth;
	}
	public String getEarnings() {
		return earnings;
	}
	public void setEarnings(String earnings) {
		this.earnings = earnings;
	}
	public Float getRetention() {
		return retention;
	}
	public void setRetention(Float retention) {
		this.retention = retention;
	}
	public String getPaymentModeForRetention() {
		return paymentModeForRetention;
	}
	public void setPaymentModeForRetention(String paymentModeForRetention) {
		this.paymentModeForRetention = paymentModeForRetention;
	}
	public String getDisbursementPeriodForPBI() {
		return disbursementPeriodForPBI;
	}
	public void setDisbursementPeriodForPBI(String disbursementPeriodForPBI) {
		this.disbursementPeriodForPBI = disbursementPeriodForPBI;
	}
	public Float getPBI() {
		return pBI;
	}
	public void setPBI(Float pBI) {
		this.pBI = pBI;
	}
	public String getPaymentModeforPBI() {
		return paymentModeforPBI;
	}
	public void setPaymentModeforPBI(String paymentModeforPBI) {
		this.paymentModeforPBI = paymentModeforPBI;
	}
	public String getDisbursementPeriodForRetention() {
		return disbursementPeriodForRetention;
	}
	public void setDisbursementPeriodForRetention(String disbursementPeriodForRetention) {
		this.disbursementPeriodForRetention = disbursementPeriodForRetention;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public CostToCompanySalary(Integer id, @NotEmpty(message = "Plz Enter Your Name.") String name,
			@NotEmpty(message = "Plz Enter Date Here.") String dayPresent,
			@NotEmpty(message = "Plz Enter Date Here.") String processingMonth,
			@NotEmpty(message = "PLease Enter the Earning Value ") String earnings,
			@NotEmpty(message = "PLease Enter the Retention Value ") Float retention,
			@NotEmpty(message = "PLease Enter the Payment Mode Value") String paymentModeForRetention,
			@NotEmpty(message = "PLease Enter the disbursementPeriodForPBI Value") String disbursementPeriodForPBI,
			@NotEmpty(message = "PLease Enter the PBI Value ") Float pBI,
			@NotEmpty(message = "PLease Enter the Payment Model Value") String paymentModeforPBI,
			String disbursementPeriodForRetention, boolean status) {
		super();
		this.id = id;
		this.name = name;
		this.dayPresent = dayPresent;
		this.processingMonth = processingMonth;
		this.earnings = earnings;
		this.retention = retention;
		this.paymentModeForRetention = paymentModeForRetention;
		this.disbursementPeriodForPBI = disbursementPeriodForPBI;
		this.pBI = pBI;
		this.paymentModeforPBI = paymentModeforPBI;
		this.disbursementPeriodForRetention = disbursementPeriodForRetention;
		this.status = status;
	}
	@Override
	public String toString() {
		return "CostToCompanySalary [id=" + id + ", name=" + name + ", dayPresent=" + dayPresent + ", processingMonth="
				+ processingMonth + ", earnings=" + earnings + ", retention=" + retention + ", paymentModeForRetention=" + paymentModeForRetention
				+ ", disbursementPeriodForPBI=" + disbursementPeriodForPBI + ", pBI=" + pBI
				+ ", paymentModeforPBI=" + paymentModeforPBI + ", disbursementPeriodForRetention="
				+ disbursementPeriodForRetention + ", status=" + status + "]";
	}
	
}
