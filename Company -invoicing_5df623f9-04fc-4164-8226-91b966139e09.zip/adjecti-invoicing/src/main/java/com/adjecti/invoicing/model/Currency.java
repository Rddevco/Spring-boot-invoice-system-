package com.adjecti.invoicing.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_currency")
public class Currency {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String currencyname;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCurrencyname() {
		return currencyname;
	}
	public void setCurrencyname(String currencyname) {
		this.currencyname = currencyname;
	}
	public Currency(int id, String currencyname) {
		super();
		this.id = id;
		this.currencyname = currencyname;
	}
	public Currency() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Currency [id=" + id + ", currencyname=" + currencyname + "]";
	}
	
	
}
