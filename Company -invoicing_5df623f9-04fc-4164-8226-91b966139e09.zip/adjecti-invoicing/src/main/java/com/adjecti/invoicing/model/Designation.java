package com.adjecti.invoicing.model;

import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "tbl_designationn")
public class Designation {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer designationId;
	@NotEmpty(message = "Please Enter Name Value")
	private String name;
	@NotEmpty(message = "Please Enter Lavel Value")
	private String level;
	private boolean status;

	
	public Designation() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Designation(Integer designationId, @NotEmpty(message = "Please Enter Name Value") String name,
			@NotEmpty(message = "Please Enter Lavel Value") String level, boolean status) {
		super();
		this.designationId = designationId;
		this.name = name;
		this.level = level;
		this.status = status;
	}

	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public Integer getDesignationId() {
		return designationId;
	}
	public void setDesignationId(Integer designationId) {
		this.designationId = designationId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	
}
