package com.adjecti.invoicing.model;


import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

/**
 * @author HP
 *
 */
@Entity
@Table(name="tbl_employee")
public class Employee {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@NotEmpty(message = "Value Of FirstName is Must.")
	private String firstName;
	private String middleName;
	@NotEmpty(message = "Value Of lastName is Must.")
	private String lastName;
	@NotEmpty(message = "Value Of designation is Must.")
	private String designation;
	@Email(message = "Email is Must.")
	private String email;
	@NotEmpty(message = "Mobile No is required." )
	@Size(min = 10,max = 10)
    private String mobileNo;
	private boolean status;
	@NotEmpty(message="DateOfBirth must be required")
	private String  dateOfBirth;
	@NotEmpty(message = "Value Of lastName is Must.")
	private String gender;
	@NotEmpty(message = "Value Of lastName is Must.")
	private String fatherName;
	@NotEmpty(message="DateOfJoining must be required")
    private String dateOfJoining;
	@OneToMany(mappedBy = "employee",fetch = FetchType.LAZY,
	cascade = {CascadeType.DETACH,CascadeType.MERGE,CascadeType.PERSIST,CascadeType.REFRESH})
	private List<Leave> leave;
	@OneToMany(mappedBy = "employee",fetch=FetchType.LAZY,cascade = {CascadeType.MERGE,CascadeType.PERSIST,CascadeType.REFRESH,CascadeType.DETACH})
	private List<EmployeeEducation> employeeEducation;
		
	@OneToMany(mappedBy ="employee",fetch = FetchType.LAZY,cascade =  {CascadeType.DETACH,CascadeType.MERGE,CascadeType.PERSIST,CascadeType.REFRESH})
	private List<EmployeeAddress> employeeAddress;
	
	@OneToMany(mappedBy ="employee",fetch = FetchType.LAZY,cascade =  {CascadeType.DETACH,CascadeType.MERGE,CascadeType.PERSIST,CascadeType.REFRESH})
	private List<EmployeeExperence> employeeExperence;

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(Integer id, @NotEmpty(message = "Value Of FirstName is Must.") String firstName, String middleName,
			@NotEmpty(message = "Value Of lastName is Must.") String lastName,
			@NotEmpty(message = "Value Of designation is Must.") String designation,
			@Email(message = "Email is Must.") String email,
			@NotEmpty(message = "Mobile No is required.") @Size(min = 10, max = 10) String mobileNo, boolean status,
			@NotEmpty(message = "DateOfBirth must be required") String dateOfBirth,
			@NotEmpty(message = "Value Of lastName is Must.") String gender,
			@NotEmpty(message = "Value Of lastName is Must.") String fatherName,
			@NotEmpty(message = "DateOfJoining must be required") String dateOfJoining, List<Leave> leave,
			List<EmployeeEducation> employeeEducation, List<EmployeeAddress> employeeAddress,
			List<EmployeeExperence> employeeExperence) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.designation = designation;
		this.email = email;
		this.mobileNo = mobileNo;
		this.status = status;
		this.dateOfBirth = dateOfBirth;
		this.gender = gender;
		this.fatherName = fatherName;
		this.dateOfJoining = dateOfJoining;
		this.leave = leave;
		this.employeeEducation = employeeEducation;
		this.employeeAddress = employeeAddress;
		this.employeeExperence = employeeExperence;
	}

	public Employee(@NotEmpty(message = "Value Of FirstName is Must.") String firstName, String middleName,
			@NotEmpty(message = "Value Of lastName is Must.") String lastName,
			@NotEmpty(message = "Value Of designation is Must.") String designation,
			@Email(message = "Email is Must.") String email,
			@NotEmpty(message = "Mobile No is required.") @Size(min = 10, max = 10) String mobileNo, boolean status,
			@NotEmpty(message = "DateOfBirth must be required") String dateOfBirth,
			@NotEmpty(message = "Value Of lastName is Must.") String gender,
			@NotEmpty(message = "Value Of lastName is Must.") String fatherName,
			@NotEmpty(message = "DateOfJoining must be required") String dateOfJoining, List<Leave> leave,
			List<EmployeeEducation> employeeEducation, List<EmployeeAddress> employeeAddress,
			List<EmployeeExperence> employeeExperence) {
		super();
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.designation = designation;
		this.email = email;
		this.mobileNo = mobileNo;
		this.status = status;
		this.dateOfBirth = dateOfBirth;
		this.gender = gender;
		this.fatherName = fatherName;
		this.dateOfJoining = dateOfJoining;
		this.leave = leave;
		this.employeeEducation = employeeEducation;
		this.employeeAddress = employeeAddress;
		this.employeeExperence = employeeExperence;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public String getDateOfJoining() {
		return dateOfJoining;
	}

	public void setDateOfJoining(String dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	public List<Leave> getLeave() {
		return leave;
	}

	public void setLeave(List<Leave> leave) {
		this.leave = leave;
	}

	public List<EmployeeEducation> getEmployeeEducation() {
		return employeeEducation;
	}

	public void setEmployeeEducation(List<EmployeeEducation> employeeEducation) {
		this.employeeEducation = employeeEducation;
	}

	public List<EmployeeAddress> getEmployeeAddress() {
		return employeeAddress;
	}

	public void setEmployeeAddress(List<EmployeeAddress> employeeAddress) {
		this.employeeAddress = employeeAddress;
	}

	public List<EmployeeExperence> getEmployeeExperence() {
		return employeeExperence;
	}

	public void setEmployeeExperence(List<EmployeeExperence> employeeExperence) {
		this.employeeExperence = employeeExperence;
	}

	/*
	 * @Override public String toString() { return "Employee [id=" + id +
	 * ", firstName=" + firstName + ", middleName=" + middleName + ", lastName=" +
	 * lastName + ", designation=" + designation + ", email=" + email +
	 * ", mobileNo=" + mobileNo + ", status=" + status + ", dateOfBirth=" +
	 * dateOfBirth + ", gender=" + gender + ", fatherName=" + fatherName +
	 * ", dateOfJoining=" + dateOfJoining + ", leave=" + leave +
	 * ", employeeEducation=" + employeeEducation + ", employeeAddress=" +
	 * employeeAddress + ", employeeExperence=" + employeeExperence + "]"; }
	 */
	
	
	
}
