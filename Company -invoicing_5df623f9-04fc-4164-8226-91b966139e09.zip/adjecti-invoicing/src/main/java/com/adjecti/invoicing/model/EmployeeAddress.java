package com.adjecti.invoicing.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
@Entity
@Table(name="tbl_employeeaddress")
public class EmployeeAddress {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer addressId;
	@NotEmpty(message = "Please Enter Address Value. ")
	private String  address;
	@NotEmpty(message = "Please Enter State Value.")
	private String  state;
	@NotEmpty(message = "Please Enter Pincode Value.")
	private String  pincode;
	@NotEmpty(message = "Please Enter Currency Value.")
	private String  country;
	
	@ManyToOne(fetch =FetchType.LAZY )
	@JoinColumn(name ="employeeId")
	private Employee employee;
	
	public EmployeeAddress() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeAddress(Integer addressId, @NotEmpty(message = "Please Enter Address Value. ") String address,
			@NotEmpty(message = "Please Enter State Value.") String state,
			@NotEmpty(message = "Please Enter Pincode Value.") String pincode,
			@NotEmpty(message = "Please Enter Currency Value.") String country, Employee employee) {
		super();
		this.addressId = addressId;
		this.address = address;
		this.state = state;
		this.pincode = pincode;
		this.country = country;
		this.employee = employee;
	}

	public EmployeeAddress(@NotEmpty(message = "Please Enter Address Value. ") String address,
			@NotEmpty(message = "Please Enter State Value.") String state,
			@NotEmpty(message = "Please Enter Pincode Value.") String pincode,
			@NotEmpty(message = "Please Enter Currency Value.") String country, Employee employee) {
		super();
		this.address = address;
		this.state = state;
		this.pincode = pincode;
		this.country = country;
		this.employee = employee;
	}

	public Integer getAddressId() {
		return addressId;
	}

	public void setAddressId(Integer addressId) {
		this.addressId = addressId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	/*
	 * @Override public String toString() { return "EmployeeAddress [addressId=" +
	 * addressId + ", address=" + address + ", state=" + state + ", pincode=" +
	 * pincode + ", country=" + country + ", employee=" + employee + "]"; }
	 */

	
}
