package com.adjecti.invoicing.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "tbl_employeeeduction")
public class EmployeeEducation {


@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Integer educationId;
@NotEmpty(message = "Please Enter Your qualification.")
private String qualification;
@NotEmpty(message = "Please Enter Your  College Name.")
private String collegeName;
@NotEmpty(message = "Please Enter The Value Of Year.")
private String fromYear;
@NotEmpty(message = "Please Enter The Value Of Year.")
private String toYear;
@NotNull(message = "Please Enter the Percentage Value")
private float percentage;


@ManyToOne(fetch = FetchType.LAZY)
@JoinColumn(name = "employeeId")
private Employee employee;


public EmployeeEducation() {
	super();
	// TODO Auto-generated constructor stub
}


public EmployeeEducation(Integer educationId,
		@NotEmpty(message = "Please Enter Your qualification.") String qualification,
		@NotEmpty(message = "Please Enter Your  College Name.") String collegeName,
		@NotEmpty(message = "Please Enter The Value Of Year.") String fromYear,
		@NotEmpty(message = "Please Enter The Value Of Year.") String toYear,
		@NotNull(message = "Please Enter the Percentage Value") float percentage, Employee employee) {
	super();
	this.educationId = educationId;
	this.qualification = qualification;
	this.collegeName = collegeName;
	this.fromYear = fromYear;
	this.toYear = toYear;
	this.percentage = percentage;
	this.employee = employee;
}


public EmployeeEducation(@NotEmpty(message = "Please Enter Your qualification.") String qualification,
		@NotEmpty(message = "Please Enter Your  College Name.") String collegeName,
		@NotEmpty(message = "Please Enter The Value Of Year.") String fromYear,
		@NotEmpty(message = "Please Enter The Value Of Year.") String toYear,
		@NotNull(message = "Please Enter the Percentage Value") float percentage, Employee employee) {
	super();
	this.qualification = qualification;
	this.collegeName = collegeName;
	this.fromYear = fromYear;
	this.toYear = toYear;
	this.percentage = percentage;
	this.employee = employee;
}


public Integer getEducationId() {
	return educationId;
}


public void setEducationId(Integer educationId) {
	this.educationId = educationId;
}


public String getQualification() {
	return qualification;
}


public void setQualification(String qualification) {
	this.qualification = qualification;
}


public String getCollegeName() {
	return collegeName;
}


public void setCollegeName(String collegeName) {
	this.collegeName = collegeName;
}


public String getFromYear() {
	return fromYear;
}


public void setFromYear(String fromYear) {
	this.fromYear = fromYear;
}


public String getToYear() {
	return toYear;
}


public void setToYear(String toYear) {
	this.toYear = toYear;
}


public float getPercentage() {
	return percentage;
}


public void setPercentage(float percentage) {
	this.percentage = percentage;
}


public Employee getEmployee() {
	return employee;
}


public void setEmployee(Employee employee) {
	this.employee = employee;
}


@Override
public String toString() {
	return "EmployeeEducation [educationId=" + educationId + ", qualification=" + qualification + ", collegeName="
			+ collegeName + ", fromYear=" + fromYear + ", toYear=" + toYear + ", percentage=" + percentage
			+ ", employee=" + employee + "]";
}



}


  
