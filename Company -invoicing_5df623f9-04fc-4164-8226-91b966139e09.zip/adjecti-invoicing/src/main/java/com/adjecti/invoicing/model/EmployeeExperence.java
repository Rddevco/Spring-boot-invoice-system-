package com.adjecti.invoicing.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "tbl_employeexexperence")
public class EmployeeExperence {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer experenceId;
	@NotEmpty(message = "Please Enter The Company Name.")
	private String companyName;
	
	@NotEmpty(message = "Please Enter Date.")
	@Column(name = "fromDate")
	private String from;
	@NotEmpty(message = "Please Enter Date.")
	@Column(name = "toDate")
	private String to;
	
	@ManyToOne(fetch = FetchType.LAZY )
	@JoinColumn(name ="employeeId") 
	private Employee employee;
	
	public Integer getExperenceId() {
		return experenceId;
	}
	public void setExperenceId(Integer experenceId) {
		this.experenceId = experenceId;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public Employee getEmployee() {
		return employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	public EmployeeExperence(Integer experenceId,
			@NotEmpty(message = "Please Enter The Company Name.") String companyName,
			
			@NotEmpty(message = "Please Enter Date.") String from, @NotEmpty(message = "Please Enter Date.") String to,
			Employee employee) {
		super();
		this.experenceId = experenceId;
		this.companyName = companyName;
		this.from = from;
		this.to = to;
		this.employee = employee;
	}
	public EmployeeExperence(@NotEmpty(message = "Please Enter The Company Name.") String companyName,
			
			@NotEmpty(message = "Please Enter Date.") String from, @NotEmpty(message = "Please Enter Date.") String to,
			Employee employee) {
		super();
		this.companyName = companyName;
		this.from = from;
		this.to = to;
		this.employee = employee;
	}
	@Override
	public String toString() {
		return "EmployeeExperence [experenceId=" + experenceId + ", companyName=" + companyName
				+  ", from=" + from + ", to=" + to + ", employee="
				+ employee + "]";
	}
	public EmployeeExperence() {
		super();
		// TODO Auto-generated constructor stub
	} 
	
	
}
