package com.adjecti.invoicing.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import org.springframework.format.annotation.DateTimeFormat;

/**
 *
 * @author DELL PC
 */
@Entity
@Table(name = "tbl_invoice")
public class Invoice {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "termsConditions")
	private String termsConditions;

	@Column(name = "subTotal")
	private double subTotal;

	@Column(name = "serialNo")
	private int serialNo;

	@Column(name = "invoiceUpload")
	private String invoiceUpload;

	@Column(name = "invoiceNo")
	private String invoiceNo;

	@Column(name = "invoiceDate")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date invoiceDate;

	@Column(name = "instructions")
	private String instructions;

	@Column(name = "grandTotal")
	private double grandTotal;

	@Column(name = "dueDate")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date dueDate;

	@Column(name = "currency")
	private String currency;

	@Column(name = "createdDate")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date createdDate;

	@Column(name = "cancelled")
	private int cancelled;

	@Column(name = "balanceDue")
	private double balanceDue;

	@Column(name = "amountReceived")
	private double amountReceived;

	@Column(name = "advancePaid")
	private double advancePaid;

	@Column(name = "enabled")
	private int enabled;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL,orphanRemoval = true)
	@JoinColumn(name = "invoiceId")
	private List<InvoiceItem> invoiceItems;
	
	//@ManyToOne(cascade = { CascadeType.DETACH, CascadeType.MERGE, CascadeType.REFRESH })
	@ManyToOne
	@JoinColumn(name = "clientId")
	private Client client;

	@ManyToOne
	@JoinColumn(name = "purchaseOrderId")
	private PurchaseOrder purchaseOrder;
	
	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL,orphanRemoval = true)
	@JoinColumn(name = "invoiceId")
	private List<TaxItem> taxItems;

	public List<TaxItem> getTaxItems() {
		return taxItems;
	}

	public void setTaxItems(List<TaxItem> taxItems) {
		this.taxItems = taxItems;
	}

	public Invoice() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTermsAndConditions() {
		return termsConditions;
	}

	public void setTermsAndConditions(String termsConditions) {
		this.termsConditions = termsConditions;
	}

	public double getSubTotal() {
		return subTotal;
	}

	public void setSubTotal(double subTotal) {
		this.subTotal = subTotal;
	}

	public int getSerialNo() {
		return serialNo;
	}

	public void setSerialNo(int serialNo) {
		this.serialNo = serialNo;
	}

	public String getInvoiceUpload() {
		return invoiceUpload;
	}

	public void setInvoiceUpload(String invoiceUpload) {
		this.invoiceUpload = invoiceUpload;
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public Date getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getInstructions() {
		return instructions;
	}

	public void setInstructions(String instructions) {
		this.instructions = instructions;
	}

	public double getGrandTotal() {
		return grandTotal;
	}

	public void setGrandTotal(double grandTotal) {
		this.grandTotal = grandTotal;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public int getCancelled() {
		return cancelled;
	}

	public void setCancelled(int cancelled) {
		this.cancelled = cancelled;
	}

	public double getBalanceDue() {
		return balanceDue;
	}

	public void setBalanceDue(double balanceDue) {
		this.balanceDue = balanceDue;
	}

	public double getAmountReceived() {
		return amountReceived;
	}

	public void setAmountReceived(double amountReceived) {
		this.amountReceived = amountReceived;
	}

	public double getAdvancePaid() {
		return advancePaid;
	}

	public void setAdvancePaid(double advancePaid) {
		this.advancePaid = advancePaid;
	}

	public int getEnabled() {
		return enabled;
	}

	public void setEnabled(int enabled) {
		this.enabled = enabled;
	}

	public List<InvoiceItem> getInvoiceItems() {
		return invoiceItems;
	}

	public void setInvoiceItems(List<InvoiceItem> invoiceItems) {
		this.invoiceItems = invoiceItems;
	}

	public String getTermsConditions() {
		return termsConditions;
	}

	public void setTermsConditions(String termsConditions) {
		this.termsConditions = termsConditions;
	}

	public Client getClient() {
		return client;
	}

	public void setClient(Client client) {
		this.client = client;
	}

	public PurchaseOrder getPurchaseOrder() {
		return purchaseOrder;
	}

	public void setPurchaseOrder(PurchaseOrder purchaseOrder) {
		this.purchaseOrder = purchaseOrder;
	}

	public void add(InvoiceItem tempInvoiceItem) {
		if (invoiceItems == null) {
			invoiceItems = new ArrayList<>();
		}
		invoiceItems.add(tempInvoiceItem);
		// tempInvoiceItem.setInvoice(this);
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Invoice [id=").append(id).append(", termsConditions=").append(termsConditions)
				.append(", subTotal=").append(subTotal).append(", serialNo=").append(serialNo)
				.append(", invoiceUpload=").append(invoiceUpload).append(", invoiceNo=").append(invoiceNo)
				.append(", invoiceDate=").append(invoiceDate).append(", instructions=").append(instructions)
				.append(", grandTotal=").append(grandTotal).append(", dueDate=").append(dueDate).append(", currency=")
				.append(currency).append(", createdDate=").append(createdDate).append(", cancelled=").append(cancelled)
				.append(", balanceDue=").append(balanceDue).append(", amountReceived=").append(amountReceived)
				.append(", advancePaid=").append(advancePaid).append(", enabled=").append(enabled)
				.append(", invoiceItems=").append(invoiceItems).append(", client=").append(client)
				.append(", purchaseOrder=").append(purchaseOrder).append(", taxItems=").append(taxItems).append("]");
		return builder.toString();
	}

}
