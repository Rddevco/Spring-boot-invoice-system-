package com.adjecti.invoicing.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_jobApplication")
public class JobApplications {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(name = "name")
	private String name;

	@Column(name = "phone")
	private String phone;

	@Column(name = "email")
	private String email;

	@Column(name = "relevantExp")
	private String relevantExp;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
	@JoinColumn(name = "jobOpeningId")
	private JobOpening jobOpening;

	@Column(name = "currentCompany")
	private String currentCompany;

	@Column(name = "currentLocation")
	private String currentLocation;

	@Column(name = "noticePeroid")
	private String noticePeroid;

	@Column(name = "currentSalary")
	private String currentSalary;

	@Column(name = "expectedSalary")
	private String expectedSalary;

	@Column(name = "enabled")
	private Boolean enabled;

	public JobApplications() {
		super();
		// TODO Auto-generated constructor stub
	}

	public JobApplications(int id, String name, String phone, String email, String relevantExp, JobOpening jobOpening,
			String currentCompany, String currentLocation, String noticePeroid, String currentSalary,
			String expectedSalary, Boolean enabled) {
		super();
		this.id = id;
		this.name = name;
		this.phone = phone;
		this.email = email;
		this.relevantExp = relevantExp;
		this.jobOpening = jobOpening;
		this.currentCompany = currentCompany;
		this.currentLocation = currentLocation;
		this.noticePeroid = noticePeroid;
		this.currentSalary = currentSalary;
		this.expectedSalary = expectedSalary;
		this.enabled = enabled;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getRelevantExp() {
		return relevantExp;
	}

	public void setRelevantExp(String relevantExp) {
		this.relevantExp = relevantExp;
	}

	public JobOpening getJobOpening() {
		return jobOpening;
	}

	public void setJobOpening(JobOpening jobOpening) {
		this.jobOpening = jobOpening;
	}

	public String getCurrentCompany() {
		return currentCompany;
	}

	public void setCurrentCompany(String currentCompany) {
		this.currentCompany = currentCompany;
	}

	public String getCurrentLocation() {
		return currentLocation;
	}

	public void setCurrentLocation(String currentLocation) {
		this.currentLocation = currentLocation;
	}

	public String getNoticePeroid() {
		return noticePeroid;
	}

	public void setNoticePeroid(String noticePeroid) {
		this.noticePeroid = noticePeroid;
	}

	public String getCurrentSalary() {
		return currentSalary;
	}

	public void setCurrentSalary(String currentSalary) {
		this.currentSalary = currentSalary;
	}

	public String getExpectedSalary() {
		return expectedSalary;
	}

	public void setExpectedSalary(String expectedSalary) {
		this.expectedSalary = expectedSalary;
	}

	public Boolean getEnabled() {
		return enabled;
	}

	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}

	@Override
	public String toString() {
		return "JobApplications [id=" + id + ", name=" + name + ", phone=" + phone + ", email=" + email
				+ ", relevantExp=" + relevantExp + ", jobOpening=" + jobOpening + ", currentCompany=" + currentCompany
				+ ", currentLocation=" + currentLocation + ", noticePeroid=" + noticePeroid + ", currentSalary="
				+ currentSalary + ", expectedSalary=" + expectedSalary + ", enabled=" + enabled + "]";
	}

	
}
