package com.adjecti.invoicing.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "tbl_leave")
public class Leave {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Integer id;
@NotEmpty(message = "Please enter the EmployeeName Value")
private String employeeName;
@NotEmpty(message = "Please enter the FromDate Value")
private String fromDate ;
@NotEmpty(message = "Please enter the ToDate Value")
private String toDate;
@NotNull
@Min(value = 1,message = "At Least One Day Leave Is Monimum.")
@Max(value = 30,message = "We are providing maximum 30 days leave only.")
private Integer noOfDays; 
private boolean  halfday;
private boolean status;
@ManyToOne(fetch = FetchType.LAZY,cascade = {CascadeType.DETACH,CascadeType.MERGE,CascadeType.PERSIST,CascadeType.REFRESH})
@JoinColumn(name="employee_id")
private Employee employee;
public Leave() {
	super();
	// TODO Auto-generated constructor stub
}
public Leave(Integer id, @NotEmpty(message = "Please enter the EmployeeName Value") String employeeName,
		@NotEmpty(message = "Please enter the FromDate Value") String fromDate,
		@NotEmpty(message = "Please enter the ToDate Value") String toDate,
		@NotNull @Min(value = 1, message = "At Least One Day Leave Is Monimum.") @Max(value = 30, message = "We are providing maximum 30 days leave only.") Integer noOfDays,
		boolean halfday, boolean status, Employee employee_id) {
	super();
	this.id = id;
	this.employeeName = employeeName;
	this.fromDate = fromDate;
	this.toDate = toDate;
	this.noOfDays = noOfDays;
	this.halfday = halfday;
	this.status = status;
	this.employee = employee_id;
}
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public String getEmployeeName() {
	return employeeName;
}
public void setEmployeeName(String employeeName) {
	this.employeeName = employeeName;
}
public String getFromDate() {
	return fromDate;
}
public void setFromDate(String fromDate) {
	this.fromDate = fromDate;
}
public String getToDate() {
	return toDate;
}
public void setToDate(String toDate) {
	this.toDate = toDate;
}
public Integer getNoOfDays() {
	return noOfDays;
}
public void setNoOfDays(Integer noOfDays) {
	this.noOfDays = noOfDays;
}
public boolean isHalfday() {
	return halfday;
}
public void setHalfday(boolean halfday) {
	this.halfday = halfday;
}
public boolean isStatus() {
	return status;
}
public void setStatus(boolean status) {
	this.status = status;
}
public Employee getEmployee_id() {
	return employee;
}
public void setEmployee_id(Employee employee_id) {
	this.employee = employee_id;
}


}
