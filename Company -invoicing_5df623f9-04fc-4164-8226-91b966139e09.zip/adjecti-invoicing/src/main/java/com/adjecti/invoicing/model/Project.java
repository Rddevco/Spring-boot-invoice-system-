package com.adjecti.invoicing.model;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
//import javax.persistence.OneToMany;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "tbl_project")
public class Project {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	private int id;
	@Column(name = "description")
	private String description;
	@Column(name = "endDate")
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date endDate;
	@Column(name = "startDate")
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date startDate;
	@Column(name = "name")
	private String name;
	@Column(name = "sowUrl")
	private String sowUrl;
	@OneToOne
	@JoinColumn(name = "billingCycleId")
	private BillingCycle billingcycle;
	@OneToOne
	@JoinColumn(name = "billingTypeId")
	private BillingType billingtype;
	
	@OneToOne
	@JoinColumn(name = "clientId")
	private Client client;
	
	private Boolean enabled;
	
	@OneToOne
	@JoinColumn(name = "purchaseOrderId", unique=false)
	private PurchaseOrder purchaseorder;
	@Column(name = "createdDate")
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date createdDate;
	//@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	//@JoinTable(name = "tbl_project_technology")
	//@JoinColumn(name = "Technology_id")
	
	@ManyToMany(fetch = FetchType.LAZY,cascade = {CascadeType.MERGE})
	 @JoinTable(name = "tbl_project_technology", joinColumns = { @JoinColumn(name =
	  "ProjectId",referencedColumnName="id")}, inverseJoinColumns =
	  { @JoinColumn(name = "technologyId", referencedColumnName="id", unique=false)})
	private List<Technology> technology;

	
   
	public Boolean getEnabled() {
		return enabled;
	}
	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}
	public List<Technology> getTechnology() {
		return technology;
	}

	public void setTechnology(List<Technology> technology) {
		this.technology = technology;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSowUrl() {
		return sowUrl;
	}

	public void setSowUrl(String sowUrl) {
		this.sowUrl = sowUrl;
	}

	
	public BillingCycle getBillingcycle() {
		return billingcycle;
	}

	public void setBillingcycle(BillingCycle billingcycle) {
		this.billingcycle = billingcycle;
	}

	public BillingType getBillingtype() {
		return billingtype;
	}

	public void setBillingtype(BillingType billingtype) {
		this.billingtype = billingtype;
	}

	public Client getClient() {
		return client;
	}

	public void setClient(Client client) {
		this.client = client;
	}

	
	public PurchaseOrder getPurchaseorder() {
		return purchaseorder;
	}
	public void setPurchaseorder(PurchaseOrder purchaseorder) {
		this.purchaseorder = purchaseorder;
	}
	@Override
	public String toString() {
		return "Project [id=" + id + ", description=" + description + ", endDate=" + endDate + ", startDate="
				+ startDate + ", name=" + name + ", sowUrl=" + sowUrl + ", billingcycle=" + billingcycle
				+ ", billingtype=" + billingtype + ", client=" + client + ", enabled=" + enabled + ", purchaseorder="
				+ purchaseorder + ", createdDate=" + createdDate + ", technology=" + technology + "]";
	}

	

}