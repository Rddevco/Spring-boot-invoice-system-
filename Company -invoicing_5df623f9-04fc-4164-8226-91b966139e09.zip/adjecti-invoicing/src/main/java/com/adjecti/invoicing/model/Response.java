package com.adjecti.invoicing.model;

public class Response {

	private String field;
	private String statusMessage;
	private String defaultMessage;
	public String getField() {
		return field;
	}
	@Override
	public String toString() {
		return "Response [field=" + field + ", statusMessage=" + statusMessage + ", defaultMessage=" + defaultMessage
				+ "]";
	}
	public Response(String field, String statusMessage, String defaultMessage) {
		super();
		this.field = field;
		this.statusMessage = statusMessage;
		this.defaultMessage = defaultMessage;
	}
	public void setField(String field) {
		this.field = field;
	}
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	public String getDefaultMessage() {
		return defaultMessage;
	}
	public void setDefaultMessage(String defaultMessage) {
		this.defaultMessage = defaultMessage;
	}
	public Response() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
