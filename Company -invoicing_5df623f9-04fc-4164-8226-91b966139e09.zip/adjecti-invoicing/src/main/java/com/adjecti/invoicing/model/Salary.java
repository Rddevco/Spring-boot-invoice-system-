package com.adjecti.invoicing.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_savesalary")
public class Salary {


	public Salary() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idNo;
	
	private String name;
	private String designation;
	private String department;
	private String processingMonth;
	private String workingDays;
	private String leaveDays;
	private String dayPresent;
	private String cLBal;
	private String eLBal;
	private String currentMonthsSalaryReimb;
	private String basic;
	private String hRA;
	private String tA;
	private String sA;
	private String technical;
	private String medical;
	private String otherReimbursements;
	private String arears;
	private String tDS;
	private String pFCompany;
	private String pFEmployer;
	private String advance;
	private String foodParking;
	private String gratuity;
	private String earnings;
	private String deductions;
	private String netSalary;
	private String paymentMode;
	private String bank;
	private String accountNo;
	private String refNo;
	private String accessKey;
	private boolean flag;
	
	
	
	
	
	public Salary(Integer idNo, String name, String designation, String department, String processingMonth,
			String workingDays, String leaveDays, String dayPresent, String cLBal, String eLBal,
			String currentMonthsSalaryReimb, String basic, String hRA, String tA, String sA, String technical,
			String medical, String otherReimbursements, String arears, String tDS, String pFCompany, String pFEmployer,
			String advance, String foodParking, String gratuity, String earnings, String deductions, String netSalary,
			String paymentMode, String bank, String accountNo, String refNo, String accessKey, boolean flag) {
		super();
		this.idNo = idNo;
		this.name = name;
		this.designation = designation;
		this.department = department;
		this.processingMonth = processingMonth;
		this.workingDays = workingDays;
		this.leaveDays = leaveDays;
		this.dayPresent = dayPresent;
		this.cLBal = cLBal;
		this.eLBal = eLBal;
		this.currentMonthsSalaryReimb = currentMonthsSalaryReimb;
		this.basic = basic;
		this.hRA = hRA;
		this.tA = tA;
		this.sA = sA;
		this.technical = technical;
		this.medical = medical;
		this.otherReimbursements = otherReimbursements;
		this.arears = arears;
		this.tDS = tDS;
		this.pFCompany = pFCompany;
		this.pFEmployer = pFEmployer;
		this.advance = advance;
		this.foodParking = foodParking;
		this.gratuity = gratuity;
		this.earnings = earnings;
		this.deductions = deductions;
		this.netSalary = netSalary;
		this.paymentMode = paymentMode;
		this.bank = bank;
		this.accountNo = accountNo;
		this.refNo = refNo;
		this.accessKey = accessKey;
		this.flag = flag;
	}
	
	public Salary(String name, String designation, String department, String processingMonth, String workingDays,
			String leaveDays, String dayPresent, String cLBal, String eLBal, String currentMonthsSalaryReimb,
			String basic, String hRA, String tA, String sA, String technical, String medical,
			String otherReimbursements, String arears, String tDS, String pFCompany, String pFEmployer, String advance,
			String foodParking, String gratuity, String earnings, String deductions, String netSalary,
			String paymentMode, String bank, String accountNo, String refNo, String accessKey) {
		super();
		this.name = name;
		this.designation = designation;
		this.department = department;
		this.processingMonth = processingMonth;
		this.workingDays = workingDays;
		this.leaveDays = leaveDays;
		this.dayPresent = dayPresent;
		this.cLBal = cLBal;
		this.eLBal = eLBal;
		this.currentMonthsSalaryReimb = currentMonthsSalaryReimb;
		this.basic = basic;
		this.hRA = hRA;
		this.tA = tA;
		this.sA = sA;
		this.technical = technical;
		this.medical = medical;
		this.otherReimbursements = otherReimbursements;
		this.arears = arears;
		this.tDS = tDS;
		this.pFCompany = pFCompany;
		this.pFEmployer = pFEmployer;
		this.advance = advance;
		this.foodParking = foodParking;
		this.gratuity = gratuity;
		this.earnings = earnings;
		this.deductions = deductions;
		this.netSalary = netSalary;
		this.paymentMode = paymentMode;
		this.bank = bank;
		this.accountNo = accountNo;
		this.refNo = refNo;
		this.accessKey = accessKey;
	}

	@Override
	public String toString() {
		return "Salary [idNo=" + idNo + ", name=" + name + ", designation=" + designation + ", department=" + department
				+ ", processingMonth=" + processingMonth + ", workingDays=" + workingDays + ", leaveDays=" + leaveDays
				+ ", dayPresent=" + dayPresent + ", cLBal=" + cLBal + ", eLBal=" + eLBal + ", currentMonthsSalaryReimb="
				+ currentMonthsSalaryReimb + ", basic=" + basic + ", hRA=" + hRA + ", tA=" + tA + ", sA=" + sA
				+ ", technical=" + technical + ", medical=" + medical + ", otherReimbursements=" + otherReimbursements
				+ ", arears=" + arears + ", tDS=" + tDS + ", pFCompany=" + pFCompany + ", pFEmployer=" + pFEmployer
				+ ", advance=" + advance + ", foodParking=" + foodParking + ", gratuity=" + gratuity + ", earnings="
				+ earnings + ", deductions=" + deductions + ", netSalary=" + netSalary + ", paymentMode=" + paymentMode
				+ ", bank=" + bank + ", accountNo=" + accountNo + ", refNo=" + refNo + ", accessKey=" + accessKey
				+ ", flag=" + flag + "]";
	}
	public Integer getIdNo() {
		return idNo;
	}
	public void setIdNo(Integer idNo) {
		this.idNo = idNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getProcessingMonth() {
		return processingMonth;
	}
	public void setProcessingMonth(String processingMonth) {
		this.processingMonth = processingMonth;
	}
	public String getWorkingDays() {
		return workingDays;
	}
	public void setWorkingDays(String workingDays) {
		this.workingDays = workingDays;
	}
	public String getLeaveDays() {
		return leaveDays;
	}
	public void setLeaveDays(String leaveDays) {
		this.leaveDays = leaveDays;
	}
	public String getDayPresent() {
		return dayPresent;
	}
	public void setDayPresent(String dayPresent) {
		this.dayPresent = dayPresent;
	}
	public String getcLBal() {
		return cLBal;
	}
	public void setcLBal(String cLBal) {
		this.cLBal = cLBal;
	}
	public String geteLBal() {
		return eLBal;
	}
	public void seteLBal(String eLBal) {
		this.eLBal = eLBal;
	}
	public String getCurrentMonthsSalaryReimb() {
		return currentMonthsSalaryReimb;
	}
	public void setCurrentMonthsSalaryReimb(String currentMonthsSalaryReimb) {
		this.currentMonthsSalaryReimb = currentMonthsSalaryReimb;
	}
	public String getBasic() {
		return basic;
	}
	public void setBasic(String basic) {
		this.basic = basic;
	}
	public String gethRA() {
		return hRA;
	}
	public void sethRA(String hRA) {
		this.hRA = hRA;
	}
	public String gettA() {
		return tA;
	}
	public void settA(String tA) {
		this.tA = tA;
	}
	public String getsA() {
		return sA;
	}
	public void setsA(String sA) {
		this.sA = sA;
	}
	public String getTechnical() {
		return technical;
	}
	public void setTechnical(String technical) {
		this.technical = technical;
	}
	public String getMedical() {
		return medical;
	}
	public void setMedical(String medical) {
		this.medical = medical;
	}
	public String getOtherReimbursements() {
		return otherReimbursements;
	}
	public void setOtherReimbursements(String otherReimbursements) {
		this.otherReimbursements = otherReimbursements;
	}
	public String getArears() {
		return arears;
	}
	public void setArears(String arears) {
		this.arears = arears;
	}
	public String gettDS() {
		return tDS;
	}
	public void settDS(String tDS) {
		this.tDS = tDS;
	}
	public String getpFCompany() {
		return pFCompany;
	}
	public void setpFCompany(String pFCompany) {
		this.pFCompany = pFCompany;
	}
	public String getpFEmployer() {
		return pFEmployer;
	}
	public void setpFEmployer(String pFEmployer) {
		this.pFEmployer = pFEmployer;
	}
	public String getAdvance() {
		return advance;
	}
	public void setAdvance(String advance) {
		this.advance = advance;
	}
	public String getFoodParking() {
		return foodParking;
	}
	public void setFoodParking(String foodParking) {
		this.foodParking = foodParking;
	}
	public String getGratuity() {
		return gratuity;
	}
	public void setGratuity(String gratuity) {
		this.gratuity = gratuity;
	}
	public String getEarnings() {
		return earnings;
	}
	public void setEarnings(String earnings) {
		this.earnings = earnings;
	}
	public String getDeductions() {
		return deductions;
	}
	public void setDeductions(String deductions) {
		this.deductions = deductions;
	}
	public String getNetSalary() {
		return netSalary;
	}
	public void setNetSalary(String netSalary) {
		this.netSalary = netSalary;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getBank() {
		return bank;
	}
	public void setBank(String bank) {
		this.bank = bank;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getRefNo() {
		return refNo;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	public String getAccessKey() {
		return accessKey;
	}
	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}
	public boolean isFlag() {
		return flag;
	}
	public void setFlag(boolean flag) {
		this.flag = flag;
	}
	
	
	
	
	
	
}
