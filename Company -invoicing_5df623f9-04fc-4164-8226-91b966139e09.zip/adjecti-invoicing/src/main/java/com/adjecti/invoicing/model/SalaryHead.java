package com.adjecti.invoicing.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "tbl_salaryHead")
public class SalaryHead {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	private boolean active;
	@NotEmpty(message = "Code is  required")
		private String code;
	@NotEmpty(message = "Name is  required")
	private String name;
	@NotNull(message = "Period is  required")
	private Integer period;
	@NotNull(message = "Type is  required")
	private Integer type;
	@NotNull(message = "DisbursePeriod is  required")
	private Integer disbursePeriod;
	
	private boolean nonTaxable;
    private  boolean status;
	public SalaryHead() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SalaryHead(Integer id,  boolean active,
			@NotEmpty(message = "Code is  required") String code, @NotEmpty(message = "Name is  required") String name,
			@NotEmpty(message = "Period is  required") Integer period,
			@NotNull(message = "Type is  required") Integer type,
			@NotEmpty(message = "DisbursePeriod is  required") Integer disbursePeriod,
			boolean nonTaxable, boolean status) {
		super();
		this.id = id;
		this.active = active;
		this.code = code;
		this.name = name;
		this.period = period;
		this.type = type;
		this.disbursePeriod = disbursePeriod;
		this.nonTaxable = nonTaxable;
		this.status = status;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getPeriod() {
		return period;
	}
	public void setPeriod(Integer period) {
		this.period = period;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public Integer getDisbursePeriod() {
		return disbursePeriod;
	}
	public void setDisbursePeriod(Integer disbursePeriod) {
		this.disbursePeriod = disbursePeriod;
	}
	public boolean isNonTaxable() {
		return nonTaxable;
	}
	public void setNonTaxable(boolean nonTaxable) {
		this.nonTaxable = nonTaxable;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "SalaryHead [id=" + id + ", active=" + active + ", code=" + code + ", name=" + name + ", period="
				+ period + ", type=" + type + ", disbursePeriod=" + disbursePeriod + ", nonTaxable=" + nonTaxable
				+ ", status=" + status + "]";
	}
	
	

}
