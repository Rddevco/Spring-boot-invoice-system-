package com.adjecti.invoicing.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name = "tbl_structureform")
public class SalaryStructure {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	 private Integer id;
	@NotEmpty(message = "Name is  required")
	 private String name;
	@NotEmpty(message="Date must be required")
	 private String fromDate;
	@NotEmpty(message="Date must be required")
	 private String toDate;
	@NotEmpty(message="Currency is required")
	 private String currency;
	 private boolean status;
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
		System.out.print(fromDate);
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		System.out.print(toDate);
		this.toDate = toDate;
		
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	
	public SalaryStructure() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SalaryStructure(Integer id, String name, String fromDate, String toDate, String currency, boolean status) {
		super();
		this.id = id;
		this.name = name;
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.currency = currency;
		this.status = status;
	}
	@Override
	public String toString() {
		return "SalaryStructure [id=" + id + ", name=" + name + ", fromDate=" + fromDate + ", toDate=" + toDate
				+ ", currency=" + currency + ", status=" + status + "]";
	}
	
}
