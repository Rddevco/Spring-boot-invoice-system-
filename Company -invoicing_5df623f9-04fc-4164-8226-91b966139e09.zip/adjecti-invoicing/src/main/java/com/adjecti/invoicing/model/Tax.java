/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.adjecti.invoicing.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

/**
 *
 * @author DELL PC
 */

@Entity
@Table(name = "tbl_tax")
public class Tax {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	private Integer active;

	@Column(name = "createdDate")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date createdDate;

	@Column(name = "effectiveDate")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date effectiveDate;

	@Column(name = "ineffectiveDate")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date ineffectiveDate;

	@Column(name = "name")
	private String name;

	@Column(name = "rate")
	private double rate;

	@Column(name = "type")
	private String type;

	public Tax() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Integer getActive() {
		return active;
	}

	public void setActive(Integer active) {
		this.active = active;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Date getIneffectiveDate() {
		return ineffectiveDate;
	}

	public void setIneffectiveDate(Date ineffectiveDate) {
		this.ineffectiveDate = ineffectiveDate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	
	  @Override 
	  public String toString() 
	  { StringBuilder sb = new StringBuilder();
	  sb.append("Tax{id=").append(id); sb.append(", active=").append(active);
	  sb.append(", createdDate=").append(createdDate);
	  sb.append(", effectiveDate=").append(effectiveDate);
	  sb.append(", ineffectiveDate=").append(ineffectiveDate);
	  sb.append(", name=").append(name); sb.append(", rate=").append(rate);
	  sb.append(", type=").append(type); sb.append('}'); return sb.toString(); }
	  
	 

}
