package com.adjecti.invoicing.repository;



import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.adjecti.invoicing.model.ConsultantPayment;


public interface ConsultantPaymentRepository extends JpaRepository<ConsultantPayment,Integer>{
	@Transactional
	@Modifying
	@Query(value = "update tbl_consultant_payment set enabled=?1 WHERE id = ?2", nativeQuery = true)
	public void delete(Boolean status,int id);
	
	@Query(value="select * from tbl_consultant_payment where enabled=?1",nativeQuery = true)
	public List<ConsultantPayment> getConsultantPayment(Boolean enabled);
}
