package com.adjecti.invoicing.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.adjecti.invoicing.model.Consultant;

public interface ConsultantRepository extends JpaRepository<Consultant, Integer> {
	
	@Transactional
	@Modifying
	@Query(value = "update tbl_consultant set enabled=?1 WHERE id = ?2", nativeQuery = true)
	void deleteById(Boolean status,int id);
	
	@Query(value="select * from tbl_consultant where enabled=?1",nativeQuery = true)
	public List<Consultant> findAll(Boolean enabled);
}
