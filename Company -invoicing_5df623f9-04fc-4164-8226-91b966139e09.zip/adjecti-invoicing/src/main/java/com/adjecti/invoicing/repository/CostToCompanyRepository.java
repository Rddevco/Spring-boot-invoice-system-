package com.adjecti.invoicing.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.adjecti.invoicing.model.CostToCompanySalary;
@Repository
public interface CostToCompanyRepository extends JpaRepository<CostToCompanySalary, Integer> {

}
