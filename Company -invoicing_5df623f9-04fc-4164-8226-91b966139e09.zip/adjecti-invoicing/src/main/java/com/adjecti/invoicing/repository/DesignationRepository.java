package com.adjecti.invoicing.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.adjecti.invoicing.model.Designation;

public interface DesignationRepository extends JpaRepository<Designation, Integer>{

}
