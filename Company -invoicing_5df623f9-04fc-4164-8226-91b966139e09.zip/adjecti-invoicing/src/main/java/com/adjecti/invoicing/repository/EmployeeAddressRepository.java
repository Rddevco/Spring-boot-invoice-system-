package com.adjecti.invoicing.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.adjecti.invoicing.model.EmployeeAddress;


public interface EmployeeAddressRepository extends JpaRepository<EmployeeAddress, Integer>
{
@Query(value = "select * from adjerp.tbl_employeeaddress where employeeId=:id",nativeQuery = true)
List<EmployeeAddress>	findByEmployeeId(Integer id);
}
