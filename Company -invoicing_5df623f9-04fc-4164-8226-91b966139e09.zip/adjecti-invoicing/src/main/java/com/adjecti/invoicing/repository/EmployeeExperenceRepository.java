package com.adjecti.invoicing.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


import com.adjecti.invoicing.model.EmployeeExperence;

public interface EmployeeExperenceRepository extends JpaRepository<EmployeeExperence, Integer>{

	@Query(value = "select * from adjerp.tbl_employeexexperence where employeeId=:id",nativeQuery = true)
	List<EmployeeExperence>	findByEmployeeId(Integer id);
}
