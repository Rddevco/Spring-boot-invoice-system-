package com.adjecti.invoicing.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.adjecti.invoicing.model.Leave;

public interface LeaveRepository extends JpaRepository<Leave, Integer>{
	
	@Query(value = "select * from adjerp.tbl_leave where employee_id=:eid",nativeQuery = true)    
	List<Leave> findByEmployeeId(Integer eid);
	

}
