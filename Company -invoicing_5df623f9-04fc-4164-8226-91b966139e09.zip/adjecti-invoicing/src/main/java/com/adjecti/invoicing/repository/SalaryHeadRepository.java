package com.adjecti.invoicing.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.adjecti.invoicing.model.SalaryHead;

public interface SalaryHeadRepository extends JpaRepository<SalaryHead, Integer> {

}
