package com.adjecti.invoicing.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.adjecti.invoicing.model.Tax;

public interface TaxRepository extends JpaRepository<Tax, Integer>{

      Tax findByName(String name);

}
