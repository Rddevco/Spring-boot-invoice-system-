package com.adjecti.invoicing.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;


import com.adjecti.invoicing.model.YearlyLeave;

public interface YearlyLeaveRepository extends JpaRepository<YearlyLeave,Integer>{
	@Transactional
	@Modifying
	@Query(value = "update tbl_yearlyleave set enabled=?1 WHERE id = ?2", nativeQuery = true)
	public void delete(Boolean status,int id);
	
	@Query(value="select * from tbl_yearlyleave where enabled=?1",nativeQuery = true)
	public List<YearlyLeave> getYearlyLeave(Boolean enabled);
}
