package com.adjecti.invoicing.response;

import org.springframework.stereotype.Component;

@Component
public class Response {

	//private boolean validated;
	private String fieldName;
	private String errorMsg;
	public String statusMessage;
	
	public Response() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Response(String fieldName, String errorMsg, String statusMessage) {
		super();
		this.fieldName = fieldName;
		this.errorMsg = errorMsg;
		this.statusMessage = statusMessage;
	}

	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

}