package com.adjecti.invoicing.service;

import java.util.List;

import com.adjecti.invoicing.dto.AddressTypeDto;

public interface AddressTypeService {

	public AddressTypeDto save(AddressTypeDto AddressTypeDto);
	public List<AddressTypeDto> getAddressTypes();
	void delete(long id);
	void update(AddressTypeDto addressTypeDto);
	AddressTypeDto findById(long id);

	
}
