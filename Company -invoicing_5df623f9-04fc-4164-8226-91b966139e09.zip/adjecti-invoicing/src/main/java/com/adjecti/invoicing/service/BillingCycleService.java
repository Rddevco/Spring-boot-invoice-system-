package com.adjecti.invoicing.service;

import java.util.List;

import com.adjecti.invoicing.dto.BillingCycleDto;

public interface BillingCycleService {

	public BillingCycleDto save(BillingCycleDto billingCycle);
	public List<BillingCycleDto> getAllBillingCycle();
	public void delete(int id);

	BillingCycleDto findById(int id);
	public void update(BillingCycleDto billingCycledto);

}