package com.adjecti.invoicing.service;

import java.util.List;

import com.adjecti.invoicing.dto.ClientPurchaseOrderItemDto;

public interface ClientPurchaseOrderItemSerice {

	List<ClientPurchaseOrderItemDto> getAllCLientPoItem();
	void save(ClientPurchaseOrderItemDto clientPurchaseOrderItemDto);
	void delete(int id);
	ClientPurchaseOrderItemDto getAllCLientPoItem(int id);
}
