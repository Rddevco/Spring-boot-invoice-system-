package com.adjecti.invoicing.service;

import java.util.List;

import com.adjecti.invoicing.dto.CompanyTypeDto;

public interface CompanyTypeService {
	
	public CompanyTypeDto save(CompanyTypeDto companyTypeDto);
	public List<CompanyTypeDto> getCompanyList();
	public void delete(Integer id);
	void update(CompanyTypeDto companyTypeDto);
	public CompanyTypeDto findById(int id);

}
