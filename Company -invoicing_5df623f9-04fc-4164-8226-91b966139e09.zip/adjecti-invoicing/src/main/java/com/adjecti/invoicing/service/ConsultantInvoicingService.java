package com.adjecti.invoicing.service;


import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.adjecti.invoicing.dto.ConsultantInvoicingDto;

public interface ConsultantInvoicingService {
	
	public ConsultantInvoicingDto save(ConsultantInvoicingDto consultantInvoicingDto, MultipartFile file);
	public List<ConsultantInvoicingDto> findAll();
	public void deleteConsultantInvoicing(Integer id);
	public ConsultantInvoicingDto findByid(int id);
	public void update(ConsultantInvoicingDto consultantInvoicingDto);
	
	
}
