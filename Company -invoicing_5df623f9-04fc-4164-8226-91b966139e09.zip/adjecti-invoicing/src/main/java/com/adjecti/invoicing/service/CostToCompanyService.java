package com.adjecti.invoicing.service;

import java.util.List;

import javax.validation.Valid;

import com.adjecti.invoicing.model.CostToCompanySalary;


public interface CostToCompanyService {

	public CostToCompanySalary forUpdateCostToCompanySalary(@Valid CostToCompanySalary costtocompanysalary);

	
	public List<CostToCompanySalary> getList();


	


	public CostToCompanySalary getBYId(Integer id);


	public String getSalaryByIdForDelete(Integer idNo);
	  

}
