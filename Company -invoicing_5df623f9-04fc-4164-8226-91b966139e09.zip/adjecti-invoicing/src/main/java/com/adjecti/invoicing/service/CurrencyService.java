package com.adjecti.invoicing.service;

import java.util.List;

import com.adjecti.invoicing.dto.CurrencyDto;

public interface CurrencyService {
	
	public CurrencyDto saveCurrency(CurrencyDto currencyDto);
	public List<CurrencyDto> findAll();
	void update(CurrencyDto currencyDto);
	void delete(Integer id);
	public CurrencyDto findById(Integer id);
}
