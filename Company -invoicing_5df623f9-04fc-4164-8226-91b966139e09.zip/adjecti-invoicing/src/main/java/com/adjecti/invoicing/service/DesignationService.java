package com.adjecti.invoicing.service;

import java.util.List;

import com.adjecti.invoicing.model.Designation;

public interface DesignationService {

public	Designation save(Designation designation);

public Designation delete(Integer designationId);

public List<Designation> getList();

public Designation fetchDesignation(Integer designationId);

}
