package com.adjecti.invoicing.service;


import java.util.List;

import com.adjecti.invoicing.model.EmployeeAddress;

public interface EmployeeAddressService {

public	EmployeeAddress saveEmployee(EmployeeAddress employeeAddress);



public EmployeeAddress fetchEmployee(Integer id);



public List<EmployeeAddress> fetchEmployeeAddress(Integer id);



public String deleteEmployee(Integer id);

}
