package com.adjecti.invoicing.service;

import java.util.List;

import javax.validation.Valid;

import com.adjecti.invoicing.model.EmployeeEducation;

public interface EmployeeEducationService {

	/*
	 * EmployeeEducation fetchEducationExperence(Integer id);
	 */
	
	EmployeeEducation saveEmployeeEducation(@Valid EmployeeEducation employeeEducation);


	EmployeeEducation fetchEducation(Integer id);


	List<EmployeeEducation> fetchEmployee(Integer id);

	boolean deleteEmployeeExperence(Integer id);

}
