package com.adjecti.invoicing.service;


import java.util.List;

import com.adjecti.invoicing.model.EmployeeExperence;

public interface EmployeeExperenceService {

	EmployeeExperence saveEmployeeExperence(EmployeeExperence employeeExperence);

	List<EmployeeExperence> fetchEmployeeExperence(Integer id);

	EmployeeExperence fetchEmployee(Integer id);

	

	String deleteEmployeeExperence(Integer id);

}
