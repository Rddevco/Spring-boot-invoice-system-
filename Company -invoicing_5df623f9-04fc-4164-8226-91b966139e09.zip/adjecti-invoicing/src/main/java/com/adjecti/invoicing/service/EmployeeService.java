package com.adjecti.invoicing.service;

import java.util.List;

import com.adjecti.invoicing.model.Employee;
import com.adjecti.invoicing.model.Leave;

public interface EmployeeService {

	public Employee saveEmployee(Employee employee);

	public List<Employee> getEmployees();

	public String deleteEmployee(Integer id);

	public Employee fetchEmployee(Integer id);

	

}
