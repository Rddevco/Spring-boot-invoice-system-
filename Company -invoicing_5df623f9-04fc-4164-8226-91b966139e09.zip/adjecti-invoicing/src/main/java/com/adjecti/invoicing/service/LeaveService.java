package com.adjecti.invoicing.service;

import java.util.List;

import com.adjecti.invoicing.model.Leave;

public interface LeaveService {

	public Leave saveLeave(Leave leave);

	public List<Leave> getLeaves(Integer eid);

	public String deleteEmployee(Integer id);

	public Leave fetchEmployee(Integer id);

}
