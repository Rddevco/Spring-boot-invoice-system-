package com.adjecti.invoicing.service;

import java.util.List;

import com.adjecti.invoicing.dto.PaymentModeDto;


public interface PaymentModeService {
	
	
	
	public List<PaymentModeDto>getAllPayment();
    public PaymentModeDto save(PaymentModeDto PaymentModeDto );
	public PaymentModeDto findById(int id);
	public void update(PaymentModeDto paymentmode);
	void delete(int id);
}
