package com.adjecti.invoicing.service;

import java.util.List;
import com.adjecti.invoicing.dto.PurchaseOrderDto;

public interface PurchaseOrderService {

	void save(PurchaseOrderDto purchaseOrderDto);
	List<PurchaseOrderDto> getAllPurchaseOrder();
	PurchaseOrderDto getPurchaseOrder(int id);
	void deletePurchaseOrder(int id);

}