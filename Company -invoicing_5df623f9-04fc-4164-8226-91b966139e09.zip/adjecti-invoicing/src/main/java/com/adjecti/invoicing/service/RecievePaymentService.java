package com.adjecti.invoicing.service;

import java.util.List;


import com.adjecti.invoicing.dto.RecievePaymentDto;

public interface RecievePaymentService {

	public List<RecievePaymentDto> getRecievePayment();

	public void delete(int id);
	public void save(RecievePaymentDto recievepaymentdto);
	public RecievePaymentDto getRecievePayment(int id);
	
}
