package com.adjecti.invoicing.service;

import java.util.List;

import com.adjecti.invoicing.model.SalaryHead;
import com.adjecti.invoicing.model.SalaryStructure;

public interface SalaryHeadService {
	public String save(SalaryHead salaryHead);
	
	public List<SalaryHead> fetchAll();

	public SalaryHead getSalaryById(Integer id);

	public String delete(Integer id);
}
