package com.adjecti.invoicing.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.adjecti.invoicing.model.CostToCompanySalary;
import com.adjecti.invoicing.model.Salary;

public interface SalaryService {

	public void upload(MultipartFile file) throws Exception;
	 public List<Salary> get();


	public String getSalaryByIdForDelete(Integer idNo);

	/*
	 * public Salary ForUpdateStructureSalary(Integer idNo,SalaryStructue
	 * salaryStructure);
	 */
    public Salary getSalaryById(Integer id);
	/*
	 * public Salary ForUpdateCostToCompanySalary(CostToCompanySalary
	 * costToCompanySalary);
	 */
}
