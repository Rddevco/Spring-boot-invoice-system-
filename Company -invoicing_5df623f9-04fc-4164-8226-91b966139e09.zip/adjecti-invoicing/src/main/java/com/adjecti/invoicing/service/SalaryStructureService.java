package com.adjecti.invoicing.service;

import java.util.List;


import com.adjecti.invoicing.model.SalaryStructure;


public interface SalaryStructureService {
	public String save(SalaryStructure structureFor);
	public List<SalaryStructure> get();
	public SalaryStructure getSalaryById(Integer id);
	public String delete(Integer id);
}
