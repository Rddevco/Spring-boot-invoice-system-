package com.adjecti.invoicing.service;

import java.util.List;

import com.adjecti.invoicing.dto.TaxDto;
import com.adjecti.invoicing.model.Tax;


public interface TaxService {
   
	public List<TaxDto> findAll();
	
	public TaxDto save(TaxDto tax);
	
	public void delete(int id);
	
	public TaxDto findById(int id);
	
	public Tax findByName(String name);
	
}
