package com.adjecti.invoicing.service;

import java.util.List;

import com.adjecti.invoicing.dto.TechnologyDto;

public interface TechnologyService {
	public TechnologyDto save(TechnologyDto technologyDto);
	public List<TechnologyDto> findAll();
	public void delete(Integer id);
	
	void update(TechnologyDto billingTypedto);
	public TechnologyDto findById(int id);
}
