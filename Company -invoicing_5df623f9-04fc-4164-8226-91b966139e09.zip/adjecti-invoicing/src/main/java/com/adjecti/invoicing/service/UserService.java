package com.adjecti.invoicing.service;

import com.adjecti.invoicing.model.User;

public interface UserService {
	void save(User user);

	User findByUsername(String username);
}
