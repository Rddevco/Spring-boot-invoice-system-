package com.adjecti.invoicing.service;

import java.util.List;

import com.adjecti.invoicing.dto.UtilityTypeDto;

public interface UtilityService {

	List<UtilityTypeDto> findAll();

	void save(UtilityTypeDto utilitydto);

}
