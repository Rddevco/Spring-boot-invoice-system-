package com.adjecti.invoicing.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.dto.AddressTypeDto;
import com.adjecti.invoicing.model.AddressType;
import com.adjecti.invoicing.repository.AddressTypeRepository;
import com.adjecti.invoicing.service.AddressTypeService;

@Service
public class AddressTypeServiceImpl implements AddressTypeService {
	@Autowired
	private AddressTypeRepository addressTypeRepository; 
	@Autowired
    private ModelMapper modelMapper;
	@Override
	public AddressTypeDto save(AddressTypeDto addressTypeDto) {
		AddressType addresstype =addressTypeRepository.save(modelMapper.map(addressTypeDto, AddressType.class));
		AddressTypeDto dto = modelMapper.map(addresstype, AddressTypeDto.class);
		return dto;
	}

	@Override
	public List<AddressTypeDto> getAddressTypes() {
	   List<AddressType> addressTypes = addressTypeRepository.findAll();
	    ArrayList<AddressTypeDto> addressTypeDto = new ArrayList<AddressTypeDto>();
		for(AddressType  addressType: addressTypes)
		{
			addressTypeDto.add(new AddressTypeDto(addressType));
		}
		
		return addressTypeDto;
	}

	@Override
	public void delete(long id) {
		this.addressTypeRepository.deleteById(id);
		
	}

	@Override
	public void update(AddressTypeDto addressTypeDto) {
		AddressType addressType= modelMapper.map(addressTypeDto, AddressType.class);
		addressTypeRepository.save(addressType);
		
	}

	@Override
	public AddressTypeDto findById(long id) {
		Optional<AddressType> addressType=	addressTypeRepository.findById(id);
		if(addressType.isPresent()) 
		return modelMapper.map(addressType.get(), AddressTypeDto.class);	
		return null;
	}

}
