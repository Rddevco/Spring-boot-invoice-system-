package com.adjecti.invoicing.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.dto.BillingCycleDto;
import com.adjecti.invoicing.model.BillingCycle;
import com.adjecti.invoicing.repository.BillingCycleRepository;
import com.adjecti.invoicing.service.BillingCycleService;

@Service
public class BillingCycleServiceImpl implements BillingCycleService {

	@Autowired
	private BillingCycleRepository billingCycleRepository;
	@Autowired
    private ModelMapper modelMapper;
	@Override
	public BillingCycleDto save(BillingCycleDto billingCycleDto) {
		BillingCycle billingCycle =billingCycleRepository.save(modelMapper.map(billingCycleDto, BillingCycle.class));
		BillingCycleDto dto = modelMapper.map(billingCycle, BillingCycleDto.class);
		return dto;
	}

	@Override
	public List<BillingCycleDto> getAllBillingCycle() {
		
		List<BillingCycle> billingCycleList = billingCycleRepository.findAll();
		List<BillingCycleDto> billingCycleDtos=new ArrayList<>();
		billingCycleList.forEach(a->billingCycleDtos.add(new BillingCycleDto(a)));

		return billingCycleDtos;
	}

	  @Override 
	  public void delete(int id) {
		  billingCycleRepository.deleteById( id); 
	  }
		@Override
		public BillingCycleDto findById(int id) {
			Optional<BillingCycle> billingcylce=	billingCycleRepository.findById(id);
			if(billingcylce.isPresent()) 
			return modelMapper.map(billingcylce.get(), BillingCycleDto.class);	
			return null;
			
		}

		@Override
		public void update(BillingCycleDto billingCycledto) {
			this.save(billingCycledto);
			
		}
}