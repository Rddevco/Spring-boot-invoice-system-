package com.adjecti.invoicing.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.dto.CompanyTypeDto;
import com.adjecti.invoicing.model.CompanyType;
import com.adjecti.invoicing.repository.CompanyRepository;
import com.adjecti.invoicing.service.CompanyTypeService;

@Service
public class CompanyTypeServiceImpl implements CompanyTypeService {
	
	@Autowired
	private CompanyRepository companyTypeRepository; 
	@Autowired
    private ModelMapper modelMapper;
	@Override
	public CompanyTypeDto save(CompanyTypeDto companyTypedto) {
		CompanyType companytype =companyTypeRepository.save(modelMapper.map(companyTypedto, CompanyType.class));
		CompanyTypeDto dto = modelMapper.map(companytype, CompanyTypeDto.class);
		return dto;
	}
	@Override
	public List<CompanyTypeDto> getCompanyList() {
		List<CompanyTypeDto>  CompanyTypeDto=  companyTypeRepository.findAll() .stream() .map(this::convertCompanyTypeDto) .collect(Collectors.toList());
		return CompanyTypeDto;
		}
	    private CompanyTypeDto convertCompanyTypeDto(CompanyType companyType) { 
	   
	        CompanyTypeDto CompanyTypeDto = modelMapper.map(companyType, CompanyTypeDto.class);	
	        return CompanyTypeDto;
	    }
		@Override
		public void delete(Integer id) {
			companyTypeRepository.deleteById(id);			
		}
		@Override
		public void update(CompanyTypeDto CompanyTypeDto) {
			CompanyType companyTypedto= modelMapper.map(CompanyTypeDto, CompanyType.class);
			companyTypeRepository.save(companyTypedto);
			
		}

		@Override
		public CompanyTypeDto findById(int id) {
			Optional<CompanyType> companyTypedto=	companyTypeRepository.findById(id);
			if(companyTypedto.isPresent()) 
			return modelMapper.map(companyTypedto.get(), CompanyTypeDto.class);	
			return null;
			
		}
	
	
}