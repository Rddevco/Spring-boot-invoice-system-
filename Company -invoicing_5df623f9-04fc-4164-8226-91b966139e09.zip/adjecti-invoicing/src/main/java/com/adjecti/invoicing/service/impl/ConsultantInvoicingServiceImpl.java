package com.adjecti.invoicing.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.adjecti.invoicing.dto.ConsultantDto;
import com.adjecti.invoicing.dto.ConsultantInvoicingDto;
import com.adjecti.invoicing.helper.FileUploadHelper;
import com.adjecti.invoicing.model.Consultant;
import com.adjecti.invoicing.model.ConsultantInvoicDocument;
import com.adjecti.invoicing.model.ConsultantInvoicing;
import com.adjecti.invoicing.repository.ConsultantInvoicingRepository;
import com.adjecti.invoicing.repository.DocumentRepository;
import com.adjecti.invoicing.service.ConsultantInvoicingService;

@Service
public class ConsultantInvoicingServiceImpl implements ConsultantInvoicingService{
	
	@Autowired
	private ConsultantInvoicingRepository consultantInvoicingRepository;
	@Autowired
	private DocumentRepository documentRepository;
	 @Value("${upload.path}")
	 private String upload_path;
	 @Autowired
	 private ModelMapper modelMapper;
	@Autowired
	private FileUploadHelper fileUploadHelper;
		

	@Override
	public ConsultantInvoicingDto save( ConsultantInvoicingDto consultantInvoicingDto, MultipartFile file) {
		boolean uploadConculatntInvoiceFile = fileUploadHelper.uploadClientFile(file);
		
		String fileName = file.getOriginalFilename();
		String contentType = file.getContentType();
		String name=file.getName();
		System.out.println(uploadConculatntInvoiceFile + " " + fileName + " "+ contentType +" "+name +" "+upload_path);
		ConsultantInvoicDocument consultantInvoicDocument = consultantInvoicingDto.getConsultantInvoicDocument();
		consultantInvoicDocument.setMimeType(contentType);
		consultantInvoicDocument.setDocumentType(name);
		consultantInvoicDocument.setName(fileName);
		consultantInvoicDocument.setTitle(fileName);
		consultantInvoicDocument.setPath(upload_path);
		consultantInvoicingDto.setConsultantInvoicDocument(consultantInvoicDocument);
		ConsultantInvoicing consultantInvoicing=this.consultantInvoicingRepository.save(consultantInvoicingDto.ToEntity());
		return new ConsultantInvoicingDto(consultantInvoicing);
		
	}

	@Override
	public List<ConsultantInvoicingDto> findAll() {
		List<ConsultantInvoicing> consultantInvoicing=this.consultantInvoicingRepository.findAll(true);
		List<ConsultantInvoicingDto> consultantInvoicingDto = new ArrayList<>();
		consultantInvoicing.forEach(c->consultantInvoicingDto.add(new ConsultantInvoicingDto(c)));
		return consultantInvoicingDto;
	}

	@Override
	public void deleteConsultantInvoicing(Integer id) {
		this.consultantInvoicingRepository.deleteById(false,id);
		
	}

	@Override
	public ConsultantInvoicingDto findByid(int id) {
		Optional<ConsultantInvoicing> consultantinvoicing=this.consultantInvoicingRepository.findById(id);
		if(consultantinvoicing.isPresent()) 
			return modelMapper.map(consultantinvoicing.get(), ConsultantInvoicingDto.class);	
			return null;
		
	}

	@Override
	public void update(ConsultantInvoicingDto consultantInvoicingDto) {
		
		
	Optional<ConsultantInvoicDocument>	invocingdocument=documentRepository.findById(consultantInvoicingDto.getConsultantInvoicDocument().getId());
	ConsultantInvoicDocument consultantInvoicDocument =invocingdocument.get();
	consultantInvoicDocument.getName();
	consultantInvoicingDto.setConsultantInvoicDocument(consultantInvoicDocument);
		this.consultantInvoicingRepository.save(consultantInvoicingDto.ToEntity());
		
	}

}
