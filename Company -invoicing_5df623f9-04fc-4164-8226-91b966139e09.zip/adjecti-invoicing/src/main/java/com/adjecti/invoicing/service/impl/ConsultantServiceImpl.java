package com.adjecti.invoicing.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.dto.ConsultantDto;
import com.adjecti.invoicing.model.Consultant;
import com.adjecti.invoicing.repository.ConsultantRepository;
import com.adjecti.invoicing.service.ConsultantService;

@Service
public class ConsultantServiceImpl implements ConsultantService{

	@Autowired
	private ConsultantRepository consultantRepository;
	@Autowired
    private ModelMapper modelMapper;
	@Override
	public ConsultantDto save(ConsultantDto consultantDto) {
		// TODO Auto-generated method stub
		 //Consultant consultant=this.consultantRepository.save(consultantDto.ToEntity());
		Consultant consultant =modelMapper.map(consultantDto, Consultant.class);
		consultant=this.consultantRepository.save(consultant);
		consultantDto=modelMapper.map(consultant, ConsultantDto.class);
		 return consultantDto;
	}

	@Override
	public List<ConsultantDto> findAll() {
		// TODO Auto-generated method stub
		List<Consultant> companyType=consultantRepository.findAll(true);
		List<ConsultantDto> consultantDto=new ArrayList<>();
		companyType.forEach(c->consultantDto.add(new ConsultantDto(c)));
		//System.out.println(consultantDto.get(0).getCompany());
		return consultantDto;
	}

	@Override
	public void delete(Integer id) {
		this.consultantRepository.deleteById(false,id);
		
	}

	@Override
	public ConsultantDto findById(int id) {
		Optional<Consultant> consultant=this.consultantRepository.findById(id);
		if(consultant.isPresent()) 
			return modelMapper.map(consultant.get(), ConsultantDto.class);	
			return null;
		
	}
	@Override
	public void update(ConsultantDto consultantDto) {
		Consultant consultant= modelMapper.map(consultantDto, Consultant.class);
		consultantRepository.save(consultant);
		
	}

}
