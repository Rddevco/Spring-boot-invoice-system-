package com.adjecti.invoicing.service.impl;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.model.CostToCompanySalary;
import com.adjecti.invoicing.model.Salary;
import com.adjecti.invoicing.repository.CostToCompanyRepository;
import com.adjecti.invoicing.service.CostToCompanyService;
@Service
public class CostToCompanyServiceImpl  implements CostToCompanyService{

	@Autowired
	CostToCompanyRepository costToCompanyRepository;
	
	@Override
	public CostToCompanySalary forUpdateCostToCompanySalary(@Valid CostToCompanySalary costtocompanysalary) {
		@Valid
		CostToCompanySalary save = costToCompanyRepository.save(costtocompanysalary);
		return save;
	}
	
	public List<CostToCompanySalary> getList() {
		List<CostToCompanySalary> list = costToCompanyRepository.findAll();
		return list;
	}

	public CostToCompanySalary getBYId(Integer id) {
		// TODO Auto-generated method stub
		Optional<CostToCompanySalary> findById = costToCompanyRepository.findById(id);
		CostToCompanySalary costToCompanySalary = null;
		if(findById.isPresent()) {
			 costToCompanySalary = findById.get();
		}
		return costToCompanySalary;
	}

	@Override
	public String getSalaryByIdForDelete(Integer id) {
		String data;
		Optional<CostToCompanySalary> findById = costToCompanyRepository.findById(id);
		CostToCompanySalary costToCompanySalary = findById.get();
		if(costToCompanySalary!=null) {
			costToCompanySalary.setStatus(true);
			costToCompanyRepository.save(costToCompanySalary);
		data="Delete Is Successfully Done.";
		}
		else {
		data="Your Id is not exist.";
		}
			return data ;
		
	}

}
