package com.adjecti.invoicing.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.model.Designation;
import com.adjecti.invoicing.repository.DesignationRepository;
import com.adjecti.invoicing.service.DesignationService;
@Service
public class DesignationServiceImpl implements DesignationService {
    @Autowired
	DesignationRepository designationRepository;

	@Override
	public Designation save(Designation designation) {
		Designation designation2 = designationRepository.save(designation);
		return designation2;
	}

	@Override
	public Designation delete(Integer designationId) {
		Optional<Designation> designation2 = designationRepository.findById(designationId);
		Designation designation = designation2.get();
		designation.setStatus(true);
		Designation designation1 = designationRepository.save(designation);
		return designation1;
	}

	@Override
	public List<Designation> getList() {
		List<Designation> list = designationRepository.findAll();
		return list;
	}

	@Override
	public Designation fetchDesignation(Integer designationId) {
		Optional<Designation> designation2 = designationRepository.findById(designationId);
		Designation designation = designation2.get();
		return designation;
		
	}
}
