package com.adjecti.invoicing.service.impl;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.model.EmployeeAddress;
import com.adjecti.invoicing.repository.EmployeeAddressRepository;
import com.adjecti.invoicing.service.EmployeeAddressService;
@Service
public class EmployeeAddressServiceImpl implements EmployeeAddressService {
    @Autowired
	EmployeeAddressRepository employeeAddressRepository;
   
  
	@Override
	public EmployeeAddress saveEmployee(EmployeeAddress employeeAddress) {
		System.out.println("Employee Address Before "+employeeAddress);
		/*
		 * entityManager.clear(); EmployeeAddress address =
		 * entityManager.merge(employeeAddress);
		 */
		EmployeeAddress address = employeeAddressRepository.save(employeeAddress); 
		System.out.println("Employee Address After "+address);
		return address;
	}
	@Override
	public EmployeeAddress fetchEmployee(Integer id) {
		Optional<EmployeeAddress> findById = employeeAddressRepository.findById(id);
	    EmployeeAddress employeeAddress = findById.get();
		return employeeAddress;
	}
	@Override
	public List<EmployeeAddress> fetchEmployeeAddress(Integer id) {
		// TODO Auto-generated method stub
		List<EmployeeAddress> findByEmployeeId = employeeAddressRepository.findByEmployeeId(id);
		for(EmployeeAddress e:findByEmployeeId)
		{
			e.setEmployee(null);
		}
		
		/*
		 * if(findByEmployeeId==null) { findByEmployeeId=new EmployeeAddress(null, null,
		 * null, null, null, null, null, null, null); }
		 */
		
		return findByEmployeeId;
	}
	@Override
	public String deleteEmployee(Integer id) {
		employeeAddressRepository.deleteById(id);
		
		return "Deleted Successfully";
	}

}
