package com.adjecti.invoicing.service.impl;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.model.EmployeeEducation;
import com.adjecti.invoicing.repository.EmployeeEducationRepository;
import com.adjecti.invoicing.service.EmployeeEducationService;
@Service
public class EmployeeEducationServiceImpl implements EmployeeEducationService
{
	@Autowired
    EmployeeEducationRepository employeeEducationRepository;
	
	@Override
	public EmployeeEducation saveEmployeeEducation(@Valid EmployeeEducation employeeEducation) {
		@Valid
		EmployeeEducation employeeEducation2 = employeeEducationRepository.save(employeeEducation);
		return employeeEducation2; 
	}

	@Override
	public EmployeeEducation fetchEducation(Integer id) {
		Optional<EmployeeEducation> findById = employeeEducationRepository.findById(id);
	EmployeeEducation employeeEducation = findById.get();
		return employeeEducation;
	}

	@Override
	public List<EmployeeEducation> fetchEmployee(Integer id) {
		List<EmployeeEducation>  byEmployeeId =employeeEducationRepository.findByEmployeeId(id);
		System.out.println(byEmployeeId);
		for(EmployeeEducation education:byEmployeeId)
		{
			education.setEmployee(null);;
		}
		return byEmployeeId;
	}

	@Override
	public boolean deleteEmployeeExperence(Integer id) {
		employeeEducationRepository.deleteById(id);
		return true;
	}

}
  
