package com.adjecti.invoicing.service.impl;

import java.util.List;
import java.util.Optional;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.model.EmployeeExperence;
import com.adjecti.invoicing.repository.EmployeeExperenceRepository;
import com.adjecti.invoicing.service.EmployeeExperenceService;
@Service
public class EmployeeExperenceServiceImpl implements EmployeeExperenceService {

	@Autowired
	EmployeeExperenceRepository employeeExperenceRepository;
	@Override
	public EmployeeExperence saveEmployeeExperence(EmployeeExperence employeeExperence) {
		
		EmployeeExperence experence = employeeExperenceRepository.save(employeeExperence);
		return experence;
	}

	@Override
	public List<EmployeeExperence> fetchEmployeeExperence(Integer id) {
		List<EmployeeExperence> findByEmployeeId = employeeExperenceRepository.findByEmployeeId(id);
		for(EmployeeExperence e:findByEmployeeId)
		{
			e.setEmployee(null);
		}
		return findByEmployeeId;
	}

	@Override
	public EmployeeExperence fetchEmployee(Integer id) {
		Optional<EmployeeExperence> findById = employeeExperenceRepository.findById(id);
		EmployeeExperence employeeExperence = findById.get();
		return employeeExperence;
	}

	@Override
	@Override
	public String deleteEmployeeExperence(Integer id) {
		employeeExperenceRepository.deleteById(id);
		return "Delete Successfully";
	}

}
