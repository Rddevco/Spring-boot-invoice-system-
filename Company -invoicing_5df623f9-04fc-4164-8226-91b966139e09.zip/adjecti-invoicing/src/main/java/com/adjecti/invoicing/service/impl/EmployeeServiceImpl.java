package com.adjecti.invoicing.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.model.Employee;
import com.adjecti.invoicing.model.Leave;
import com.adjecti.invoicing.repository.EmployeeRepository;
import com.adjecti.invoicing.service.EmployeeService;
@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	EmployeeRepository employeeRepository;
	@Override
	public Employee saveEmployee(Employee employee) {
		Employee save = employeeRepository.save(employee);
		return save;
	}
	@Override
	public List<Employee> getEmployees() {
		List<Employee> findAll = employeeRepository.findAll();
		return findAll;
	}
	@Override
	public String deleteEmployee(Integer id) {
		Optional<Employee> findById = employeeRepository.findById(id);
		if(findById.isPresent())
		{
			Employee employee = findById.get();
			employee.setStatus(true);
			employeeRepository.save(employee);
		}
		return "Delete Successfully";
	}
	@Override
	public Employee fetchEmployee(Integer id) {
		Optional<Employee> findById = employeeRepository.findById(id);
		
			Employee employee = findById.get();
			if(employee==null)
			{
				employee=new Employee(null, null, null, null, null, null, false, null, null, null, null, null, null, null, null);
			}
		return employee;
	}
	

}
