package com.adjecti.invoicing.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.dto.InvoiceDto;
import com.adjecti.invoicing.model.Invoice;
import com.adjecti.invoicing.repository.InvoiceRepository;
import com.adjecti.invoicing.service.InvoiceService;

@Service
public class InvoiceServiceImpl implements InvoiceService{

	@Autowired
	private InvoiceRepository invoiceRepository;

	@Autowired
	private ModelMapper mapper;

	@Override
	public List<InvoiceDto> findAll() {
		List<Invoice> invoices = invoiceRepository.getAllInvoice(1);
       // List<Invoice> invoices = invoiceRepository.findAll();
       // System.out.print(invoices);
        List<InvoiceDto> tempInvoices = new ArrayList<>();

        invoices.forEach(invoice -> tempInvoices.add(mapper.map(invoice, InvoiceDto.class)));
		return tempInvoices;
	}

	@Override
	public InvoiceDto save(InvoiceDto invoiceDto) {
		
		Invoice invoice = mapper.map(invoiceDto, Invoice.class);
		
		invoice = invoiceRepository.save(invoice);
		
		invoiceDto = mapper.map(invoice, InvoiceDto.class);
		
		return invoiceDto;
	}

	@Override
	public void delete(int id) {
		
		InvoiceDto invoiceDto = findById(id);
		
		if(invoiceDto!=null) {
			Invoice invoice = mapper.map(invoiceDto, Invoice.class);
			
			invoiceRepository.delete(invoice);
		}
		
	}

	@Override
	public InvoiceDto findById(int id) {
		Optional<Invoice> invoice = invoiceRepository.findById(id);
		
		Invoice tempInvoice = null;
		if(!invoice.isEmpty()) {
			tempInvoice = invoice.get();
			InvoiceDto invoiceDto = mapper.map(tempInvoice, InvoiceDto.class);
			
			return invoiceDto;
		}
		 
		return null;
	}

}
