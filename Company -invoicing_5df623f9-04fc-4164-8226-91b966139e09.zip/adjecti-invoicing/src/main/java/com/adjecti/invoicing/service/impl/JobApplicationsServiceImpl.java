
package com.adjecti.invoicing.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.dto.JobApplicationsDto;

import com.adjecti.invoicing.model.JobApplications;

import com.adjecti.invoicing.repository.JobApplicationsRepository;

import com.adjecti.invoicing.service.JobApplicationsService;

@Service
public class JobApplicationsServiceImpl implements JobApplicationsService {

	@Autowired
	private JobApplicationsRepository jobapplicationsrepository;
	@Autowired
	private ModelMapper modelMapper;

	@Override
	public List<JobApplicationsDto> getJobApplications() {
		List<JobApplications> jobapplications = jobapplicationsrepository.getJobApplications(true);
		List<JobApplicationsDto> jobapplicationsdto = new ArrayList<>();

		for (JobApplications temp : jobapplications) {
			JobApplicationsDto jobapplicationsDto = modelMapper.map(temp, JobApplicationsDto.class);
			jobapplicationsdto.add(jobapplicationsDto);

		}

		return jobapplicationsdto;
	}

	@Override
	public void delete(int id) {
		jobapplicationsrepository.delete(false, id);
	}

	@Override
	public void save(JobApplicationsDto jobapplicationsdto) {
		jobapplicationsdto.setEnabled(true);
		JobApplications savejobapplications = modelMapper.map(jobapplicationsdto, JobApplications.class);
		jobapplicationsrepository.saveAndFlush(savejobapplications);

	}

	@Override
	public JobApplicationsDto getJobApplications(int id) {

		Optional<JobApplications> optional = jobapplicationsrepository.findById(id);
		JobApplications jobapplications = optional.get();
		JobApplicationsDto jobapplicationsdto = modelMapper.map(jobapplications, JobApplicationsDto.class);
		return jobapplicationsdto;
	}

}
