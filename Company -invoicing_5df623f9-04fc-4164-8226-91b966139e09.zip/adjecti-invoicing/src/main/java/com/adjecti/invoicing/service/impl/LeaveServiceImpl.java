package com.adjecti.invoicing.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.model.Leave;
import com.adjecti.invoicing.repository.LeaveRepository;
import com.adjecti.invoicing.service.LeaveService;
@Service
public class LeaveServiceImpl implements LeaveService{
    @Autowired
    LeaveRepository  leaveRepository;
	@Override
	public Leave saveLeave(Leave leave) {
		Leave save = leaveRepository.save(leave);
		return save;
		}
	@Override
	public List<Leave> getLeaves(Integer eid) {
		List<Leave> findAll = leaveRepository.findByEmployeeId(eid);
		
		return findAll;
	}
	@Override
	public String deleteEmployee(Integer id) {
		Optional<Leave> findById = leaveRepository.findById(id);
		if(findById.isPresent())
		{
			Leave employee = findById.get();
			employee.setStatus(true);
			leaveRepository.save(employee);
		}
		return "Delete Successfully";
	}
	@Override
	public Leave fetchEmployee(Integer id) {
		Optional<Leave> findById = leaveRepository.findById(id);
		Leave leave = findById.get();
		return  leave;
	}

	
	
}
  
 