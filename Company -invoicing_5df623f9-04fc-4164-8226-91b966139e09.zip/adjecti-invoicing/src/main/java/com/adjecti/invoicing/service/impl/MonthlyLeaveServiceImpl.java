package com.adjecti.invoicing.service.impl;



import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.dto.MonthlyLeaveDto;
import com.adjecti.invoicing.dto.PeopleDto;
import com.adjecti.invoicing.model.MonthlyLeave;
import com.adjecti.invoicing.model.People;
import com.adjecti.invoicing.repository.MonthlyLeaveRepository;
import com.adjecti.invoicing.service.MonthlyLeaveService;

@Service
public class  MonthlyLeaveServiceImpl  implements  MonthlyLeaveService {
	@Autowired
	private  MonthlyLeaveRepository monthlyleaverepository;
	@Autowired
	private ModelMapper modelMapper;
	
	
	
	@Override
	public List<MonthlyLeaveDto> getMonthlyLeave() {
		List<MonthlyLeave>  monthlyleave =monthlyleaverepository.getMonthlyLeave(true);
		List<MonthlyLeaveDto> monthlyleavedto=new ArrayList<>();

		for(MonthlyLeave temp: monthlyleave) {
			MonthlyLeaveDto monthlyleaveDto=modelMapper.map(temp,MonthlyLeaveDto.class);
			monthlyleavedto.add(monthlyleaveDto);
			
		}
	   
	   return monthlyleavedto;
}
	
	 @Override 
	  public void delete(int id) {
		 monthlyleaverepository.delete(false, id);
	  }
	 @Override
	public void save(MonthlyLeaveDto monthlyleavedto) {
		 monthlyleavedto.setEnabled(true);
			MonthlyLeave savemonthlyleave = modelMapper.map(monthlyleavedto,MonthlyLeave.class);
			monthlyleaverepository.saveAndFlush(savemonthlyleave );
		
		
		}

	    @Override
		public MonthlyLeaveDto getMonthlyLeave(int id) {
		
			 Optional<MonthlyLeave> optional = monthlyleaverepository.findById(id);
			 MonthlyLeave monthlyleave = optional.get();
			 MonthlyLeaveDto monthlyleavedto = modelMapper.map(monthlyleave, MonthlyLeaveDto.class);	
				return monthlyleavedto;
		}
}
