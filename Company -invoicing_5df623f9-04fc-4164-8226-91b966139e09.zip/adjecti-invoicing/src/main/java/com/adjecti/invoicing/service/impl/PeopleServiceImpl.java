package com.adjecti.invoicing.service.impl;



import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.dto.PeopleDto;
import com.adjecti.invoicing.model.People;
import com.adjecti.invoicing.repository.PeopleRepository;
import com.adjecti.invoicing.service.PeopleService;
@Service
public class  PeopleServiceImpl  implements  PeopleService {
	@Autowired
	private  PeopleRepository peoplerepository;
	@Autowired
	private ModelMapper modelMapper;
	
	
	
	@Override
	public List<PeopleDto> getPeople() {
		List<People>  people =peoplerepository.getPeople(true);
		List<PeopleDto> peopledto=new ArrayList<>();

		for(People temp: people) {
			PeopleDto peopleDto=modelMapper.map(temp,PeopleDto.class);
			peopledto.add(peopleDto);
			
		}
	   
	   return peopledto;
}
	
	 @Override 
	  public void delete(int id) {
		 peoplerepository.delete(false, id);
	  }
	 @Override
	public void save(PeopleDto peopledto) {
			peopledto.setEnabled(true);
			People savepeople = modelMapper.map(peopledto,People.class);
			peoplerepository.saveAndFlush(savepeople );
		
		
		}

	    @Override
		public PeopleDto getPeople(int id) {
		
			 Optional<People> optional = peoplerepository.findById(id);
			 People people = optional.get();
			 PeopleDto peopledto = modelMapper.map(people, PeopleDto.class);	
				return peopledto;
		}
}
