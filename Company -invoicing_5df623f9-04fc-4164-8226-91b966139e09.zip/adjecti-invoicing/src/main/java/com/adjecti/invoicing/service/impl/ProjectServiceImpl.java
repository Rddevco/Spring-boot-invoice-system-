package com.adjecti.invoicing.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.adjecti.invoicing.dto.ProjectDto;
import com.adjecti.invoicing.dto.TechnologyDto;

import com.adjecti.invoicing.model.Project;
import com.adjecti.invoicing.model.Technology;
import com.adjecti.invoicing.repository.ProjectRepository;
import com.adjecti.invoicing.repository.TechnologyRepository;
import com.adjecti.invoicing.service.ProjectService;
import com.adjecti.invoicing.service.TechnologyService;


@Service
public class ProjectServiceImpl  implements ProjectService{
	
	@Autowired
	private ProjectRepository projectrepository;
	@Autowired
	private TechnologyService technologyservice;
	@Autowired
	private TechnologyRepository technologyrepository;
	@Autowired
	private ModelMapper modelMapper;
	

	@Override
	public List<ProjectDto> getProject() {
		List<Project> project = projectrepository.getProject(true);
		List<ProjectDto> projectdto=new ArrayList<>();

		for(Project temp:project) {
			ProjectDto dto=modelMapper.map(temp,ProjectDto.class);
			projectdto.add(dto);
			
		}
		return projectdto;
}
	
	
	
	 @Override 
	  public void delete(int id) {
		 projectrepository.delete(false, id);
	  }
	 
	 @Override
		public void save(ProjectDto projectdto, MultipartFile file) {
		
		 projectdto.setEnabled(true);
			Project project = modelMapper.map(projectdto, Project.class);
			 
		 List<Technology> technology1=new ArrayList<>();
		  
		  for(Technology technology : projectdto.getTechnology()) { 
			  TechnologyDto technologydto =technologyservice.findById(technology.getId());
			  if(technologydto!=null)
			  {
				  technology1.add(technologydto.toEntity());			 
			  }
			  }
		
		  project.setTechnology(technology1);
			project.setSowUrl(file.getOriginalFilename());
		  projectrepository.saveAndFlush(project);
		}
	 @Override
		public ProjectDto getProject(int id) {
		 Optional<Project> optional = projectrepository.findById(id);
		 Project project = optional.get();
		 ProjectDto projectdto = modelMapper.map(project,ProjectDto.class);	
			return projectdto;
		}

}