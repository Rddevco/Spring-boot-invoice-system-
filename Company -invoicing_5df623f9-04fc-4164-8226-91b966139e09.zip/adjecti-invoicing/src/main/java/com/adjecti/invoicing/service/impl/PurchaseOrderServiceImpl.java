package com.adjecti.invoicing.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.dto.PurchaseOrderDto;
import com.adjecti.invoicing.model.ClientPurchaseOrderItem;
import com.adjecti.invoicing.model.PurchaseOrder;
import com.adjecti.invoicing.repository.ClientPurchaseOrderItemRepository;
import com.adjecti.invoicing.repository.PurchaseOrderRepository;
import com.adjecti.invoicing.service.PurchaseOrderService;

@Service
public class PurchaseOrderServiceImpl implements PurchaseOrderService {

	@Autowired
	private PurchaseOrderRepository purchaseOrderRepository;
	
	@Autowired
	private ClientPurchaseOrderItemRepository ClientPoItemRepo;

	@Autowired
	private ModelMapper modelMapper;

	@Override
	public void save(PurchaseOrderDto purchaseOrderDto) {

		PurchaseOrder purchaseOrder = modelMapper.map(purchaseOrderDto, PurchaseOrder.class);
		if(purchaseOrder.getId()>0) {
			
			purchaseOrderRepository.save(purchaseOrder);
		 }
		else {
			 purchaseOrder.setEnabled(true);
			 Date date = new Date();  
			 purchaseOrder.setCreatedDate(date);			
			 purchaseOrderRepository.save(purchaseOrder);
		}

	}

	@Override
	public List<PurchaseOrderDto> getAllPurchaseOrder() {

		List<PurchaseOrder> purchaseOrders = purchaseOrderRepository.getAllPurchaseOrder(true);
		List<PurchaseOrderDto> purchaseOrderDtos=new ArrayList<>();

		for(PurchaseOrder temp:purchaseOrders) {
			PurchaseOrderDto dto=modelMapper.map(temp,PurchaseOrderDto.class);
			purchaseOrderDtos.add(dto);
			System.out.println(dto.getSow());
		}
		return purchaseOrderDtos;
	}

	@Override
	public PurchaseOrderDto getPurchaseOrder(int id) {
		Optional<PurchaseOrder> optional = purchaseOrderRepository.findById(id);
		PurchaseOrder purchaseOrder = optional.get();
		PurchaseOrderDto purchaseOrdeDto = modelMapper.map(purchaseOrder, PurchaseOrderDto.class);	
		return purchaseOrdeDto;
	}

	@Override
	public void deletePurchaseOrder(int id) {
		
		purchaseOrderRepository.deletePurchaseOrder(false,id);
	}

}