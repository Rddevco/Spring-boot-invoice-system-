package com.adjecti.invoicing.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.dto.RecievePaymentDto;
import com.adjecti.invoicing.model.RecievePayment;
import com.adjecti.invoicing.repository.RecievePaymentRepository;
import com.adjecti.invoicing.service.RecievePaymentService;
@Service
public class RecievePaymentServiceImpl implements RecievePaymentService {
	
		@Autowired
		private  RecievePaymentRepository recievepaymentrepository;
		@Autowired
		private ModelMapper modelMapper;
		
		
		
		@Override
		public List<RecievePaymentDto> getRecievePayment() {
			List<RecievePayment>  recievepayment =recievepaymentrepository.getRecievePayment(true);
			List<RecievePaymentDto> recievepaymentdto=new ArrayList<>();

			for(RecievePayment temp: recievepayment) {
				RecievePaymentDto recievepaymentDto=modelMapper.map(temp,RecievePaymentDto.class);
				recievepaymentdto.add(recievepaymentDto);
				
			}
		   
		   return recievepaymentdto;
	}
		
		 @Override 
		  public void delete(int id) {
			 recievepaymentrepository.delete(false, id);
		  }
		 @Override
		public void save(RecievePaymentDto recievepaymentdto) {
			 recievepaymentdto.setEnabled(true);
			 RecievePayment saverecievepayment = modelMapper.map(recievepaymentdto,RecievePayment.class);
			 recievepaymentrepository.saveAndFlush(saverecievepayment );
			
			
			}

		    @Override
			public RecievePaymentDto getRecievePayment(int id) {
			
				 Optional<RecievePayment> optional = recievepaymentrepository.findById(id);
				 RecievePayment recievepayment = optional.get();
				 RecievePaymentDto recievepaymentdto = modelMapper.map(recievepayment, RecievePaymentDto.class);	
					return recievepaymentdto;
			}
		
	}



