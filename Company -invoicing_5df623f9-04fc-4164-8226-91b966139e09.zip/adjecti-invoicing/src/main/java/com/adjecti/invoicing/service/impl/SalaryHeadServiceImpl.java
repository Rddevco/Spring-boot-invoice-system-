package com.adjecti.invoicing.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.model.SalaryHead;
import com.adjecti.invoicing.repository.SalaryHeadRepository;
import com.adjecti.invoicing.service.SalaryHeadService;
@Service
public class SalaryHeadServiceImpl implements SalaryHeadService {
	
	@Autowired
	SalaryHeadRepository salaryHeadRepository;
		public String save(SalaryHead salaryHead)
		{
			
			SalaryHead salaryHead2 = salaryHeadRepository.save(salaryHead);
		String data=null;
		if(salaryHead2!=null)
		{data="Save Successfully";}
			return data;
			
		}
		public List<SalaryHead> fetchAll()
		{
			List<SalaryHead> findAll = salaryHeadRepository.findAll();
			return findAll;
			
		}
		@Override
		public SalaryHead getSalaryById(Integer id) {
			Optional<SalaryHead> findById = salaryHeadRepository.findById(id);
			SalaryHead salaryHead = null;
			if(findById.isPresent()) {
				salaryHead = findById.get();
				
			}
			return salaryHead;
		}
		@Override
		public String delete(Integer id) {
			Optional<SalaryHead> findById = salaryHeadRepository.findById(id);
			String data=null;
			if(findById.isPresent()) {
				SalaryHead salaryHead= findById.get();
				if(salaryHead!=null) {
					salaryHead.setStatus(true);
					salaryHeadRepository.save(salaryHead);
					data="Successfully Deleted";
				}
				
			}
			return data;
		}
	

}
