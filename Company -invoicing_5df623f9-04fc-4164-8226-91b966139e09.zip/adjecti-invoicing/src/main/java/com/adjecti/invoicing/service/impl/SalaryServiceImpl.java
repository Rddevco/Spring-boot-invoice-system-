package com.adjecti.invoicing.service.impl;

import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.adjecti.invoicing.model.CostToCompanySalary;
import com.adjecti.invoicing.model.Salary;
import com.adjecti.invoicing.repository.SalaryRepository;
import com.adjecti.invoicing.service.SalaryService;

@Service
public class SalaryServiceImpl implements SalaryService {
	@Autowired
	SalaryRepository salaryRepository;
	
	

	@Override
	public void upload(MultipartFile file) throws Exception {

		InputStream inputStream = file.getInputStream();
		XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
		XSSFSheet sheet = workbook.getSheetAt(0);
		Iterator<Row> iterator = sheet.iterator();
		int counter = 0;
		while (iterator.hasNext() && iterator != null) {
			List<String> list = new ArrayList<>();
			XSSFRow row = (XSSFRow) iterator.next();
			Iterator<Cell> cellIterator = row.cellIterator();
			if (counter > 0) {
				int rowCounter= 0;
				boolean flag = false;
				while (cellIterator.hasNext()) {
					XSSFCell cell = (XSSFCell) cellIterator.next();
					if (rowCounter> 0 && cell.toString().trim().length() > 0) {
						list.add(cell.toString());
						flag = true;
					}
					rowCounter++;
				}

				if (flag == true) {
					save(list);
					flag = false;
				}
			}
			counter++;
		}
	}

	public void save(List<String> list) throws SecurityException, ClassNotFoundException, InstantiationException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		Constructor<?>[] declaredConstructors = Class.forName("com.adjecti.invoicing.model.Salary")
				.getDeclaredConstructors();
		Constructor<?> constructor = declaredConstructors[1];
		System.out.println("perameter"+constructor.getParameterCount());
		Object[] object  = list.toArray();
		Arrays.asList(object).stream().forEach(System.out::println);
		Object instance = constructor.newInstance(object);
		salaryRepository.save((Salary)instance);
		System.out.println("SaveComplete");
	}

	@Override
	public List<Salary> get() {
		List<Salary> findAll = salaryRepository.findAll();
		System.out.println("List "+findAll);
		return findAll;
	}

	@Override
	public Salary getSalaryById(Integer idNo)
	{
		Salary salary = null;
		Optional<Salary> findById = salaryRepository.findById(idNo);
		if(findById.isPresent())
		{
		 salary = findById.get();	
		}
		return salary;
		
	}
	@Override
	public String getSalaryByIdForDelete(Integer idNo) {
		/*
		 * Optional<Salary> findById = salaryRepository.findById(idNo); String data;
		 * if(findById.isPresent()) { Salary salary = findById.get();
		 */	
		String data;
		Salary  salary= getSalaryById(idNo);
		if(salary!=null) {
		salary.setFlag(true);
		salaryRepository.save(salary);
		data="Delete Is Successfully Done.";
		}
		else {
		data="Your Id is not exist.";
		}
			return data ;
	}

	/*
	 * @Override public Salary ForUpdateStructureSalary(Integer id,StructueSalary
	 * structueSalary) { System.out.println("Get Salary By Id For Update"); Salary
	 * salary = getSalaryById(id); if(salary!=null) {
	 * 
	 * salary.setName(structueSalary.getName());
	 * salary.setProcessingMonth(structueSalary.getProcessingMonth());
	 * salary.setpFCompany(structueSalary.getpFCompany());
	 * salaryRepository.save(salary); } return salary; }
	 */

	/*
	 * @Override public Salary ForUpdateCostToCompanySalary(CostToCompanySalary
	 * costToCompanySalary) { // TODO Auto-generated method stub Salary salary =
	 * getSalaryById(costToCompanySalary.getIdNo()); if(salary!=null) {
	 * 
	 * salary.setName(costToCompanySalary.getName());
	 * salary.setProcessingMonth(costToCompanySalary.getProcessingMonth());
	 * salary.setDayPresent(costToCompanySalary.getDayPresent());
	 * salary.setEarnings(costToCompanySalary.getEarnings());
	 * salary.settDS(costToCompanySalary.gettDS());
	 * salary.setPaymentMode(costToCompanySalary.getPaymentMode());
	 * 
	 * salaryRepository.save(salary); } return null; }
	 */

}
