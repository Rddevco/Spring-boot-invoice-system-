package com.adjecti.invoicing.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.model.Salary;
import com.adjecti.invoicing.model.SalaryStructure;
import com.adjecti.invoicing.repository.SalaryStructureRepository;
import com.adjecti.invoicing.service.SalaryStructureService;
@Service
public class SalaryStructureServiceImpl implements SalaryStructureService {
    @Autowired
	SalaryStructureRepository salaryStructureRepository;
	@Override
	public String save(SalaryStructure salaryStructure) {
        String value=null;
		SalaryStructure saveSalary = salaryStructureRepository.save(salaryStructure);
		if(saveSalary!=null) {
		value="SaveSuccessfully";	
		}
		return value;
	}
	public List<SalaryStructure> get(){
		return salaryStructureRepository.findAll();
		
		
	}
	@Override
	public SalaryStructure getSalaryById(Integer id) {
		return salaryStructureRepository.findById(id).get();
	}
	@Override
	public String delete(Integer id) {
		String data;
		 SalaryStructure salaryStructure= getSalaryById(id);
		if(salaryStructure!=null) {
			salaryStructure.setStatus(true);
		salaryStructureRepository.save(salaryStructure);
		data="Delete Is Successfully Done.";
		}
		else {
		data="Your Id is not exist.";
		}
			return data ;
		
	}
}
