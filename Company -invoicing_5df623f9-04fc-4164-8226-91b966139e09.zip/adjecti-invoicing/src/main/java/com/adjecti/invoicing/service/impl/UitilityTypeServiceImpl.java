package com.adjecti.invoicing.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoicing.dto.UtilityTypeDto;
import com.adjecti.invoicing.model.UtilityType;
import com.adjecti.invoicing.repository.UtilityTypeRepository;
import com.adjecti.invoicing.service.UtilityService;
@Service
public class UitilityTypeServiceImpl implements UtilityService{
	
	@Autowired
	private UtilityTypeRepository utilityTypeRepository; 
	@Autowired
    private ModelMapper modelMapper;
	@Override
	public List<UtilityTypeDto> findAll() {
		List<UtilityTypeDto>  utilityTypeDto=  utilityTypeRepository.findAll() .stream() .map(this::convertUtilityTypeDto) .collect(Collectors.toList());
		return utilityTypeDto;
	}
	 private UtilityTypeDto convertUtilityTypeDto(UtilityType utilityType) { 
		   
		 UtilityTypeDto utilityTypeDto = modelMapper.map(utilityType, UtilityTypeDto.class);	
	        return utilityTypeDto;
	    }
	@Override
	public void save(UtilityTypeDto utilitydto) {
		UtilityType utilityType= modelMapper.map(utilitydto, UtilityType.class);
		utilityTypeRepository.save(utilityType);
	}

}
