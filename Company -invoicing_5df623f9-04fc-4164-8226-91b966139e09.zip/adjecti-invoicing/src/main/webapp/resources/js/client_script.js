 $(document).ready(function(){
    	var tab= $('#clientTable').DataTable();
         getClientList(tab);
         tab.clear().draw();
          window.getDataTable = function() {
		        return tab;
		    }
		    
	 $('input[type=checkbox][name=taxExemptable]').change(function() {
	         
		    if ($(this).prop("checked")) {
		      $(this).val("1")
		     
		    }
		    else {
		    	$(this).val("0")
		    	
		    }
		  });

	      $("form[name='client_form']").validate({
             rules: {
			     
			       name: "required",
			       businessName:"required",
			       companyType:{
			    	   required: true   
				       } ,
			      "address.address1": "required",
			  
		           "address.phone":{
		           required: true,
		           minlength: 10,
		           maxlength: 10,
		           
		           },
		           "address.city":"required",
		           "address.email": {
				        required: true,
				       
				        email: true
		               },
		           "address.pincode":"required",
		           "address.website":"required",
		           "address.country":{

		        	   required: true   
			           },
		         

			           "address.addressType":{

			        	   required: true   
				           },
			    },
			  
			    messages: {
			      name: "Please enter name",
			      "address.address1": "Please enter adrress",
			      companyType: "Please select company type",
			    
			      businessName:"Please enter business name ",
		           "address.phone":{
		                  required: "Please enter phone number",
	                      length: "phone number must be 10 digit"
		           },
		           "address.city":"Please enter city",
		           "address.email":{
		                  required: "Please enter email",
	                      email: "enter valid email "
		           },
				   "address.pincode":"Please enter pincode ",
		           "address.website":"Please enter website",
		           "address.country":"Please select country",
		           "address.addressType":"Please select address Type ",
		        
			      
			  
			    },
			  
			    submitHandler: function (form) {
				 $('.error').remove();
				var data=$("#form_data").serialize();//.replace (/[^&]+=\.?(?:&|$)/g, '');
				console.log(data);
			    	$.ajax({
			    		 
			    		 url: "add",
		                 type: 'POST',
		               
		                   data:data,

		                     success: function (data) {
		                         console.log(data);
		                    	 $("#myModal .close").click(); 

		                     	//$(".msg").addClass("alert alert-success").text(data.msg)
		                    		$(".msg").addClass("alert alert-success").text(data.statusMessage).fadeTo(2000, 500).slideUp(500, function() {
						                   $('.msg').slideUp(500);
				                       });
		                     	window.getClientList(window.getDataTable().clear());
			                
		                     },
		              error: function (jqXHR, textStatus, errorThrown) {
	               	 var json = JSON.parse(JSON.stringify(jqXHR));
	               	 console.log(json);
	               		
	               		for (var i = 0; i < json.responseJSON.length; i++) {
		                    console.log(json.responseJSON[i].fieldName);
		                    console.log(json.responseJSON[i].errorMsg);
                          
		                    $('#'+json.responseJSON[i].fieldName).after('<span class="error">'+json.responseJSON[i].errorMsg+'</span>');
    
		                    setTimeout(function(){
		                    	  $('.error').remove();
		                    }, 20000);
		                }
	               	 
	                   
	                }

					   })
		            
		         }
			    
			    
			    
			  }); 
              
     });    

  function deleteClient(id,btn){
	if(confirm("are you sure you want to delete record ??")==true){

		 $.ajax({
	          url: 'delete/'+id,
	          method: 'GET',
	          success: function (data) {
                  console.log(data)
	        	
                  $(btn).closest("tr").remove();
                 
                
                  $(".msg").addClass("alert alert-success").text(data).fadeTo(2000, 500).slideUp(500, function() {
	                   $('.msg').slideUp(500);
                  });
                  //$(".alert").children("p").text(data);
	          },
	          error: function (jqXHR, textStatus, errorThrown) {
	              
	         	 var json = JSON.parse(JSON.stringify(jqXHR));
	              console.log(json);
	              console.log("response textStatus " + textStatus);
	              console.log("response jqXHR " + jqXHR);
	              console.log("response errorThrown " + errorThrown);
	          }
	      })

		}
	else{
          alert("your record is safe now!!");
		}
     

  }

  function addClient() {
        
		$('.modal-body').load("form",function(){
			$('.error').remove();
			$('#myModal').modal({show:true});
		});
  }


  function updateClient(id) {
      
		$('.modal-body').load("update/"+id,function(){
			$('#myModal').modal({show:true});
		});
}

/* 
	 function updateClient(id) {
		    var updateTax = window.open("update/"+id, "_blank", "scrollbars=1,resizable=1,height=300,width=450");
		    updateTax.focus();
		  
			}
 */



		function getClientList(table){

			var tab = table;
			$.getJSON("jlist", function(json) {
				for (var i = 0; i < json.length; i++) { 
					var editButton='<button class="btn btn-warning btn-xs" style="display:inline;"  onclick="javascript:updateClient(' + json[i].id + ')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button> | ';
					var deleteButton='<button class="btn btn-danger btn-xs" style="display:inline;" onclick="deleteClient(' + json[i].id + ',this)"><i class="fa fa-trash-o" aria-hidden="true"></i></button>';
					 tab.row.add( [
						    i+1,
				            json[i].name,
				            json[i].businessName,
				            json[i].address.address1,
				            json[i].address.phone,
				            json[i].address.email,
				            
				            editButton+" "+deleteButton,   
				        ] ).draw( false );	
				}	
			});
			


			}