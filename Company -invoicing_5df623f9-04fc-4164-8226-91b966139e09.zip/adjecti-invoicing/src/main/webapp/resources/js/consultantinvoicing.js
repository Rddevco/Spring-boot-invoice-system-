/**
 * 
 */
$(document).ready(function() {
var tab=$('#example').DataTable();
	getConsultantInvoicingList(tab);
	window.getDataTable = function() {
		        return tab;}
} );


/*
function deleteConsultantInvoicing(event,id)
{
	var table=$('#example').DataTable();
	var tableRow = $(event.target).parent();
if(confirm('are you sure you want to delete this record permanently?')==true){
	$.ajax({
		url:'delete/'+id,
		method:'get',
		success:function(data){
		var json = JSON.parse(JSON.stringify(data))
			console.log(json);
	         if(json == 'Delete') {
	         table.row(tableRow).remove().draw();
  			 $('#success-alert').fadeIn('slow', function(){
               $('#success-alert').delay(3000).fadeOut(); 
            });
            }
		  	},
		error:function(jqXHR,status,errorThrown){
			var json=JSON.parse(JSON.stringify(jqXHR));
			console.log(json);
			console.log(jqXHR);
			console.log(status);
			console.log(errorThrown);
		}
	})
}
else
{
	alert('Your record is safe now!');
}
}*/

function newConsultantInvoicing() {
	$('.modal-body').load('add',function(){
		$('#myModal').modal({show:true});
	});
}
function updateConsultantInvoicing(id) {
	$('.modal-body').load('update?id='+id,function(){
		$('#myModal').modal({show:true});
	});
}

	function convertDate(date) {
			var javadateTime = new Date(date);
			var day = ("0" + javadateTime.getDate()).slice(-2);
			var month = ("0" + (javadateTime.getMonth() + 1)).slice(-2);
			return javadateTime.getFullYear() + "-" + (month) + "-" + (day);

		}
	function deleteConsultantInvoicing(event,id)
{
	var table=$('#example').DataTable();
	var tableRow = $(event.target).parent();
if(confirm('are you sure you want to delete this record permanently?')==true){
	$.ajax({
		url:'delete/'+id,
		method:'get',
		success:function(data){
		var json = JSON.parse(JSON.stringify(data))
			console.log(json);
	         if(json == 'Delete') {
	         table.row(tableRow).remove().draw();
  			 $('#success-alert').fadeIn('slow', function(){
               $('#success-alert').delay(3000).fadeOut(); 
            });
            }
		  	},
		error:function(jqXHR,status,errorThrown){
			var json=JSON.parse(JSON.stringify(jqXHR));
			console.log(json);
			console.log(jqXHR);
			console.log(status);
			console.log(errorThrown);
		}
	})
}
else
{
	alert('Your record is safe now!');
}
}

	