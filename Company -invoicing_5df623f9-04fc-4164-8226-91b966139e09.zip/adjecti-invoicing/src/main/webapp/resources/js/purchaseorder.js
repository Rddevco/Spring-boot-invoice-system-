$(function() {

	var index = $("#newTable tr").length - 1;

	$("#addRow").click(function(){

		console.log(index);
		
		$("#newTable #tbody")
		.append(
				"<tr class='item'>"
				+ "<td><textarea cols='40' rows='2' name='clientPurchaseOrderItem["
				+ index
				+ "].name' class='form-control'></textarea></td>"
				+ "<td><textarea cols='40' rows='2' name='clientPurchaseOrderItem["
				+ index
				+ "].description' class='form-control'></textarea></td>"
				+ "<td><input type='number' name='clientPurchaseOrderItem["
				+ index
				+ "].qty'  class='form-control mar qty' onkeyup='Total()'/></td>"
				+ "<td><input type='number' name='clientPurchaseOrderItem["
				+ index
				+ "].price'  class='form-control mar price' onkeyup='Total()' onfocusout='calculate()'/></td>"
				+ "<td><input type='number' name='clientPurchaseOrderItem["
				+ index
				+ "].amount'  class='form-control mar amount' onkeyup='Total()'/>"
				+ "</tr>");
		++index;
		console.log(index);
	});
	
	
/*	$("#newTable #tbody tr").each(function() {
		$("#newTable #tbody tr").find(".price").focusout(function() {
			var subtotal = 0;
			$("#newTable #tbody tr").each(function() {
				var qty = $(this).find(".qty").val();
				var price = $(this).find(".price").val();
	
				var total = qty * price;
				subtotal += total;
				$(this).find(".amount").val(total);
				$("#subTotal").val(subtotal);
			});
		});
	});*/

	$("#formsubmit").submit(
			
			function(e) {
				e.preventDefault();

				client_value=clientCheck();
				po_num=poNumberCheck();
				po_date=poDateCheck();
				receive_date=receivedDateCheck();
				billing_type=billingTypeCheck();
				billing_cycle=billingCycleCheck();
				po_Title=poTitleCheck();
				if ((po_num == true) && (po_date == true)&&(billing_type==true)&&(po_Title==true)
						&& (receive_date == true) && (client_value == true)&&(billing_cycle==true)) {
					console.log(po_num);
					console.log(po_date);
					console.log(receive_date);
					console.log(client_value);
					console.log("Inside save");
					$.ajax({
						url : 'save',
						type : 'POST',
						data : $(this).serialize(),
						success : function(data) {
							console.log('success' + data);

							if (data != null) {
								$("#myModal .close").click();
							}
							window.purchaseOrderList(window.getDataTable().clear());
							$(".msg").addClass("alert alert-success").text(data.statusMessage).fadeTo(2000, 500).slideUp(500, function() {
				                   $('.msg').slideUp(500);
		                       });

						},
						error : function(jqXHR, textStatus, errorThrown) {
							var json = JSON.parse(JSON.stringify(jqXHR))
							console.log(json);
							$.each(json.responseJSON,function(key, value) {
			               		console.log(value.fieldName+value.errorMsg);                          
			               	});
							for (var i = 0; i < json.responseJSON.length; ++i) {
			                    console.log(json.responseJSON[i].fieldName);
			                    console.log(json.responseJSON[i].errorMsg);
			                    $('input[name='+json.responseJSON[i].fieldName+']').after('<span class="error d-block mx-0 text-danger">'+json.responseJSON[i].errorMsg+'</span>');
			                    setTimeout(function(){
			                    	  $('.error').remove();
			                    }, 3000);
			                }
							console.log("response textStatus " + textStatus);
							console.log("response jqXHR " + jqXHR);
							console.log("response errorThrown " + errorThrown);
						}
					});

					return true;
				} else {
					console.log("out side if");
					return false;
				}

			});

	
	
	$('#ponummsg').hide();
	$('#podatemsg').hide();
	$('#receivedatemsg').hide();
	$('#hsnmsg').hide();
	$('#clientmsg').hide();
	$('#billingTypeMsg').hide();
	$('#billingCycleMsg').hide();	
	$('#poTitleMsg').hide();

	var po_num = true;
	var po_date = true;
	var receive_date = true;
	var client_value = true;
	var billing_type=true;
	var billing_cycle=true;
	var po_Title=true;

	$('#ponumber').keyup(function() {
		poNumberCheck();
	});

	$('#poTitle').keyup(function(){
		poTitleCheck();
	});

	$('#podate').on("change", function() {
		console.log("hello");
		console.log($('#podate').val());
		poDateCheck();
	});

	$('#receivedate').on("change", function() {
		console.log($('#receivedate').val());
		receivedDateCheck();
	});

	$('#billingtype').on("change", function() {
		console.log("billing type");
		billingTypeCheck();
	});
	
	$('#billingcycle').on("change", function() {
		console.log("billing Cycle");
		billingCycleCheck();
	});
	
	$('#client').on("change", function() {
		console.log("client");
		clientCheck();
	});

	function poNumberCheck() {

		var ponum = $('#ponumber').val();

		if (ponum.length == '') {
			$('#ponummsg').show();
			$('#ponummsg').html("PO Number must not be null");
			$('#ponummsg').focus();
			$('#ponummsg').css("color", "red");
			po_num = false;
			return false;
		} 
		
		else if ((ponum.length < 3) || (ponum.length > 10)) {

			$('#ponummsg').show();
			$('#ponummsg').html("Length must be between 3-10 character");
			$('#ponummsg').focus();
			$('#ponummsg').css("color", "red");
			po_num = false;
			return false;
		} 
		else {
			$('#ponummsg').hide();
			return true;
		}
	}
	
	function poTitleCheck(){
			
		var value = $('#poTitle').val();
		if(value.length==''){
			$('#poTitleMsg').show();
			$('#poTitleMsg').html('PO Number must not be empty');
			$('#poTitleMsg').focus();
			$('#poTitleMsg').css("color","red");
			po_Title=false;
			return false;
		}
		else{
			$('#poTitleMsg').hide();
			return true;
		}
		
	}

	function clientCheck() {

		var client = $('#client').val();

		if (client == '0') {

			$('#clientmsg').show();
			$('#clientmsg').html("Please select Client Name");
			$('#clientmsg').focus();
			$('#clientmsg').css("color", "red");
			client_value = false;
			return false;
		} else {
			$('#clientmsg').hide();
			return true;
		}
	}
	
	function billingTypeCheck() {

		var temp = $('#billingtype').val();

		if (temp == '0') {

			$('#billingTypeMsg').show();
			$('#billingTypeMsg').html("Please select Billing Type");
			$('#billingTypeMsg').focus();
			$('#billingTypeMsg').css("color", "red");
			billing_type = false;
			return false;
		} else {
			$('#billingTypeMsg').hide();
			return true;
		}
	}
	
	function billingCycleCheck() {

		var temp = $('#billingcycle').val();

		if (temp == '0') {

			$('#billingCycleMsg').show();
			$('#billingCycleMsg').html("Please select Billing Cycle");
			$('#billingCycleMsg').focus();
			$('#billingCycleMsg').css("color", "red");
			billing_cycle = false;
			return false;
		} else {
			$('#billingCycleMsg').hide();
			return true;
		}
	}

	function receivedDateCheck() {

		var recdat = $('#receivedate').val();

		if (recdat == '') {

			$('#receivedatemsg').show();
			$('#receivedatemsg').html("Please Select Date");
			$('#receivedatemsg').focus();
			$('#receivedatemsg').css("color", "red");
			receive_date = false;
			return false;
		} else {
			$('#receivedatemsg').hide();
			return true;

		}
	}

	function poDateCheck() {

		var podat = $('#podate').val();

		if (podat == '') {

			$('#podatemsg').show();
			$('#podatemsg').html("Please Select Date");
			$('#podatemsg').focus();
			$('#podatemsg').css("color", "red");
			po_date = false;
			return false;
		} else {
			$('#podatemsg').hide();
			console.log(podat);
			return true;
		}
	}

});

function calculate(){

	//$("#newTable #tbody tr").each(function() {
//		$("#newTable #tbody tr").find(".price").focusout(function() {
			var subtotal = 0;
			$("#newTable #tbody tr").each(function() {
				var qty = $(this).find(".qty").val();
				var price = $(this).find(".price").val();
	
				var total = qty * price;
				subtotal += total;
				$(this).find(".amount").val(total);
				$("#subTotal").val(subtotal);
			});
	//	});
//	});
}
function deleteRow(size){
	
	var totalRows = $("#newTable tr").length;
	if(size==undefined){
	//	alert(size);
		if(totalRows>2){
			$("#newTable tr:last").remove();
		}
	}
	else{
	//	alert(size); 
		console.log(size+" "+totalRows);
		if(totalRows-1!=size){
			$("#newTable tr:last").remove();
		}
	}

}
function Total() {

	var v1 = parseInt(document.getElementById("subTotal").value);
	var v2 = parseInt(document.getElementById("taxAmount").value);
	var v3 = parseInt(document.getElementById("otherAmount").value);
	var sum = v1 + v2 + v3;

	$("#grandTotal").val(sum);
}

function balance() {
	var v1 = parseInt(document.getElementById("grandTotal").value);
	var v2 = parseInt(document.getElementById("advancePaid").value);
	var bal = v1 - v2;

	document.getElementById("balanceDue").value = bal;
}