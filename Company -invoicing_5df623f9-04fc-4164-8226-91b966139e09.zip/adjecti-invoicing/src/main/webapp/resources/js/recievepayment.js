if (window.jQuery) { 
	 
       $(document).ready(function(){
    	var tab= $('#recievepaymentTable').DataTable();
         getRecievePaymentList(tab);
         tab.clear().draw();
          window.getDataTable = function() {
		        return tab;
		    }
		    
	  });  
	 
 function addRecievePayment() {
        
		$('.modal-body').load("new",function(){
			$('#myModal').modal({show:true});
		});
  }


  function updateRecievePayment(id) {
      console.log(id)
		$('.modal-body').load("update/"+id,function(){
			$('#myModal').modal({show:true});
		});
}

function getRecievePaymentList(table){

			var tab = table;
			$.getJSON("jlist", function(json) {
				for (var i = 0; i < json.length; i++) { 
					var editButton='<button class="btn btn-warning btn-xs" style="display:inline;"  onclick="javascript:updateRecievePayment(' + json[i].id + ')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button> | ';
					var deleteButton='<button class="btn btn-danger btn-xs" style="display:inline;" onclick="deleteRecievePayment(' + json[i].id + ',this)"><i class="fa fa-trash-o" aria-hidden="true"></i></button>';
					 
					 var amountRecieved;
					 amountRecieved="<td>"+json[i].amountReceived+' '+json[i].invoice.currency+"</td>";
					 var calculateAmountReceived;
										if (json[i].exchangeRate == 0) {
                                          console.log(json[i].exchangeRate);
											calculateAmountReceived="<td>"+json[i].amountReceived+' '+'INR'+"</td>";
											
										} else {
											calculateAmountReceived="<td>"+json[i].amountReceived*json[i].exchangeRate+' '+'INR'+ "</td>";
											 console.log(json[i].amountReceived);
										}
					 tab.row.add( [
						    i+1,
				            json[i].invoice.invoiceNo,
			                json[i].client.name,
			                convertDate( json[i].dateOfPayment),
			                json[i].paymentMode.name,
			                     amountRecieved,
			                calculateAmountReceived,
				            editButton+" "+deleteButton,   
				        ] ).draw( false );	
				}	
			});
			


			}

    	   $("#add_recievepayment").validate({
			
           rules: { 
        	   dateOfPayment: {
        		   required: true 
        	   },
        	  transactionDetails: {
        		   required: true 
        	   },
        	    
        	   
			    },
			  
			    messages: {
			       dateOfPayment: "Date Of Payment is required",
			      transactionDetails:"Transaction Details is required",
			       
			      
			    },
			  
			    submitHandler: function (form) {
			    	 $.ajax({
			      		 url: 'add',
			      		 type: 'GET',
			      		 data:$("#add_recievepayment").serialize(),
			      		 success: function(data) {
					     		
			      			$("#myModal .close").click();
			      			window.getRecievePaymentList(window.getDataTable().clear());
			      		$(".msg").addClass("alert alert-success").text(data.msg).fadeTo(2000, 500).slideUp(500, function() {
				                   $('.msg').slideUp(500);
		                       });
		                     	
								
								 
			      		 
			      		 },error: function (jqXHR, textStatus, errorThrown) {
			      		 var json = JSON.parse(JSON.stringify(jqXHR))
			      		 console.log(json);
			      		 console.log("response textStatus " + textStatus);
			      		 console.log("response jqXHR " + jqXHR);
			      		 console.log("response errorThrown " + errorThrown);
			      		 }
			      		 })
		            
		         }
  
			 }); 
            
    
        

  function deleteRecievePayment(id,btn){
	if(confirm("are you sure you want to delete record ??")==true){

		 $.ajax({
	          url: 'delete/'+id,
	          method: 'GET',
	          success: function (data) {
                  console.log(data)
	        	
                  $(btn).closest("tr").remove();
                 
                
                 	$(".msg").addClass("alert alert-success").text(data.msg).fadeTo(2000, 500).slideUp(500, function() {
				                   $('.msg').slideUp(500);
		                       });
                  $(".alert").children("p").text(data);
	          },
	          error: function (jqXHR, textStatus, errorThrown) {
	              
	         	 var json = JSON.parse(JSON.stringify(jqXHR));
	              console.log(json);
	              console.log("response textStatus " + textStatus);
	              console.log("response jqXHR " + jqXHR);
	              console.log("response errorThrown " + errorThrown);
	          }
	      })

		}
	else{
          alert("your record is safe now!!");
		}
     

  }
function convertDate(date) {
	var javadateTime = new Date(date);

	var day = ("0" + javadateTime.getDate()).slice(-2);
	var month = ("0" + (javadateTime.getMonth() + 1)).slice(-2);

	return (day)+ "-" + (month)+ "-" +javadateTime.getFullYear();

}

   } 




