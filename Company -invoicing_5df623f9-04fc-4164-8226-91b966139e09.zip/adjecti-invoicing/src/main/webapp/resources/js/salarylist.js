$(document).ready(function() {
	var tab = $('#datasalary').DataTable();
	getsalaryList(tab);
	tab.clear().draw();
	window.getDataTable = function() {
		return tab;
	}

});

function getsalaryList(table) {

	var tab = table;
	$.getJSON("/salary/jlist", function(json) {


		$.each(json, function(key, entry) {

			console.log("--------------------------------------------");
			console.log(entry);
			console.log("Json key: ");
			console.log(key);
			console.log("--------------------------------------------");
			$.each(entry, function(key, val) {
				console.log("key " + key);
				console.log(val);


			});
			const monthNames = ["January", "February", "March", "April", "May", "June",
           "July", "August", "September", "October", "November", "December"
            ];


			var d = new Date(entry.processingMonth);
							var day = ("0" + d.getDate()).slice(-2);
							var month = monthNames[d.getMonth()];
							var year = d.getFullYear();
var ddate = month + "-" +year ;
			tab.row.add([

				entry.idNo,
				entry.name,
				ddate,
				entry.earnings,
				entry.pFCompany,
				entry.pFEmployer,
				entry.tDS,
				entry.advance,
				entry.netSalary,
				entry.currentMonthsSalaryReimb,
				"<button class='btn btn-dark' onclick='myPrintFun2($(this))'><i class='bi bi-printer-fill'></i></button>"
			]).draw(false);
		});


	});
}
function myPrintFun2(data) {
	console.log("Reference : " + data);
	$(data).closest("tr").css("color", "");
	var id1 = $(data).closest('tr').children('td:first').text();
	console.log("textval id1 " + id1);
window.location.href ='/salary/fetchh/'+id1;

}

function myPrintFun(data) {
	console.log("Reference : " + data);
	$(data).closest("tr").css("color", "");
	var id1 = $(data).closest('tr').children('td:first').text();
	console.log("textval id1 " + id1);

	$.ajax({
		url: '/salary/fetch/' + id1,
		type: 'GET',
		success: function(data) {
			var json = JSON.parse(JSON.stringify(data))
			console.log(json);

			$('#ptable tbody tr').each(function() {

				$(this).find('#edata').html('<b>Employee Code :</b>   ' + json.idNo +
					'<br><b>Name :</b>  ' + json.name +
					'<br><b>Tax Regime :</b>  OLD'

				);
				$(this).find('#edepartment').html('<b>Department : </b>  ' + json.department +
					'<br><b>Designation :</b>  ' + json.designation +
					'<br><b>Payable Days :</b>   31.00');



			});


			$('#ptable tbody #three').each(function() {
				$(this).find("td:eq(0)").html(json.netSalary);
				$(this).find("td:eq(1)").html(json.netSalary);
				$(this).find("td:eq(2)").html(json.arears);
				$(this).find("td:eq(3)").html(parseFloat(json.netSalary) + parseFloat(json.arears));
				$(this).find("td:eq(4)").html("<b>Income Tax</b>");
				$(this).find("td:eq(5)").html(parseFloat(json.deductions));

			});
			$('#ptable tbody #four').each(function() {
				$(this).find("td:eq(0)").html(json.hRA);
				$(this).find("td:eq(1)").html(json.hRA);
				$(this).find("td:eq(2)").html(json.arears);
				$(this).find("td:eq(3)").html(parseFloat(json.hRA) + parseFloat(json.arears));
				$(this).find("td:eq(4)").html("<b>Gratuity</b>");
				$(this).find("td:eq(5)").html(parseFloat(json.gratuity));

			});
			$('#ptable tbody #five').each(function() {
				$(this).find("td:eq(0)").html(json.tA);
				$(this).find("td:eq(1)").html(json.tA);
				$(this).find("td:eq(2)").html(json.arears);
				$(this).find("td:eq(3)").html(parseFloat(json.tA) + parseFloat(json.arears));
				$(this).find("td:eq(4)").html();
				$(this).find("td:eq(5)").html();

			});
			$('#ptable tbody #six').each(function() {
				$(this).find("td:eq(0)").html(json.sA);
				$(this).find("td:eq(1)").html(json.sA);
				$(this).find("td:eq(2)").html(json.arears);
				$(this).find("td:eq(3)").html(parseFloat(json.sA) + parseFloat(json.arears));
				$(this).find("td:eq(4)").html();
				$(this).find("td:eq(5)").html();

			});
			var total = parseFloat(json.netSalary) + parseFloat(json.arears) +
				parseFloat(json.hRA) + parseFloat(json.arears) +
				parseFloat(json.tA) + parseFloat(json.arears) +
				parseFloat(json.sA) + parseFloat(json.arears);
			$('#ptable tbody #seven').each(function() {
				$(this).find("td:eq(0)").html(parseInt(json.netSalary) + parseInt(json.hRA) + parseInt(json.tA) + parseInt(json.sA));
				$(this).find("td:eq(1)").html(json.sA);
				$(this).find("td:eq(2)").html(json.arears);

				$(this).find("td:eq(3)").html(total);
				$(this).find("td:eq(4)").html("<b>GROSS DEDUCTIONS</b>");
				$(this).find("td:eq(5)").html(parseFloat(json.deductions) + parseFloat(json.gratuity));

			});
			var netPay = (parseFloat(total) - (parseFloat(json.deductions) + parseFloat(json.gratuity)));
			$('#ptable tbody #eight').find("td").html('<b>Net Pay  :  </b>' + netPay);

			$('#ptable tbody #nine').find("td").html('<b>Net Pay In Words  :  </b>');

var wholePrintContent=document.body.innerHTML;
var divContent=document.getElementById('printsalary');
document.body.innerHTML=divContent;
window.print();
document.body.innerHTML=wholePrintContent;



			
	
	
		},
		error: function(error) {
			console.log("error : " + error);
		}

	});


}

function myPrintFun1()
{

var wholePrintContent=document.body.innerHTML;
var divContent=document.getElementById('printsalary');
document.body.innerHTML=divContent;
window.print();
document.body.innerHTML=wholePrintContent;

}