$(document).ready(function() {
	var tab = $('#structure').DataTable();
	getsalaryList(tab);
	tab.clear().draw();
	window.getDataTable = function() {
		return tab;
	}

});





function getsalaryList(table) {

	var tab = table;
	$.getJSON("jlist", function(json) {


		$.each(json, function(key, entry) {

			console.log("--------------------------------------------");
			console.log(entry);
			console.log("Json key: ");
			console.log(key);
			console.log("--------------------------------------------");
			var updateButton = '<button id="updatebutton" class="btn btn-warning btn-xs"  style="display-inline;"  onclick="updateProject(' + entry.id + ',event)"><i class="bi bi-pencil-square"  aria-hidden="true"></i></button>';
			var deleteButton = '<button class="btn btn-danger btn-xs" style="display:inline;" onclick="deleteProject(' + entry.id + ',this)"><i class="fa fa-trash-o" aria-hidden="true"></i></button>';

			if (entry.status == false) {
				tab.row.add([

					key + 1,
					entry.name,
					entry.fromDate,
					entry.toDate,
					entry.currency,
					updateButton + " " + deleteButton
				]).draw(false);
			}
		});

	});
}

function deleteProject(id, e) {
	if (confirm("are you sure you want to delete record ??") == true) {

		$.ajax({
			url: 'delete/' + id,
			method: 'GET',
			success: function(data) {
				console.log("Success  Donr: " + data);

				$(e).closest("tr").remove();
				$(".msg").addClass("alert alert-success").text(data.msg).fadeTo(2000, 500).slideUp(500, function() {
					$('.msg').slideUp(500);

				});


			},
			error: function(jqXHR, textStatus, errorThrown) {

				var json = JSON.parse(JSON.stringify(jqXHR));
				console.log(json);
				console.log("response textStatus " + textStatus);
				console.log("response jqXHR " + jqXHR);
				console.log("response errorThrown " + errorThrown);
			}
		})

	}
	else {
		alert("your record is safe now!!");
	}


}

function updateProject(id, e) {
	console.log("updateProject --++--" + id + "  " + e);
	$.ajax({
		url: 'fetch/' + id,
		method: 'GET',
		success: function(data) {
			console.log("Success" +data);
			console.log("idNo : " + data.id);
			console.log("Name : " + data.name);
			console.log("dayPresent : " + data.fromDate);
			console.log("processingMonth : " + data.toDate);
			console.log("pFCompany : " + data.currency);

			/*
							var d = new Date(data.processingMonth);
							var day = ("0" + d.getDate()).slice(-2);
							var month = ("0" + (d.getMonth() + 1)).slice(-2);
							var year = d.getFullYear();
			*//*
							var ddate = year + "-" + month + "-" + day;
							*/
			if (e.id = "updatebutton") {
				$('#idNo').val(data.id);
				$('#name').val(data.name);
				$('#fromDate').val(data.fromDate);
				$('#toDate').val(data.toDate);
				$('#pFCompany').val(data.currency);
				$('#tabb').hide();
			}
			
			$('#structure-Modal').modal('show');
			/*   location.href = "structureSalaryform"; */
		},
		error: function(error) {
			console.log("error : " + JSON.stringify(error));
		}

	});
}

	$("#formm").submit(function(event) {


		console.log("I am from saveStructure");
		event.preventDefault();
		console.log("After dEfault");


		$.ajax({
			url: '/salaryStructure/save',
			type: 'POST',
			data: $(this).serialize(),
			success: function(data) {
				var json = JSON.parse(JSON.stringify(data))
				console.log(json);
				window.location.href = '/salaryStructure/structure';
				
			},
			error: function(jqXHR, textStatus, errorThrown) {
				var json = JSON.parse(JSON.stringify(jqXHR))
				console.log(json);
				$.each(json.responseJSON, function(key, value) {
					console.log(value.field);
					console.log(value.statusMessage);
			});
				for (var i = 0; i < json.responseJSON.length; ++i) {
					console.log(json.responseJSON[i].field);
					console.log(json.responseJSON[i].statusMessage);
					$('#' + json.responseJSON[i].field).after('<span class="error text-danger d-block">' + json.responseJSON[i].statusMessage + '</span>');
					setTimeout(function() {
						$('.error').remove();
					}, 5000);
				}
				console.log("response textStatus " + textStatus);
				console.log("response jqXHR " + jqXHR);
				console.log("response errorThrown " + errorThrown);
			}




});
});




function addComponenetData(){

$.ajax({
url:'/salaryhead/fetchAll',
method:'GET',
success: function(data){console.log(JSON.stringify(data));
var json = JSON.parse(JSON.stringify(data));
console.log(json);
var tab = $('#componentTab').DataTable();
$.each(json, function(key, value) {
					console.log(value.status);
					console.log(value.name);
		 
if (value.status == false) {
var type;
if(value.type==1){type="Addition";}
else{type="Deduction";}
				tab.row.add([
				value.name,
					value.period,
					type,
					value.code,
				]).draw(false);
			}		
			});
			$('#tabb').show();
$('#structure-Modal').modal('show');
},
error: function(error){console.log(JSON.stringify(error));}




})
}
$(function () {
            $(".modal-footer").click(function () {
             $(".modal").modal("hide");
            });
          });
          
          
          
          
function closeAndClean()
{
var tab = $('#componentTab').DataTable();
console.log("Clean And Close");  
var gg=$("table#componentTab").find("tbody>tr");
$.each(gg,function(k,v){
console.log(v);

tab.row( $(this) ).remove().draw();
});
$('#formm').trigger("reset");
/*$("#formm").find(".a").empty();*/
     console.log("End Of Clean And Close");
      
      
      
}