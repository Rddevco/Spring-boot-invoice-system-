package com.adj.mdm.invoice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
class ApplicationTests {

	@Test
	void contextLoads() {
	}

}
